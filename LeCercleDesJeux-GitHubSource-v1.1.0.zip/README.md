# Le Cercle des jeux

Jeu de réflexion en français : sudoku, mots croisés, mots fléchés, mots mêlés et mémory. Le mode solo fonctionne sans connexion ; les défis France quotidiens sont facultatifs.

## Jouer

Ouvrez `index.html` dans un navigateur ou lancez `Lancer-Le-Cercle.bat`. La progression solo et les 52 trophées internes restent dans le stockage local de l’appareil.

## Défis quotidiens France

Chaque date et chaque jeu utilisent une grille commune. Les joueurs peuvent jouer sans créer de pseudo. Pour envoyer un résultat au classement France, il faut accepter la politique de confidentialité et créer un pseudo anonyme. Le jeu transmet alors le temps, les aides et les erreurs. Le profil et ses résultats peuvent être supprimés depuis le menu des défis.

Le classement est asynchrone et amical. Le serveur conserve les scores 90 jours et supprime les profils inactifs après 12 mois. Les temps étant déclarés par le client, ils ne sont pas inviolables.

Pour installer le service sur l’hébergement, suivre `server/mysql-api/README.md`. Le site doit proposer PHP 8.2, PDO MySQL et HTTPS. Les identifiants MySQL doivent rester dans le fichier `config.php` sur l’hébergement, jamais dans le dépôt public.

La politique de confidentialité est dans `privacy.html`. Les jeux solo ne transmettent aucune partie au serveur. Les succès Xbox/Windows ne sont pas activés dans cette version.

## Plateformes

- `Plateformes/WindowsExe/` : EXE Windows d’essai.
- `Plateformes/WindowsStore/` : paquet Windows Store.
- `Plateformes/Android/` : APK de test et projet Android.
- `Propositions/` : les deux présentations visuelles alternatives conservées séparément.
