# Défis France — installation PHP/MySQL

Le service fournit une grille quotidienne identique à tous les joueurs en France et un classement asynchrone par jeu. Il nécessite PHP 8.2+, l’extension PDO MySQL et un site accessible en HTTPS.

## Étapes d’installation

1. Dans le panneau de ton hébergeur, crée une base MySQL et un utilisateur avec les droits `SELECT`, `INSERT`, `UPDATE` et `DELETE` sur cette base.
2. Importe `schema.sql` dans cette base neuve avec phpMyAdmin.
3. Téléverse les dossiers et fichiers du paquet dans `public_html/lecercle-api/`. Le point d’entrée sera `public_html/lecercle-api/v1/index.php`.
4. Dans le gestionnaire de fichiers de l’hébergeur, copie `config.example.php` sous le nom `config.php`. Remplis le nom de la base, l’hôte, l’utilisateur et le mot de passe MySQL de ton hébergeur. Remplace `challenge_secret` par une longue valeur aléatoire privée d’au moins 32 caractères.
5. Ne publie jamais `config.php` ni les identifiants MySQL sur GitHub et ne les envoie pas dans le chat. Le fichier `.htaccess` bloque l’accès public à la configuration et au schéma SQL.
6. Vérifie que `pdo_mysql` est disponible et que le site a un certificat HTTPS valide.

Le jeu appelle cette adresse :

`https://loic-apps.duckdns.org/lecercle-api/v1/index.php`

Après l’installation, ouvre cette adresse avec `?action=challenge&mode=sudoku`. La réponse doit contenir `"ok":true`, la date, le niveau et la graine du défi. Ensuite, ouvre le jeu, coche la participation et crée un pseudo : cela vérifie la connexion à MySQL.

## Données et durée

- Un pseudo est généré automatiquement, seulement après le choix explicite de participer.
- La date de participation et la version de la politique acceptée sont conservées avec le profil.
- Le jeton d’accès est conservé dans le stockage local du jeu ; seule son empreinte SHA-256 est gardée en base.
- Le jeu, la date, le meilleur temps, les aides et les erreurs sont enregistrés pour alimenter le classement.
- Les résultats de plus de 90 jours sont purgés automatiquement lors d’une requête au service.
- Les profils sans activité depuis 12 mois et leurs scores restants sont purgés automatiquement lors d’une requête au service.
- La suppression du pseudo depuis le jeu supprime immédiatement le profil et ses scores associés.

Aucun nom réel, e-mail ou emplacement n’est demandé. Le pseudo et le temps sont visibles sur le classement France du jour. L’hébergeur peut traiter des données techniques, comme l’adresse IP, dans ses journaux selon sa configuration.

## Limites du premier prototype

Les résultats sont envoyés par le client après la partie. Le serveur protège les requêtes SQL et les jetons, mais ne rejoue pas la grille pour vérifier le résultat ; un joueur peut donc falsifier un score. Le classement convient aux défis amicaux, sans prix ni récompense.

Les défis sont asynchrones : chacun joue quand il veut. Il n’y a ni salon en direct ni WebSocket. Le mode solo ne dépend pas de cette API.
