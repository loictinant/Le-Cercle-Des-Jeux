<?php
return [
    // Remplace ces valeurs avec celles créées dans le panneau d’hébergement.
    'dsn' => 'mysql:host=localhost;dbname=lecercle_des_jeux;charset=utf8mb4',
    'username' => 'UTILISATEUR_MYSQL',
    'password' => 'MOT_DE_PASSE_MYSQL',
    // Génére une longue valeur aléatoire indépendante des identifiants MySQL.
    'challenge_secret' => 'REMPLACER_PAR_UN_SECRET_ALEATOIRE_D_AU_MOINS_32_CARACTERES',
];
