CREATE TABLE IF NOT EXISTS players (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nickname VARCHAR(20) NOT NULL,
  token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL,
  consented_at DATETIME NOT NULL,
  consent_version VARCHAR(32) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_players_token_hash (token_hash),
  UNIQUE KEY uq_players_nickname (nickname),
  KEY ix_players_last_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS daily_scores (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  player_id BIGINT UNSIGNED NOT NULL,
  challenge_date DATE NOT NULL,
  game_mode ENUM('sudoku','crossword','arrows','search','memory') NOT NULL,
  best_seconds INT UNSIGNED NOT NULL,
  hints_used SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  mistakes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  ranking_key BIGINT UNSIGNED NOT NULL,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_player_daily_mode (player_id, challenge_date, game_mode),
  KEY ix_daily_leaderboard (challenge_date, game_mode, ranking_key),
  CONSTRAINT fk_daily_scores_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
