# Le Cercle des jeux

> **Proposition 02 — Cabinet nocturne.** Copie de présentation créée pour comparaison, enrichie de cinq illustrations 3D. L’application d’origine n’est pas modifiée et cette copie utilise sa propre sauvegarde.

Un jeu de réflexion en français, avec mode solo hors ligne et défis quotidiens France facultatifs.

## Lancer le jeu

Double-cliquez sur `Lancer-Le-Cercle.bat`, ou ouvrez `index.html` dans votre navigateur.

## Jeux inclus

- Sudoku avec grilles générées, chiffres au clavier, vérification et indices.
- Mots croisés avec définitions et cases qui se croisent.
- Mots fléchés avec flèches de direction dans la grille.
- Mots mêlés avec sélection des mots à la souris.
- Mémory avec un nombre de paires qui augmente au fil des niveaux.

Chaque jeu possède sa progression et génère de nouveaux niveaux sans fin. Les niveaux atteints, parties terminées et trophées sont enregistrés dans le navigateur sur cet appareil.

## Trophées

La collection comprend 52 trophées de bronze, d’argent, d’or et de diamant. Elle récompense la découverte des cinq jeux, les séries de victoires, les parties sans erreur ou sans indice, les records de vitesse et les grandes étapes de progression. Chaque déblocage affiche une notification ; plusieurs trophées gagnés à la fin d’une même partie sont annoncés l’un après l’autre. La collection peut être filtrée par trophées gagnés ou à décrocher.

Cette collection fonctionne hors ligne et reste dans le jeu. Ce ne sont pas encore des succès Xbox visibles dans l’application Xbox ou associés au Gamerscore. Ceux-ci demandent une intégration au Game Development Kit et une configuration Xbox/Partner Center ; voir la [documentation Microsoft sur les succès](https://learn.microsoft.com/en-us/gaming/gdk/docs/gdk-dev/pc-dev/tutorials/pc-e2e-guide/e2e-services/e2e-achievements?view=gdk-2604).

## Commandes

- **Sudoku :** cliquez une case et choisissez un chiffre, ou tapez `1` à `9`. Les flèches déplacent la sélection et `Retour arrière` efface la case.
- **Mots croisés et mots fléchés :** cliquez une définition ou une case, puis tapez les lettres. `Retour arrière` efface la lettre sélectionnée.
- **Mots mêlés :** cliquez sur la première lettre, puis sur la dernière lettre d’un mot.
- **Mémory :** cliquez sur deux cartes pour chercher une paire.

Le mode solo reste hors ligne. Les défis peuvent se jouer sans pseudo ; publier un résultat demande un accord explicite et l’API PHP/MySQL décrite dans `../../server/mysql-api/`. Les scores du premier prototype sont envoyés par le jeu et ne sont pas vérifiés indépendamment par le serveur.
