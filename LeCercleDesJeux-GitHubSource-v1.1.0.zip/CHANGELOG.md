# Changements

## 1.1.0 — 18 novembre 2026

- Ajout des défis quotidiens asynchrones France et d’un classement séparé pour chacun des cinq jeux.
- Les grilles quotidiennes sont générées à partir d’une graine commune fournie par le service.
- La participation au classement est facultative et demande une acceptation explicite ; le pseudo est généré automatiquement.
- Ajout d’une API PHP/MySQL, de la suppression du profil et d’une politique de confidentialité dédiée.
- Le mode solo, sa progression et les trophées internes restent disponibles hors ligne.
- Les succès Windows/Xbox restent désactivés. Le service doit être installé et configuré sur l’hébergement avant que le classement soit joignable.
