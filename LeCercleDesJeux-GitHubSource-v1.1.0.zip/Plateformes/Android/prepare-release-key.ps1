$ErrorActionPreference = 'Stop'
$toolchainRoot = Join-Path (Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))) '.toolchain'
$jdkRoot = Get-ChildItem (Join-Path $toolchainRoot 'jdk17') -Directory -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if (-not $jdkRoot) { throw "Installez d'abord le JDK indiqué dans KIT_ANDROID.md." }

$signingDirectory = Join-Path $env:LOCALAPPDATA 'LeCercleDesJeux\AndroidSigning'
New-Item -ItemType Directory -Path $signingDirectory -Force | Out-Null
$keystore = Join-Path $signingDirectory 'le-cercle-des-jeux-upload.jks'
$passwordFile = Join-Path $signingDirectory 'upload-password.dpapi'
if (Test-Path $keystore) { throw "Une clé existe déjà. Ne l'écrasez pas : elle sert aux mises à jour de l'application." }

$randomBytes = New-Object byte[] 36
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($randomBytes) } finally { $rng.Dispose() }
$password = [Convert]::ToBase64String($randomBytes).TrimEnd('=').Replace('+', 'A').Replace('/', 'B')
$securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force
$securePassword | ConvertFrom-SecureString | Set-Content -LiteralPath $passwordFile -NoNewline

$env:JAVA_HOME = $jdkRoot
$env:LCJ_KEY_PASS = $password
$keytool = Join-Path $jdkRoot 'bin\keytool.exe'
try {
    & $keytool -genkeypair -v -keystore $keystore -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias le-cercle-upload -storepass:env LCJ_KEY_PASS -keypass:env LCJ_KEY_PASS -dname 'CN=Le Cercle des jeux, OU=Publication, O=Loic Tinant, C=FR'
    if ($LASTEXITCODE -ne 0) { throw 'La création de la clé de téléversement a échoué.' }
} finally {
    Remove-Item Env:\LCJ_KEY_PASS -ErrorAction SilentlyContinue
    $password = $null
    $securePassword.Dispose()
}

Write-Output "Clé de téléversement créée dans : $signingDirectory"
Write-Output 'Le mot de passe est protégé par Windows pour ce compte utilisateur. Sauvegardez le fichier JKS dans un endroit sûr et privé.'
