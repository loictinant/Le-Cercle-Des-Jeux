# Compilation Android

Le projet embarque le jeu dans une WebView Android. Le mode solo fonctionne hors ligne et conserve les trophées localement ; les défis France facultatifs demandent Internet et utilisent l’API PHP/MySQL du site. Le manifeste déclare la permission Internet. Les résultats n’apparaissent au classement qu’après acceptation de la politique de confidentialité.

Le script `build.ps1` synchronise les fichiers du jeu principal puis construit un APK de test. Lorsqu’une clé de téléversement est installée dans le profil Windows, il construit aussi l’APK signé et le fichier AAB pour Google Play.

Le package Android est `fr.tinantloic.lecerclejeux`. Avant de créer l’application dans Google Play Console, vérifiez que ce nom est libre et qu’il correspond bien à votre futur identifiant définitif.

L’icône 512 × 512 pour la fiche Play se trouve dans `store-assets/GooglePlayIcon512.png` après la compilation.

La clé Android générée pour ce projet est une clé de téléversement. Google Play App Signing reste nécessaire pour la publication d’une nouvelle application.
