(() => {
  'use strict';

  const MODES = [
    { id: 'sudoku', title: 'Sudoku', icon: '▦', short: 'Les chiffres trouvent leur place.', caption: 'UNE GRILLE, NEUF CHIFFRES', intro: 'Complétez chaque ligne, chaque colonne et chaque carré sans répéter de chiffre.' },
    { id: 'crossword', title: 'Mots croisés', icon: '✳', short: 'Croisez les mots et les idées.', caption: 'LES MOTS SE CROISENT', intro: 'Lisez les définitions, choisissez une case et remplissez les mots qui se croisent.' },
    { id: 'arrows', title: 'Mots fléchés', icon: '↘', short: 'Suivez les flèches jusqu’au mot.', caption: 'SUIVEZ LES FLÈCHES', intro: 'Chaque flèche indique le départ et la direction d’un mot. Complétez toute la grille.' },
    { id: 'search', title: 'Mots mêlés', icon: '⌕', short: 'Retrouvez les mots cachés.', caption: 'CHERCHEZ DANS LA GRILLE', intro: 'Repérez les mots de la liste dans la grille. Ils peuvent se lire dans plusieurs directions.' },
    { id: 'memory', title: 'Mémory', icon: '❋', short: 'Retrouvez les paires cachées.', caption: 'RETROUVEZ LES PAIRES', intro: 'Retournez deux cartes à la fois et rassemblez toutes les paires.' }
  ];

  const WORDS = [
    ['ABEILLE', 'Insecte qui fabrique le miel'], ['ABRICOT', 'Fruit orange d’été'], ['ANANAS', 'Fruit à couronne épineuse'], ['ARDOISE', 'Tablette pour écrire à la craie'],
    ['AROMATE', 'Plante qui parfume un plat'], ['AVION', 'Appareil qui vole'], ['BANANE', 'Fruit jaune en forme de croissant'], ['BATEAU', 'Il navigue sur l’eau'],
    ['BICHE', 'Femelle du cerf'], ['BOUSSOLE', 'Elle indique le nord'], ['CABANE', 'Petite maison dans les bois'], ['CAMPAGNE', 'Paysage de champs et de villages'],
    ['CANARD', 'Oiseau qui nage et fait coin-coin'], ['CAROTTE', 'Légume orange qui pousse en terre'], ['CERISE', 'Petit fruit rouge à noyau'], ['CHEVAL', 'Animal que l’on peut monter'],
    ['CITRON', 'Agrume jaune et acidulé'], ['CLAVIER', 'On y pose les doigts pour écrire'], ['COCCINELLE', 'Petit insecte rouge à points noirs'], ['COQUILLE', 'Enveloppe dure d’un œuf'],
    ['COTON', 'Fibre douce des vêtements'], ['COUTEAU', 'Ustensile pour couper'], ['CRAYON', 'On écrit ou dessine avec lui'], ['CUISINE', 'Pièce où l’on prépare les repas'],
    ['DESSERT', 'Dernier plat du repas'], ['DOMINO', 'Petit jeu de pièces à points'], ['ECUREUIL', 'Petit grimpeur à queue touffue'], ['ECOLE', 'Lieu où les enfants apprennent'],
    ['EPICE', 'Elle relève le goût d’un plat'], ['ETOILE', 'Lumière visible dans le ciel nocturne'], ['FARINE', 'Poudre pour faire du pain'], ['FEUILLE', 'Partie verte d’un arbre'],
    ['FLEUR', 'Elle s’ouvre au printemps'], ['FORET', 'Grand espace couvert d’arbres'], ['FROMAGE', 'Produit laitier affiné'], ['GATEAU', 'Dessert cuit au four'],
    ['GIRAFE', 'Animal au très long cou'], ['GUITARE', 'Instrument à cordes pincées'], ['HIVER', 'Saison la plus froide'], ['JARDIN', 'On y cultive fleurs et légumes'],
    ['JOURNAL', 'On y lit les nouvelles'], ['LANTERNE', 'Lampe portative protégée'], ['LAPIN', 'Animal aux longues oreilles'], ['MELON', 'Fruit d’été à chair sucrée'],
    ['MONTAGNE', 'Sommet que l’on peut gravir'], ['MOUTON', 'Animal qui donne de la laine'], ['MUSIQUE', 'Elle s’écoute et se joue'], ['NUAGE', 'Masse blanche dans le ciel'],
    ['OISEAU', 'Animal à plumes qui vole'], ['ORANGE', 'Agrume rond et coloré'], ['PAPILLON', 'Insecte aux ailes colorées'], ['PARAPLUIE', 'Il protège de la pluie'],
    ['PAYSAGE', 'Vue que l’on découvre au loin'], ['PIMENT', 'Petit fruit qui peut être fort'], ['POMME', 'Fruit croquant du verger'], ['POULE', 'Elle pond des œufs'],
    ['RENARD', 'Animal roux rusé'], ['RIVIERE', 'Cours d’eau qui rejoint un fleuve'], ['SALADE', 'Plat frais souvent vert'], ['SOURIS', 'Petit rongeur ou accessoire d’ordinateur'],
    ['TABLEAU', 'Surface pour écrire ou peindre'], ['TOMATE', 'Fruit rouge souvent utilisé en salade'], ['TORTUE', 'Reptile protégé par une carapace'], ['VALISE', 'On y range ses affaires en voyage'],
    ['VELOURS', 'Tissu doux au toucher'], ['VIOLETTE', 'Petite fleur au parfum délicat'], ['VOYAGE', 'Déplacement vers une autre région'], ['ZEBRE', 'Animal rayé noir et blanc']
  ].map(([word, clue]) => ({ word, clue }));

  const EMOJIS = ['🍋','🌿','🐚','🍓','🪁','🌼','🍐','🦋','🍄','🌙','🐝','🍊','🐢','🪻','🐞','🍇','🌵','🧩','🌻','🦊','🍉','🐌','🪺','🌈'];
  const TROPHIES = [
    { id: 'first', icon: '🌱', title: 'Première grille', description: 'Terminez votre première partie.', category: 'Découverte', tier: 'Bronze', unlocked: () => save.solved >= 1 },
    { id: 'sudoku', icon: '🔢', title: 'Le goût des chiffres', description: 'Terminez un sudoku.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.sudoku || 0) >= 1 },
    { id: 'crossword', icon: '✳️', title: 'Mots croisés', description: 'Terminez une grille de mots croisés.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.crossword || 0) >= 1 },
    { id: 'arrows', icon: '➡️', title: 'Dans la bonne direction', description: 'Terminez une grille de mots fléchés.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.arrows || 0) >= 1 },
    { id: 'search', icon: '🔎', title: 'Œil de lynx', description: 'Trouvez tous les mots cachés.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.search || 0) >= 1 },
    { id: 'memory', icon: '🧠', title: 'Mémoire d’éléphant', description: 'Retrouvez toutes les paires.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.memory || 0) >= 1 },
    { id: 'no-hints', icon: '🧭', title: 'Sans aide', description: 'Terminez une grille à indices sans demander d’indice.', category: 'Défis', tier: 'Argent', unlocked: () => !!game && ['sudoku', 'crossword', 'arrows'].includes(activeMode) && game.hintsUsed === 0 },
    { id: 'perfect', icon: '💎', title: 'Grille parfaite', description: 'Terminez une partie sans erreur signalée.', category: 'Défis', tier: 'Or', unlocked: () => !!game && game.mistakes === 0 },
    { id: 'streak', icon: '🔥', title: 'Belle série', description: 'Terminez cinq parties de suite.', category: 'Assiduité', tier: 'Argent', unlocked: () => save.streak >= 5 },
    { id: 'ten', icon: '🏅', title: 'Régulier', description: 'Terminez dix parties.', category: 'Assiduité', tier: 'Bronze', unlocked: () => save.solved >= 10 },
    { id: 'fifty', icon: '🏆', title: 'Passionné', description: 'Terminez cinquante parties.', category: 'Assiduité', tier: 'Argent', unlocked: () => save.solved >= 50 },
    { id: 'memory-pro', icon: '🎴', title: 'Mémoire affûtée', description: 'Finissez un mémory avec au plus deux essais de plus que le nombre de paires.', category: 'Défis', tier: 'Or', unlocked: () => !!game && activeMode === 'memory' && game.moves <= game.pairs + 2 },
    ...MODES.flatMap(mode => [
      { id: `wins-${mode.id}-5`, icon: mode.icon, title: `${mode.title} assidu`, description: `Terminez 5 parties de ${mode.title.toLowerCase()}.`, category: 'Spécialités', tier: 'Bronze', unlocked: () => (save.modeWins[mode.id] || 0) >= 5 },
      { id: `wins-${mode.id}-25`, icon: '🥈', title: `Expert ${mode.title.toLowerCase()}`, description: `Terminez 25 parties de ${mode.title.toLowerCase()}.`, category: 'Spécialités', tier: 'Argent', unlocked: () => (save.modeWins[mode.id] || 0) >= 25 },
      { id: `wins-${mode.id}-100`, icon: '🏆', title: `Maître ${mode.title.toLowerCase()}`, description: `Terminez 100 parties de ${mode.title.toLowerCase()}.`, category: 'Spécialités', tier: 'Diamant', unlocked: () => (save.modeWins[mode.id] || 0) >= 100 }
    ]),
    ...MODES.map(mode => ({ id: `clean-${mode.id}`, icon: '✨', title: `Sans faute : ${mode.title}`, description: `Terminez une partie de ${mode.title.toLowerCase()} sans erreur signalée.`, category: 'Défis', tier: 'Argent', unlocked: () => (save.cleanWins[mode.id] || 0) >= 1 })),
    ...['sudoku', 'crossword', 'arrows'].map(modeId => ({ id: `no-hint-${modeId}`, icon: '🧭', title: `En autonomie : ${modeInfo(modeId).title}`, description: `Terminez une partie de ${modeInfo(modeId).title.toLowerCase()} sans indice.`, category: 'Défis', tier: 'Argent', unlocked: () => (save.noHintWins[modeId] || 0) >= 1 })),
    ...[25, 100, 250, 500].map(total => ({ id: `total-${total}`, icon: total < 100 ? '🎖️' : '🏅', title: `${total} parties`, description: `Terminez ${total} parties, tous jeux confondus.`, category: 'Assiduité', tier: total < 100 ? 'Argent' : total < 250 ? 'Or' : 'Diamant', unlocked: () => save.solved >= total })),
    ...[3, 10, 25].map(streak => ({ id: `streak-${streak}`, icon: '🔥', title: `Série de ${streak}`, description: `Terminez ${streak} parties d’affilée sans abandonner.`, category: 'Assiduité', tier: streak < 10 ? 'Bronze' : streak < 25 ? 'Or' : 'Diamant', unlocked: () => save.streak >= streak })),
    ...[
      { modeId: 'sudoku', seconds: 300 }, { modeId: 'crossword', seconds: 300 }, { modeId: 'arrows', seconds: 300 },
      { modeId: 'search', seconds: 120 }, { modeId: 'memory', seconds: 180 }
    ].map(challenge => ({ id: `speed-${challenge.modeId}`, icon: '⏱️', title: `Coup de ${modeInfo(challenge.modeId).title.toLowerCase()}`, description: `Terminez ${modeInfo(challenge.modeId).title.toLowerCase()} en ${Math.floor(challenge.seconds / 60)} min maximum.`, category: 'Défis', tier: 'Or', unlocked: () => Number.isFinite(save.fastest[challenge.modeId]) && save.fastest[challenge.modeId] <= challenge.seconds })),
    { id: 'memory-exact', icon: '🃏', title: 'Du premier coup', description: 'Trouvez toutes les paires du mémory sans vous tromper.', category: 'Défis', tier: 'Diamant', unlocked: () => !!game && activeMode === 'memory' && game.moves === game.pairs },
    { id: 'clean-streak-3', icon: '🌟', title: 'Trois parties impeccables', description: 'Terminez trois parties de suite sans erreur signalée.', category: 'Défis', tier: 'Or', unlocked: () => save.cleanStreak >= 3 },
    ...['sudoku', 'crossword', 'arrows'].map(modeId => ({ id: `no-hint-${modeId}-10`, icon: '🧭', title: `Sans indice, toujours : ${modeInfo(modeId).title}`, description: `Terminez 10 parties de ${modeInfo(modeId).title.toLowerCase()} sans utiliser d’indice.`, category: 'Spécialités', tier: 'Diamant', unlocked: () => (save.noHintWins[modeId] || 0) >= 10 }))
  ];
  const SAVE_KEY = 'le-cercle-des-jeux-v1';
  const emptySave = () => ({ levels: {}, solved: 0, streak: 0, bestStreak: 0, lastMode: 'sudoku', trophies: {}, modeWins: {}, cleanWins: {}, noHintWins: {}, fastest: {}, cleanStreak: 0 });
  let save = emptySave();
  try {
    const stored = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}');
    save = { ...emptySave(), ...stored, trophies: { ...emptySave().trophies, ...(stored.trophies || {}) }, modeWins: { ...emptySave().modeWins, ...(stored.modeWins || {}) }, cleanWins: { ...emptySave().cleanWins, ...(stored.cleanWins || {}) }, noHintWins: { ...emptySave().noHintWins, ...(stored.noHintWins || {}) }, fastest: { ...emptySave().fastest, ...(stored.fastest || {}) } };
  } catch (_) { /* Le jeu reste jouable si le navigateur désactive le stockage local. */ }

  const $ = id => document.getElementById(id);
  const homeView = $('homeView'), gameView = $('gameView'), gameGrid = $('gameGrid');
  const boardMount = $('boardMount'), toolsPanel = $('toolsPanel'), feedback = $('boardFeedback');
  let activeMode = null, activeLevel = 1, game = null, timerHandle = null, startedAt = 0, toastHandle = null;
  let activeChallenge = null, challengeRandomState = null;
  let trophyFilter = 'all', trophyNotificationQueue = [], trophyNotificationTimer = null, activeTrophyNotification = null;

  function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (_) { /* Progression conservée en mémoire pour cette session. */ } }
  function modeInfo(id) { return MODES.find(mode => mode.id === id) || MODES[0]; }
  function levelFor(id) { return Math.max(1, Number(save.levels[id]) || 1); }
  function random() {
    if (challengeRandomState === null) return Math.random();
    challengeRandomState = (challengeRandomState + 0x6D2B79F5) >>> 0;
    let value = challengeRandomState;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  }
  function shuffle(list) { const out = [...list]; for (let i = out.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [out[i], out[j]] = [out[j], out[i]]; } return out; }
  function pad(value) { return String(value).padStart(2, '0'); }
  function clockText(seconds) { return `${pad(Math.floor(seconds / 60))}:${pad(seconds % 60)}`; }
  function renderHome() {
    gameGrid.innerHTML = MODES.map(mode => `<button class="game-card" data-game="${mode.id}" aria-label="Lancer ${mode.title}, niveau ${pad(levelFor(mode.id))}">
      <div class="game-card-top"><span class="game-symbol">${mode.icon}</span><span class="card-level">NIVEAU ${pad(levelFor(mode.id))}</span></div>
      <h3>${mode.title}</h3><p>${mode.short}</p><div class="card-footer"><span>∞ &nbsp;Niveaux sans fin</span><span class="card-arrow">↗</span></div>
    </button>`).join('');
    $('solvedCount').textContent = save.solved || 0;
    $('bestStreak').textContent = save.bestStreak || 0;
    renderTrophySummary();
    if (save.solved > 0) {
      $('progressTitle').textContent = `${save.solved} partie${save.solved > 1 ? 's' : ''} terminée${save.solved > 1 ? 's' : ''}`;
      $('progressSub').textContent = `Votre meilleure série : ${save.bestStreak || 0} partie${save.bestStreak === 1 ? '' : 's'}.`;
      $('continueButton').innerHTML = `Continuer au niveau ${pad(levelFor(save.lastMode))} <span>→</span>`;
    }
    renderMiniSudoku();
  }

  function renderMiniSudoku() {
    const digits = ['1','', '3','', '', '4','', '2','2','', '', '1','', '1','4',''];
    $('miniSudoku').innerHTML = digits.map((digit, index) => `<span class="mini-cell ${digit && index % 3 === 0 ? 'accent' : ''}">${digit}</span>`).join('');
  }

  function startGame(modeId, challenge = null) {
    clearInterval(timerHandle);
    activeMode = modeId;
    activeChallenge = challenge ? { ...challenge, mode: modeId } : null;
    challengeRandomState = activeChallenge ? (Number(activeChallenge.seed) >>> 0) : null;
    activeLevel = activeChallenge ? Math.max(1, Number(activeChallenge.level) || 1) : levelFor(modeId); save.lastMode = modeId; persist();
    const info = modeInfo(modeId);
    $('gameIcon').textContent = info.icon; $('gameTitle').textContent = info.title;
    $('gameEyebrow').textContent = `JEU DE RÉFLEXION · ${info.caption}`;
    $('levelLabel').textContent = pad(activeLevel);
    $('boardCaption').textContent = activeChallenge ? `DÉFI FRANCE · ${info.caption}` : info.caption;
    $('timerLabel').textContent = '00:00';
    const challengeStatus = $('challengeResultStatus'); if (challengeStatus) challengeStatus.textContent = '';
    feedback.className = 'feedback'; feedback.textContent = '';
    homeView.classList.add('hidden'); gameView.classList.remove('hidden');
    startedAt = Date.now(); timerHandle = setInterval(() => { $('timerLabel').textContent = clockText(Math.floor((Date.now() - startedAt) / 1000)); }, 1000);
    if (modeId === 'sudoku') makeSudoku();
    if (modeId === 'crossword' || modeId === 'arrows') makeWordGrid(modeId);
    if (modeId === 'search') makeWordSearch();
    if (modeId === 'memory') makeMemory();
    game.hintsUsed = 0; game.mistakes = 0;
    renderTools();
  }

  window.startDailyChallenge = (modeId, challenge) => startGame(modeId, challenge);

  function backHome() {
    clearInterval(timerHandle); activeMode = null; game = null; activeChallenge = null; challengeRandomState = null;
    gameView.classList.add('hidden'); homeView.classList.remove('hidden'); renderHome(); window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function setFeedback(message, kind = '') { feedback.className = `feedback${kind ? ` ${kind}` : ''}`; feedback.textContent = message; }
  function showToast(message) { const el = $('toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastHandle); toastHandle = setTimeout(() => el.classList.remove('show'), 1900); }

  function renderTools() {
    const info = modeInfo(activeMode);
    let specific = '';
    if (activeMode === 'sudoku') specific = `<div class="tool-kicker">VOTRE GRILLE</div><h2>À vous de jouer</h2><p class="tool-copy">Un chiffre de 1 à 9 par ligne, colonne et carré. Sélectionnez une case puis choisissez un chiffre.</p><div class="number-pad">${Array.from({ length: 9 }, (_, i) => `<button class="number-key" data-number="${i + 1}">${i + 1}</button>`).join('')}<button class="number-key erase" data-number="0">Effacer</button></div><div class="tool-actions"><button class="action-button" data-action="hint">Un indice <small>✦</small></button><button class="action-button primary" data-action="check">Vérifier ma grille <span>→</span></button></div><div class="side-note"><b>Le petit conseil</b>Commencez par les lignes ou les carrés qui contiennent déjà le plus de chiffres.</div>`;
    else if (activeMode === 'crossword' || activeMode === 'arrows') specific = `<div class="tool-kicker">LES DÉFINITIONS</div><h2>${activeMode === 'arrows' ? 'Suivez les flèches' : 'Croisez les mots'}</h2><p class="tool-copy">${info.intro} Choisissez une définition ou une case, puis tapez votre réponse.</p><div class="tool-divider"></div><div class="tool-actions"><button class="action-button" data-action="hint">Une lettre en moins à trouver <small>✦</small></button><button class="action-button primary" data-action="check">Vérifier mes réponses <span>→</span></button></div><div class="side-note"><b>À savoir</b>Les cases se croisent : une lettre bien placée peut aider à trouver plusieurs mots.</div>`;
    else if (activeMode === 'search') specific = `<div class="tool-kicker">LES MOTS À TROUVER</div><h2>Ouvrez l’œil</h2><p class="tool-copy">Cliquez sur la première lettre, puis sur la dernière. Les mots peuvent être horizontaux, verticaux ou en diagonale.</p><div class="tool-divider"></div><div class="tool-actions"><button class="action-button" data-action="clearSelection">Effacer la sélection <small>↺</small></button><button class="action-button primary" data-action="check">Voir ma progression <span>→</span></button></div><div class="side-note"><b>Petit indice</b>Une lettre peut appartenir à plusieurs mots cachés.</div>`;
    else specific = `<div class="tool-kicker">VOTRE MÉMOIRE</div><h2>À vous de retrouver</h2><p class="tool-copy">Retournez deux cartes. Si elles sont pareilles, elles restent découvertes. Essayez de vous souvenir de leur place.</p><div class="tool-divider"></div><div class="tool-actions"><button class="action-button" data-action="restart">Mélanger les cartes <small>↺</small></button></div><div class="side-note"><b>Le petit conseil</b>Retournez les cartes tranquillement : rien ne presse.</div>`;
    toolsPanel.innerHTML = specific;
  }

  function finishGame() {
    if (!game || game.finished) return;
    game.finished = true; clearInterval(timerHandle);
    const elapsedSeconds = Math.floor((Date.now() - startedAt) / 1000);
    const completedChallenge = activeChallenge ? { ...activeChallenge } : null;
    save.solved = (save.solved || 0) + 1; save.streak = (save.streak || 0) + 1;
    save.bestStreak = Math.max(save.bestStreak || 0, save.streak);
    save.modeWins[activeMode] = (save.modeWins[activeMode] || 0) + 1;
    save.fastest[activeMode] = Math.min(Number.isFinite(save.fastest[activeMode]) ? save.fastest[activeMode] : Infinity, elapsedSeconds);
    if (game.mistakes === 0) {
      save.cleanWins[activeMode] = (save.cleanWins[activeMode] || 0) + 1;
      save.cleanStreak = (save.cleanStreak || 0) + 1;
    } else save.cleanStreak = 0;
    if (['sudoku', 'crossword', 'arrows'].includes(activeMode) && game.hintsUsed === 0) save.noHintWins[activeMode] = (save.noHintWins[activeMode] || 0) + 1;
    if (!completedChallenge) save.levels[activeMode] = activeLevel + 1;
    persist();
    const unlocked = unlockTrophies();
    persist(); renderTrophySummary();
    feedback.className = 'feedback success';
    const award = unlocked.length ? ` <span class="trophy-win">🏆 ${unlocked.map(trophy => trophy.title).join(' · ')}</span>` : '';
    feedback.innerHTML = `Bravo, niveau ${pad(activeLevel)} terminé !${award} <button class="win-banner-next" data-action="next">Niveau ${pad(activeLevel + 1)} →</button>`;
    feedback.querySelector('button').addEventListener('click', () => startGame(activeMode));
    if (completedChallenge) window.dispatchEvent(new CustomEvent('lcdj:challenge-finished', { detail: { ...completedChallenge, elapsedSeconds, mistakes: game.mistakes || 0, hintsUsed: game.hintsUsed || 0 } }));
    if (unlocked.length) queueTrophyNotifications(unlocked);
  }

  function unlockTrophies() {
    const unlocked = [];
    for (const trophy of TROPHIES) {
      if (!save.trophies[trophy.id] && trophy.unlocked()) { save.trophies[trophy.id] = true; unlocked.push(trophy); }
    }
    return unlocked;
  }

  function renderTrophySummary() {
    const count = TROPHIES.filter(trophy => save.trophies[trophy.id]).length;
    const label = `${count} / ${TROPHIES.length}`;
    $('headerTrophyCount').textContent = label;
    $('homeTrophyCount').textContent = label;
    $('trophyProgressLabel').textContent = label;
    $('trophyModalCount').textContent = label;
    $('trophyProgressBar').style.width = `${Math.round(count / TROPHIES.length * 100)}%`;
  }

  function renderTrophyCollection() {
    renderTrophySummary();
    const visible = TROPHIES.filter(trophy => trophyFilter === 'all' || (trophyFilter === 'earned' ? !!save.trophies[trophy.id] : !save.trophies[trophy.id]));
    const categories = [...new Set(visible.map(trophy => trophy.category))];
    $('trophyGrid').innerHTML = categories.map(category => `<section class="trophy-group"><h3>${category}<small>${visible.filter(trophy => trophy.category === category).length}</small></h3><div class="trophy-group-grid">${visible.filter(trophy => trophy.category === category).map(trophy => {
      const earned = !!save.trophies[trophy.id];
      const tier = trophy.tier.toLowerCase();
      return `<article class="trophy-card ${earned ? 'earned' : 'locked'} tier-${tier}"><span class="trophy-card-icon">${earned ? trophy.icon : '🔒'}</span><span class="trophy-card-copy"><b>${trophy.title}</b><small>${trophy.description}</small></span><span class="trophy-state">${earned ? 'GAGNÉ' : trophy.tier.toUpperCase()}</span></article>`;
    }).join('')}</div></section>`).join('') || '<p class="trophy-empty">Aucun trophée dans cette sélection.</p>';
  }

  function openTrophies() {
    clearTimeout(trophyNotificationTimer);
    $('trophyNotification').classList.add('hidden');
    renderTrophyCollection(); $('trophyOverlay').classList.remove('hidden');
  }
  function closeTrophies() { $('trophyOverlay').classList.add('hidden'); showNextTrophyNotification(); }

  function queueTrophyNotifications(trophies) {
    trophyNotificationQueue.push(...trophies);
    showNextTrophyNotification();
  }

  function showNextTrophyNotification() {
    clearTimeout(trophyNotificationTimer);
    if ($('trophyOverlay') && !$('trophyOverlay').classList.contains('hidden')) return;
    const notification = $('trophyNotification');
    if (!activeTrophyNotification) activeTrophyNotification = trophyNotificationQueue.shift();
    const trophy = activeTrophyNotification;
    if (!trophy) { notification.classList.add('hidden'); return; }
    $('trophyNotificationIcon').textContent = trophy.icon;
    $('trophyNotificationTier').textContent = `TROPHÉE ${trophy.tier.toUpperCase()} DÉBLOQUÉ`;
    $('trophyNotificationTitle').textContent = trophy.title;
    $('trophyNotificationDescription').textContent = trophy.description;
    notification.dataset.tier = trophy.tier.toLowerCase();
    notification.classList.remove('hidden');
    trophyNotificationTimer = setTimeout(() => { activeTrophyNotification = null; showNextTrophyNotification(); }, 4800);
  }

  function dismissTrophyNotification() { clearTimeout(trophyNotificationTimer); activeTrophyNotification = null; $('trophyNotification').classList.add('hidden'); showNextTrophyNotification(); }

  function tryAgainMessage(message) { setFeedback(message, 'error'); save.streak = 0; persist(); }

  // Sudoku — shuffled valid Latin-grid pattern, with a growing number of blanks.
  function countSudokuSolutions(values, limit = 2) {
    const board = values.flat();
    const rows = Array(9).fill(0), cols = Array(9).fill(0), boxes = Array(9).fill(0);
    for (let i = 0; i < 81; i++) if (board[i]) {
      const r = Math.floor(i / 9), c = i % 9, box = Math.floor(r / 3) * 3 + Math.floor(c / 3), bit = 1 << board[i];
      rows[r] |= bit; cols[c] |= bit; boxes[box] |= bit;
    }
    let solutions = 0, nodes = 0, aborted = false;
    function solve() {
      if (solutions >= limit || aborted) return;
      if (++nodes > 24000) { aborted = true; return; }
      let best = -1, bestOptions = 0, bestCount = 10;
      for (let i = 0; i < 81; i++) if (!board[i]) {
        const r = Math.floor(i / 9), c = i % 9, box = Math.floor(r / 3) * 3 + Math.floor(c / 3);
        let options = 1022 & ~(rows[r] | cols[c] | boxes[box]), count = 0;
        for (let bits = options; bits; bits &= bits - 1) count++;
        if (!count) return;
        if (count < bestCount) { best = i; bestOptions = options; bestCount = count; if (count === 1) break; }
      }
      if (best < 0) { solutions++; return; }
      const r = Math.floor(best / 9), c = best % 9, box = Math.floor(r / 3) * 3 + Math.floor(c / 3);
      for (let options = bestOptions; options && solutions < limit && !aborted; options &= options - 1) {
        const bit = options & -options, value = Math.log2(bit);
        board[best] = value; rows[r] |= bit; cols[c] |= bit; boxes[box] |= bit;
        solve();
        board[best] = 0; rows[r] ^= bit; cols[c] ^= bit; boxes[box] ^= bit;
      }
    }
    solve();
    return aborted ? limit : solutions;
  }

  function makeSudoku() {
    const bands = shuffle([0, 1, 2]).flatMap(band => shuffle([0, 1, 2]).map(row => band * 3 + row));
    const stacks = shuffle([0, 1, 2]).flatMap(stack => shuffle([0, 1, 2]).map(col => stack * 3 + col));
    const digits = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    const solution = Array.from({ length: 9 }, (_, r) => Array.from({ length: 9 }, (_, c) => digits[(bands[r] * 3 + Math.floor(bands[r] / 3) + stacks[c]) % 9]));
    const values = solution.map(row => [...row]);
    const targetHoles = Math.min(55, 34 + Math.floor((activeLevel - 1) * 0.7));
    let removed = 0;
    for (const index of shuffle(Array.from({ length: 81 }, (_, i) => i))) {
      if (removed >= targetHoles) break;
      const r = Math.floor(index / 9), c = index % 9, oldValue = values[r][c];
      values[r][c] = 0;
      if (countSudokuSolutions(values) === 1) removed++;
      else values[r][c] = oldValue;
    }
    game = { solution, values, fixed: values.map(row => row.map(value => value !== 0)), selected: 0, finished: false, checked: false };
    renderSudoku();
  }

  function renderSudoku() {
    const g = game, selectedRow = Math.floor(g.selected / 9), selectedCol = g.selected % 9;
    const selectedValue = g.values[selectedRow][selectedCol];
    boardMount.innerHTML = `<div class="sudoku-grid" role="grid" aria-label="Grille de sudoku">${g.values.flatMap((row, r) => row.map((value, c) => {
      const index = r * 9 + c, sameBox = Math.floor(r / 3) === Math.floor(selectedRow / 3) && Math.floor(c / 3) === Math.floor(selectedCol / 3);
      const related = r === selectedRow || c === selectedCol || sameBox;
      const boxValues = g.values.slice(Math.floor(r / 3) * 3, Math.floor(r / 3) * 3 + 3).flatMap(other => other.slice(Math.floor(c / 3) * 3, Math.floor(c / 3) * 3 + 3));
      const duplicate = value && (row.filter(v => v === value).length > 1 || g.values.filter(other => other[c] === value).length > 1 || boxValues.filter(v => v === value).length > 1);
      const wrong = g.checked && value && value !== g.solution[r][c];
      const classes = ['sudoku-cell', g.fixed[r][c] ? 'fixed' : '', related ? 'related' : '', selectedValue && value === selectedValue ? 'same-number' : '', index === g.selected ? 'selected' : '', duplicate ? 'conflict' : '', wrong ? 'wrong' : ''].filter(Boolean).join(' ');
      return `<button class="${classes}" role="gridcell" data-sudoku="${index}" aria-label="Ligne ${r + 1}, colonne ${c + 1}, ${value || 'vide'}">${value || ''}</button>`;
    })).join('')}</div>`;
  }

  function setSudokuValue(value) {
    if (!game || game.finished) return;
    const r = Math.floor(game.selected / 9), c = game.selected % 9;
    if (game.fixed[r][c]) { showToast('Cette case fait partie de la grille.'); return; }
    game.values[r][c] = value; game.checked = false; renderSudoku();
  }

  function checkSudoku() {
    if (game.finished) return;
    const empty = game.values.flat().filter(value => !value).length;
    if (empty) { setFeedback(`Il reste ${empty} case${empty > 1 ? 's' : ''} à remplir.`); return; }
    const errors = game.values.flatMap((row, r) => row.map((value, c) => value === game.solution[r][c] ? null : [r, c])).filter(Boolean);
    if (!errors.length) { finishGame(); return; }
    game.mistakes++; game.checked = true; renderSudoku(); tryAgainMessage(`${errors.length} chiffre${errors.length > 1 ? 's' : ''} à revoir. Les cases en rose sont incorrectes.`);
  }

  function sudokuHint() {
    if (game.finished) return;
    const holes = shuffle(Array.from({ length: 81 }, (_, i) => i).filter(i => !game.values[Math.floor(i / 9)][i % 9]));
    if (!holes.length) { showToast('Toutes les cases sont déjà remplies.'); return; }
    game.selected = holes[0]; const r = Math.floor(game.selected / 9), c = game.selected % 9;
    game.values[r][c] = game.solution[r][c]; game.hintsUsed++; game.checked = false; renderSudoku(); setFeedback('Un chiffre est placé. À vous de continuer !');
  }

  // Crosswords and arrowwords are assembled from a reusable French word bank.
  const keyOf = (r, c) => `${r},${c}`;
  function canPlaceWord(cells, entries, word, dir, r, c) {
    if (entries.some(entry => entry.dir === dir && entry.cells.some(cell => cell.r === r && cell.c === c))) return null;
    let crosses = 0; const points = [];
    for (let i = 0; i < word.length; i++) {
      const rr = r + (dir === 'v' ? i : 0), cc = c + (dir === 'h' ? i : 0), existing = cells.get(keyOf(rr, cc));
      if (existing && existing.letter !== word[i]) return null;
      if (existing) {
        if (entries.some(entry => entry.dir === dir && entry.cells.some(cell => cell.r === rr && cell.c === cc))) return null;
        crosses++;
      } else {
        const sides = dir === 'h' ? [[rr - 1, cc], [rr + 1, cc]] : [[rr, cc - 1], [rr, cc + 1]];
        if (sides.some(([sr, sc]) => cells.has(keyOf(sr, sc)))) return null;
      }
      points.push({ r: rr, c: cc });
    }
    const before = dir === 'h' ? [r, c - 1] : [r - 1, c], after = dir === 'h' ? [r, c + word.length] : [r + word.length, c];
    if (cells.has(keyOf(...before)) || cells.has(keyOf(...after)) || !crosses) return null;
    return { crosses, points };
  }

  function generateCrossword(level) {
    const target = Math.min(10, 5 + Math.floor((level - 1) / 2));
    let best = null;
    for (let attempt = 0; attempt < 110; attempt++) {
      const choices = shuffle(WORDS).slice(0, Math.min(28, WORDS.length));
      const seed = choices.shift();
      const entries = [{ word: seed.word, clue: seed.clue, dir: 'h', r: 0, c: 0, cells: [] }];
      const cells = new Map();
      for (let i = 0; i < seed.word.length; i++) { const point = { r: 0, c: i }; entries[0].cells.push(point); cells.set(keyOf(point.r, point.c), { letter: seed.word[i] }); }
      const remaining = choices.filter(item => item.word !== seed.word);
      while (entries.length < target && remaining.length) {
        const candidates = [];
        for (let wi = 0; wi < remaining.length; wi++) {
          const item = remaining[wi];
          for (const anchor of entries) for (let ai = 0; ai < anchor.word.length; ai++) {
            const anchorPoint = anchor.cells[ai], dir = anchor.dir === 'h' ? 'v' : 'h';
            for (let li = 0; li < item.word.length; li++) if (item.word[li] === anchor.word[ai]) {
              const r = anchorPoint.r - (dir === 'v' ? li : 0), c = anchorPoint.c - (dir === 'h' ? li : 0);
              const placed = canPlaceWord(cells, entries, item.word, dir, r, c);
              if (placed) candidates.push({ wi, item, dir, r, c, ...placed });
            }
          }
        }
        if (!candidates.length) break;
        const topScore = Math.max(...candidates.map(candidate => candidate.crosses));
        const bestFits = candidates.filter(candidate => candidate.crosses === topScore);
        const pick = bestFits[Math.floor(random() * bestFits.length)];
        const entry = { word: pick.item.word, clue: pick.item.clue, dir: pick.dir, r: pick.r, c: pick.c, cells: pick.points };
        entries.push(entry); remaining.splice(pick.wi, 1);
        for (let i = 0; i < entry.word.length; i++) cells.set(keyOf(entry.cells[i].r, entry.cells[i].c), { letter: entry.word[i] });
      }
      if (!best || entries.length > best.entries.length) best = { entries, cells };
      if (best.entries.length >= target) break;
    }
    const entries = best.entries;
    let minR = Infinity, minC = Infinity, maxR = -Infinity, maxC = -Infinity;
    for (const point of best.cells.keys()) { const [r, c] = point.split(',').map(Number); minR = Math.min(minR, r); minC = Math.min(minC, c); maxR = Math.max(maxR, r); maxC = Math.max(maxC, c); }
    for (const entry of entries) { entry.cells = entry.cells.map(point => ({ r: point.r - minR + 1, c: point.c - minC + 1 })); entry.r = entry.cells[0].r; entry.c = entry.cells[0].c; }
    const normalized = new Map();
    for (const entry of entries) entry.cells.forEach((point, index) => normalized.set(keyOf(point.r, point.c), { letter: entry.word[index] }));
    const numbered = new Map(); let nextNumber = 1;
    entries.forEach(entry => { const key = keyOf(entry.r, entry.c); if (!numbered.has(key)) numbered.set(key, nextNumber++); entry.number = numbered.get(key); });
    return { entries, cells: normalized, rows: maxR - minR + 3, cols: maxC - minC + 3, guesses: new Map(), selected: 0, offset: 0, finished: false };
  }

  function makeWordGrid(modeId) {
    game = generateCrossword(activeLevel); game.mode = modeId; renderWordGrid();
  }

  function renderWordGrid() {
    const g = game; const startMap = new Map();
    g.entries.forEach((entry, index) => { const key = keyOf(entry.r, entry.c); if (!startMap.has(key)) startMap.set(key, []); startMap.get(key).push(index); });
    const selected = g.entries[g.selected];
    const cellsHtml = [];
    for (let r = 0; r < g.rows; r++) for (let c = 0; c < g.cols; c++) {
      const key = keyOf(r, c), cell = g.cells.get(key), start = startMap.get(key) || [], selectedHere = selected?.cells.some(point => point.r === r && point.c === c);
      if (!cell) { cellsHtml.push('<span class="word-cell block" aria-hidden="true"></span>'); continue; }
      const number = start.length ? g.entries[start[0]].number : '';
      const arrow = start.length && activeMode === 'arrows' ? `<span class="cell-arrow">${g.entries[start[0]].dir === 'h' ? '→' : '↓'}</span>` : '';
      const value = g.guesses.get(key) || '';
      cellsHtml.push(`<button class="word-cell ${selectedHere ? 'selected-word' : ''} ${g.wrong?.has(key) ? 'wrong-letter' : ''}" data-word-cell="${key}" aria-label="Case ${number || ''} ${value || ''}">${number ? `<span class="cell-num">${number}</span>` : ''}${value}${arrow}</button>`);
    }
    const groups = [['h', activeMode === 'arrows' ? '→ HORIZONTALES' : 'HORIZONTALES'], ['v', activeMode === 'arrows' ? '↓ VERTICALES' : 'VERTICALES']];
    let clueHtml = '';
    for (const [dir, label] of groups) {
      const items = g.entries.map((entry, index) => ({ entry, index })).filter(item => item.entry.dir === dir);
      if (!items.length) continue;
      clueHtml += `<div class="clue-heading">${label}</div>`;
      clueHtml += items.map(({ entry, index }) => `<button class="clue-item ${index === g.selected ? 'active' : ''} ${isEntrySolved(entry) ? 'solved' : ''}" data-entry="${index}"><span class="clue-num">${entry.number}.</span><span class="clue-text">${entry.clue}</span><span class="clue-length">${entry.word.length}</span></button>`).join('');
    }
    boardMount.innerHTML = `<div class="word-layout"><div class="word-board-wrap"><div class="word-grid" style="grid-template-columns:repeat(${g.cols},33px)">${cellsHtml.join('')}</div></div><div class="clue-list">${clueHtml}</div></div>`;
  }

  function isEntrySolved(entry) { return entry.cells.every((point, i) => game.guesses.get(keyOf(point.r, point.c)) === entry.word[i]); }
  function selectEntry(index, offset = 0) { if (game.finished) return; game.selected = index; const entry = game.entries[index]; game.offset = Math.min(offset, entry.word.length - 1); renderWordGrid(); }
  function selectWordCell(key) {
    const entries = game.entries.map((entry, index) => ({ entry, index })).filter(({ entry }) => entry.cells.some(point => keyOf(point.r, point.c) === key));
    if (!entries.length) return;
    const current = entries.findIndex(({ index }) => index === game.selected);
    const pick = entries.length > 1 ? entries[(current + 1) % entries.length] : entries[0];
    const offset = pick.entry.cells.findIndex(point => keyOf(point.r, point.c) === key);
    selectEntry(pick.index, offset);
  }

  function typeWordLetter(letter) {
    if (!game || game.finished) return;
    const entry = game.entries[game.selected]; if (!entry) return;
    while (game.offset < entry.word.length - 1 && entry.cells[game.offset] && game.guesses.get(keyOf(entry.cells[game.offset].r, entry.cells[game.offset].c)) === entry.word[game.offset]) game.offset++;
    const point = entry.cells[game.offset]; game.guesses.set(keyOf(point.r, point.c), letter); game.wrong?.clear();
    if (game.offset < entry.word.length - 1) game.offset++;
    else {
      const next = game.entries.findIndex((candidate, index) => index !== game.selected && !isEntrySolved(candidate));
      if (next >= 0) { game.selected = next; game.offset = 0; }
    }
    if (game.entries.every(isEntrySolved)) { finishGame(); return; }
    renderWordGrid();
  }

  function removeWordLetter() {
    if (!game || game.finished) return;
    const entry = game.entries[game.selected]; if (!entry) return;
    const point = entry.cells[game.offset];
    if (game.guesses.has(keyOf(point.r, point.c))) game.guesses.delete(keyOf(point.r, point.c));
    else if (game.offset > 0) { game.offset--; const prev = entry.cells[game.offset]; game.guesses.delete(keyOf(prev.r, prev.c)); }
    game.wrong?.clear(); renderWordGrid();
  }

  function checkWordGrid() {
    if (game.finished) return;
    const blanks = [...game.cells.keys()].filter(key => !game.guesses.has(key)).length;
    if (blanks) { setFeedback(`Il reste ${blanks} lettre${blanks > 1 ? 's' : ''} à placer.`); return; }
    const wrong = new Set();
    for (const [key, value] of game.cells) if (game.guesses.get(key) !== value.letter) wrong.add(key);
    if (!wrong.size) { finishGame(); return; }
    game.mistakes++; game.wrong = wrong; renderWordGrid(); tryAgainMessage(`${wrong.size} lettre${wrong.size > 1 ? 's' : ''} à revoir. Les cases sont signalées en rose.`);
  }

  function wordHint() {
    if (game.finished) return;
    const entry = game.entries[game.selected];
    for (let offset = 0; offset < entry.word.length; offset++) {
      const point = entry.cells[offset], key = keyOf(point.r, point.c);
      if (game.guesses.get(key) !== entry.word[offset]) { game.guesses.set(key, entry.word[offset]); game.hintsUsed++; game.offset = Math.min(offset + 1, entry.word.length - 1); if (game.entries.every(isEntrySolved)) { finishGame(); return; } renderWordGrid(); setFeedback('Une lettre est placée dans la grille.'); return; }
    }
    setFeedback('Ce mot est déjà complet. Choisissez une autre définition.');
  }

  // Word search — each next level gets a fresh set and a larger challenge over time.
  function makeWordSearch() {
    const count = Math.min(12, 7 + Math.floor((activeLevel - 1) / 4));
    const chosen = shuffle(WORDS).slice(0, count), size = activeLevel > 8 ? 14 : 12;
    const letters = Array.from({ length: size }, () => Array(size).fill(''));
    const dirs = activeLevel >= 3 ? [[0,1],[1,0],[0,-1],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]] : [[0,1],[1,0],[0,-1],[-1,0],[1,1],[-1,-1]];
    const entries = [];
    for (const item of chosen) {
      let placed = false;
      for (let attempt = 0; attempt < 240 && !placed; attempt++) {
        const [dr, dc] = dirs[Math.floor(random() * dirs.length)];
        const r = Math.floor(random() * size), c = Math.floor(random() * size);
        const endR = r + dr * (item.word.length - 1), endC = c + dc * (item.word.length - 1);
        if (endR < 0 || endR >= size || endC < 0 || endC >= size) continue;
        const path = Array.from({ length: item.word.length }, (_, i) => ({ r: r + dr * i, c: c + dc * i }));
        if (path.some((point, i) => letters[point.r][point.c] && letters[point.r][point.c] !== item.word[i])) continue;
        path.forEach((point, i) => { letters[point.r][point.c] = item.word[i]; });
        entries.push({ word: item.word, path, found: false }); placed = true;
      }
    }
    const alphabet = 'ABCDEFGHIJKLMNOPRSTUV';
    letters.forEach(row => row.forEach((value, i) => { if (!value) row[i] = alphabet[Math.floor(random() * alphabet.length)]; }));
    game = { letters, size, entries, first: null, preview: [], finished: false };
    renderWordSearch();
  }

  function renderWordSearch() {
    const found = new Set(game.entries.filter(entry => entry.found).flatMap(entry => entry.path.map(point => keyOf(point.r, point.c))));
    const preview = new Set(game.preview.map(point => keyOf(point.r, point.c)));
    const grid = game.letters.flatMap((row, r) => row.map((letter, c) => {
      const key = keyOf(r, c), classes = ['search-cell', found.has(key) ? 'found' : '', game.first && key === keyOf(game.first.r, game.first.c) ? 'start' : '', preview.has(key) ? 'selected-path' : ''].filter(Boolean).join(' ');
      return `<button class="${classes}" data-search-cell="${key}">${letter}</button>`;
    })).join('');
    const chips = game.entries.map((entry, index) => `<span class="word-chip ${entry.found ? 'found' : ''}" data-word-chip="${index}">${entry.word}</span>`).join('');
    const columns = game.size <= 12 ? 34 : 31;
    boardMount.innerHTML = `<div class="search-layout"><div class="search-grid" style="grid-template-columns:repeat(${game.size},${columns}px)">${grid}</div><div class="word-bank">${chips}</div></div>`;
  }

  function onSearchCell(key) {
    if (game.finished) return;
    const [r, c] = key.split(',').map(Number);
    if (!game.first) { game.first = { r, c }; game.preview = [{ r, c }]; renderWordSearch(); setFeedback('Choisissez maintenant la dernière lettre du mot.'); return; }
    const drRaw = r - game.first.r, dcRaw = c - game.first.c;
    const straight = drRaw === 0 || dcRaw === 0 || Math.abs(drRaw) === Math.abs(dcRaw);
    if (!straight || (drRaw === 0 && dcRaw === 0)) { game.first = { r, c }; game.preview = [{ r, c }]; renderWordSearch(); setFeedback('Le mot doit suivre une ligne droite. Choisissez sa dernière lettre.'); return; }
    const dr = Math.sign(drRaw), dc = Math.sign(dcRaw), length = Math.max(Math.abs(drRaw), Math.abs(dcRaw)) + 1;
    const path = Array.from({ length }, (_, i) => ({ r: game.first.r + dr * i, c: game.first.c + dc * i }));
    const match = game.entries.find(entry => !entry.found && (samePath(entry.path, path) || samePath(entry.path, [...path].reverse())));
    game.first = null; game.preview = [];
    if (match) {
      match.found = true; renderWordSearch(); setFeedback(`Bien trouvé : ${match.word} !`, 'success');
      if (game.entries.every(entry => entry.found)) finishGame();
    } else { game.mistakes++; renderWordSearch(); showToast('Ce n’est pas un mot de la liste.'); }
  }

  function samePath(a, b) { return a.length === b.length && a.every((point, i) => point.r === b[i].r && point.c === b[i].c); }

  // Memory — the number of pairs increases as the levels progress.
  function makeMemory() {
    const pairs = Math.min(12, 4 + Math.floor((activeLevel - 1) / 2));
    const deck = shuffle(EMOJIS).slice(0, pairs).flatMap((emoji, index) => [{ id: `${index}-a`, pair: index, emoji, open: false, matched: false }, { id: `${index}-b`, pair: index, emoji, open: false, matched: false }]);
    game = { cards: shuffle(deck), open: [], moves: 0, pairs, locked: false, finished: false };
    renderMemory();
  }

  function renderMemory() {
    const matched = game.cards.filter(card => card.matched).length / 2;
    boardMount.innerHTML = `<div class="memory-layout"><div class="memory-info"><span>Paires <b>${matched} / ${game.pairs}</b></span><span>Essais <b>${game.moves}</b></span></div><div class="memory-grid">${game.cards.map((card, index) => `<button class="memory-card ${card.open ? 'revealed' : ''} ${card.matched ? 'matched' : ''}" data-memory="${index}" aria-label="Carte ${index + 1}">${card.open || card.matched ? card.emoji : '✦'}</button>`).join('')}</div></div>`;
  }

  function flipMemory(index) {
    if (game.finished || game.locked) return;
    const card = game.cards[index]; if (card.open || card.matched) return;
    card.open = true; game.open.push(index); renderMemory();
    if (game.open.length === 2) {
      game.moves++;
      const [a, b] = game.open.map(i => game.cards[i]);
      if (a.pair === b.pair) {
        a.matched = b.matched = true; game.open = []; renderMemory();
        if (game.cards.every(item => item.matched)) finishGame();
      } else {
        game.mistakes++;
        game.locked = true;
        setTimeout(() => { a.open = b.open = false; game.open = []; game.locked = false; renderMemory(); }, 780);
      }
    }
  }

  function handleAction(action) {
    if (action === 'hint') { if (activeMode === 'sudoku') sudokuHint(); else if (activeMode === 'crossword' || activeMode === 'arrows') wordHint(); }
    if (action === 'check') { if (activeMode === 'sudoku') checkSudoku(); else if (activeMode === 'crossword' || activeMode === 'arrows') checkWordGrid(); else if (activeMode === 'search') setFeedback(`${game.entries.filter(entry => entry.found).length} mot${game.entries.filter(entry => entry.found).length > 1 ? 's' : ''} trouvé${game.entries.filter(entry => entry.found).length > 1 ? 's' : ''} sur ${game.entries.length}.`); }
    if (action === 'clearSelection') { game.first = null; game.preview = []; renderWordSearch(); setFeedback('Sélection effacée.'); }
    if (action === 'restart') { makeMemory(); setFeedback('Les cartes ont été mélangées.'); }
    if (action === 'next') startGame(activeMode);
  }

  gameGrid.addEventListener('click', event => { const button = event.target.closest('[data-game]'); if (button) startGame(button.dataset.game); });
  $('backHome').addEventListener('click', backHome); $('brandHome').addEventListener('click', () => activeMode ? backHome() : window.scrollTo({ top: 0, behavior: 'smooth' }));
  $('continueButton').addEventListener('click', () => {
    if (save.solved > 0) startGame(save.lastMode || 'sudoku');
    else gameGrid.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('openTrophies').addEventListener('click', openTrophies);
  $('openTrophiesBanner').addEventListener('click', openTrophies);
  $('closeTrophies').addEventListener('click', closeTrophies);
  $('trophyFilters').addEventListener('click', event => {
    const button = event.target.closest('[data-filter]');
    if (!button) return;
    trophyFilter = button.dataset.filter;
    $('trophyFilters').querySelectorAll('[data-filter]').forEach(item => item.classList.toggle('active', item === button));
    renderTrophyCollection();
  });
  $('trophyNotificationDismiss').addEventListener('click', dismissTrophyNotification);
  $('trophyNotificationOpen').addEventListener('click', openTrophies);
  $('trophyOverlay').addEventListener('click', event => { if (event.target === $('trophyOverlay')) closeTrophies(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('trophyOverlay').classList.contains('hidden')) closeTrophies(); });
  toolsPanel.addEventListener('click', event => {
    const action = event.target.closest('[data-action]'); if (action) { handleAction(action.dataset.action); return; }
    const number = event.target.closest('[data-number]'); if (number) setSudokuValue(Number(number.dataset.number));
  });

  boardMount.addEventListener('click', event => {
    const sudokuCell = event.target.closest('[data-sudoku]');
    if (sudokuCell && game && !game.finished) { game.selected = Number(sudokuCell.dataset.sudoku); renderSudoku(); return; }
    const wordCell = event.target.closest('[data-word-cell]');
    if (wordCell && game && !game.finished) { selectWordCell(wordCell.dataset.wordCell); return; }
    const clue = event.target.closest('[data-entry]');
    if (clue && game && !game.finished) { selectEntry(Number(clue.dataset.entry)); return; }
    const searchCell = event.target.closest('[data-search-cell]');
    if (searchCell && game && !game.finished) { onSearchCell(searchCell.dataset.searchCell); return; }
    const memoryCard = event.target.closest('[data-memory]');
    if (memoryCard && game) flipMemory(Number(memoryCard.dataset.memory));
  });

  document.addEventListener('keydown', event => {
    if (!activeMode || game?.finished || !$('trophyOverlay').classList.contains('hidden') || event.ctrlKey || event.altKey || event.metaKey) return;
    if (activeMode === 'sudoku') {
      if (/^[1-9]$/.test(event.key)) { setSudokuValue(Number(event.key)); event.preventDefault(); }
      else if (event.key === 'Backspace' || event.key === 'Delete' || event.key === '0') { setSudokuValue(0); event.preventDefault(); }
      else if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key)) { const delta = { ArrowUp: -9, ArrowDown: 9, ArrowLeft: -1, ArrowRight: 1 }[event.key]; game.selected = (game.selected + delta + 81) % 81; renderSudoku(); event.preventDefault(); }
    } else if (activeMode === 'crossword' || activeMode === 'arrows') {
      if (/^[a-zA-Z]$/.test(event.key)) { typeWordLetter(event.key.toUpperCase()); event.preventDefault(); }
      else if (event.key === 'Backspace' || event.key === 'Delete') { removeWordLetter(); event.preventDefault(); }
      else if (event.key === 'ArrowRight' || event.key === 'ArrowDown') { selectEntry((game.selected + 1) % game.entries.length); event.preventDefault(); }
      else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') { selectEntry((game.selected - 1 + game.entries.length) % game.entries.length); event.preventDefault(); }
    }
  });

  delete save.playerName; delete save.onlineWins;
  unlockTrophies(); persist();
  renderHome();
})();
