param(
    [switch]$SkipSigning,
    [string]$BuildLabel = ''
)

$ErrorActionPreference = 'Stop'
$platformRoot = $PSScriptRoot
$platformsRoot = Split-Path -Parent $platformRoot
$gameRoot = Split-Path -Parent $platformsRoot
$repoRoot = Split-Path -Parent $gameRoot
$syncScript = Join-Path $platformsRoot 'Sync-GameFiles.ps1'
$assets = Join-Path $platformRoot 'app\src\main\assets\www'
$toolchainRoot = Join-Path $repoRoot '.toolchain'
$sdkRoot = Join-Path $toolchainRoot 'android-sdk'
$jdkRoot = Get-ChildItem (Join-Path $toolchainRoot 'jdk17') -Directory -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
$gradle = Join-Path $toolchainRoot 'gradle-8.13\bin\gradle.bat'
$outputBase = Join-Path $repoRoot 'deliverables\LeCercleDesJeux\Android'
if ($BuildLabel -and $BuildLabel -notmatch '^[A-Za-z0-9.-]{1,40}$') {
    throw 'Le libellé de compilation doit contenir uniquement des lettres, chiffres, points et tirets.'
}
$outputDir = if ($BuildLabel) { Join-Path $outputBase $BuildLabel } else { $outputBase }
$storeAssets = Join-Path $platformRoot 'store-assets'

if (-not $jdkRoot -or -not (Test-Path $gradle)) {
    throw "Le kit Android local n'est pas installé. Consultez KIT_ANDROID.md."
}

& $syncScript -Destination $assets
& (Join-Path $gameRoot 'Plateformes\WindowsStore\generate-assets.ps1')
New-Item -ItemType Directory -Path $storeAssets -Force | Out-Null
Copy-Item (Join-Path $gameRoot 'Plateformes\WindowsStore\Assets\GooglePlayIcon512.png') (Join-Path $storeAssets 'GooglePlayIcon512.png') -Force
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
$env:JAVA_HOME = $jdkRoot
$env:ANDROID_HOME = $sdkRoot
$env:ANDROID_SDK_ROOT = $sdkRoot
$env:PATH = "$jdkRoot\bin;$sdkRoot\platform-tools;$env:PATH"

Push-Location $platformRoot
try {
    & $gradle --no-daemon --stacktrace assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "La compilation de l'APK de test a échoué." }
    Copy-Item 'app\build\outputs\apk\debug\app-debug.apk' (Join-Path $outputDir 'Le-Cercle-des-jeux-debug.apk') -Force

    if (-not $SkipSigning) {
        $signingDirectory = Join-Path $env:LOCALAPPDATA 'LeCercleDesJeux\AndroidSigning'
        $keystore = Join-Path $signingDirectory 'le-cercle-des-jeux-upload.jks'
        $passwordFile = Join-Path $signingDirectory 'upload-password.dpapi'
        if ((Test-Path $keystore) -and (Test-Path $passwordFile)) {
            $securePassword = Get-Content -LiteralPath $passwordFile -Raw | ConvertTo-SecureString
            $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
            try { $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
            finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
            $env:LCJ_UPLOAD_KEYSTORE = $keystore
            $env:LCJ_UPLOAD_STORE_PASSWORD = $password
            $env:LCJ_UPLOAD_KEY_PASSWORD = $password
            $env:LCJ_UPLOAD_KEY_ALIAS = 'le-cercle-upload'
            try {
                & $gradle --no-daemon --stacktrace bundleRelease assembleRelease
                if ($LASTEXITCODE -ne 0) { throw 'La compilation du paquet signé a échoué.' }
                Copy-Item 'app\build\outputs\bundle\release\app-release.aab' (Join-Path $outputDir 'Le-Cercle-des-jeux.aab') -Force
                Copy-Item 'app\build\outputs\apk\release\app-release.apk' (Join-Path $outputDir 'Le-Cercle-des-jeux-release.apk') -Force
            } finally {
                Remove-Item Env:\LCJ_UPLOAD_KEYSTORE, Env:\LCJ_UPLOAD_STORE_PASSWORD, Env:\LCJ_UPLOAD_KEY_PASSWORD, Env:\LCJ_UPLOAD_KEY_ALIAS -ErrorAction SilentlyContinue
                $password = $null
                $securePassword.Dispose()
            }
        } else {
            Write-Warning "Aucune clé de publication locale ; seul l'APK de test sera produit."
        }
    }
} finally {
    Pop-Location
}

Get-ChildItem $outputDir | Select-Object Name, Length, LastWriteTime
