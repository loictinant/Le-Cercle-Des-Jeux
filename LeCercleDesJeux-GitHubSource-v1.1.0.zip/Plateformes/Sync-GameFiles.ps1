param(
    [Parameter(Mandatory = $true)]
    [string]$Destination
)

$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $PSScriptRoot
$destinationPath = [System.IO.Path]::GetFullPath($Destination)
New-Item -ItemType Directory -Path $destinationPath -Force | Out-Null

foreach ($name in @('index.html', 'style.css', 'details.css', 'app.js', 'multiplayer.css', 'multiplayer.js', 'privacy.html')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $destinationPath $name) -Force
}

$indexPath = Join-Path $destinationPath 'index.html'
$html = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
$footer = '<footer class="home-footer"><span>LE CERCLE DES JEUX <i>·</i> ÉDITION CLASSIQUE</span><span>Progression solo sur cet appareil · défis en ligne facultatifs.</span></footer>'
$footerWithPrivacy = '<footer class="home-footer"><span>LE CERCLE DES JEUX <i>·</i> ÉDITION CLASSIQUE</span><span>Progression solo sur cet appareil · défis en ligne facultatifs.</span><a class="privacy-link" href="privacy.html">Confidentialité</a></footer>'
if ($html.Contains($footer)) { $html = $html.Replace($footer, $footerWithPrivacy) }
[System.IO.File]::WriteAllText($indexPath, $html, (New-Object System.Text.UTF8Encoding($false)))

$cssPath = Join-Path $destinationPath 'style.css'
$css = [System.IO.File]::ReadAllText($cssPath, [System.Text.Encoding]::UTF8)
if ($css -notmatch '\.privacy-link\s*\{') {
    $css += "`n.privacy-link{color:inherit;text-decoration:underline;text-underline-offset:3px}`n"
    [System.IO.File]::WriteAllText($cssPath, $css, (New-Object System.Text.UTF8Encoding($false)))
}
