# Versions Windows Store et Android

Ces projets emballent le jeu original, sans modifier ses fichiers et sans remplacer les deux propositions visuelles conservées dans `Propositions/`.

- `WindowsStore/` : application UWP empaquetée en MSIX.
- `Android/` : APK Android avec mode solo hors ligne et défis France facultatifs en ligne, puis AAB pour Google Play avec la clé de téléversement locale.
- `Sync-GameFiles.ps1` : recopie le jeu, le module des défis et la politique de confidentialité vers les paquets mobiles/boutique.

La progression solo et les trophées internes restent enregistrés sur l’appareil. Le classement quotidien est facultatif et utilise le service PHP/MySQL décrit dans `server/mysql-api/`. Les succès Windows/Xbox ne sont pas activés dans cette version.
