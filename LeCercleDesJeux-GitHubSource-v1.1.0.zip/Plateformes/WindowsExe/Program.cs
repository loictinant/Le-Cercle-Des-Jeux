using System.Diagnostics;
using System.Reflection;
using System.Text.Json;

namespace LeCercleDesJeux.WindowsExe;

internal static class Program
{
    private const string ConfigFileName = "store-launcher.json";
    private const string AssetsResourcePrefix = "LeCercleDesJeux.WebAssets.";

    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        var settings = ReadSettings();
        if (settings.OpenStoreOnStart && IsValidProductId(settings.StoreProductId))
        {
            OpenStoreListing(settings.StoreProductId!);
            return;
        }

        Application.Run(new MainForm(AssetsResourcePrefix));
    }

    private static LauncherSettings ReadSettings()
    {
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, ConfigFileName);
            if (!File.Exists(path))
                return new LauncherSettings();

            return JsonSerializer.Deserialize<LauncherSettings>(
                File.ReadAllText(path),
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new LauncherSettings();
        }
        catch
        {
            return new LauncherSettings();
        }
    }

    private static bool IsValidProductId(string? productId) =>
        productId is { Length: 12 } && productId.All(char.IsLetterOrDigit);

    private static void OpenStoreListing(string productId)
    {
        try
        {
            var uri = $"ms-windows-store://pdp/?ProductId={Uri.EscapeDataString(productId)}";
            Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Impossible d’ouvrir la fiche Microsoft Store.\n\n{ex.Message}",
                "Le Cercle des jeux",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }

    private sealed class LauncherSettings
    {
        public bool OpenStoreOnStart { get; set; }
        public string? StoreProductId { get; set; }
    }
}
