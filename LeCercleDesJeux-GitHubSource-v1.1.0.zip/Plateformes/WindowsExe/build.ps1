param(
    [string]$StoreProductId = '',
    [string]$BuildLabel = ''
)

$ErrorActionPreference = 'Stop'
$exeRoot = $PSScriptRoot
$platformRoot = Split-Path -Parent $exeRoot
$gameRoot = Split-Path -Parent $platformRoot
$repoRoot = Split-Path -Parent $gameRoot
$outputRoot = Join-Path $repoRoot 'deliverables\LeCercleDesJeux\Windows'
$assetsRoot = Join-Path $exeRoot 'www'
$syncScript = Join-Path $platformRoot 'Sync-GameFiles.ps1'

if ($StoreProductId -and $StoreProductId -notmatch '^[A-Za-z0-9]{12}$') {
    throw 'Le Store ID Microsoft doit contenir 12 lettres ou chiffres.'
}
if ($BuildLabel -and $BuildLabel -notmatch '^[A-Za-z0-9.-]{1,40}$') {
    throw 'Le libellé de compilation doit contenir uniquement des lettres, chiffres, points et tirets.'
}

$isStoreLauncher = -not [string]::IsNullOrWhiteSpace($StoreProductId)
$variantName = if ($isStoreLauncher) { 'StoreLauncher' } else { 'Essai' }
$exeName = if ($isStoreLauncher) { 'LeCercleDesJeux.exe' } else { 'LeCercleDesJeux-Essai.exe' }
$variantFolder = if ($BuildLabel) { "$variantName-$BuildLabel" } else { $variantName }
$variantDir = Join-Path $outputRoot $variantFolder
New-Item -ItemType Directory -Path $variantDir -Force | Out-Null

& $syncScript -Destination $assetsRoot

$indexPath = Join-Path $assetsRoot 'index.html'
$html = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
$trophyIntro = '<p class="trophy-intro">Chaque trophée récompense une étape de votre parcours. Ils sont conservés sur cet appareil.</p>'
$trialNotice = "<p class=`"trophy-intro platform-trophy-note`">Cette collection reste locale à cette version d’essai. Les succès Windows Store et les trophées Android seront réservés à leurs versions officielles et resteront distincts.</p>"
if (-not $html.Contains($trophyIntro)) { throw 'Le texte de la collection de trophees est introuvable pour ajouter la note de version.' }
$html = $html.Replace($trophyIntro, $trophyIntro + $trialNotice)
[System.IO.File]::WriteAllText($indexPath, $html, (New-Object System.Text.UTF8Encoding($false)))

$cssPath = Join-Path $assetsRoot 'style.css'
$css = [System.IO.File]::ReadAllText($cssPath, [System.Text.Encoding]::UTF8)
$css += "`n.platform-trophy-note{margin-top:10px;padding:10px 12px;border-left:3px solid #a78954;background:#f2eee4;border-radius:4px;font-size:.9rem;color:#59635d}`n"
[System.IO.File]::WriteAllText($cssPath, $css, (New-Object System.Text.UTF8Encoding($false)))

$settings = @{
    edition = if ($isStoreLauncher) { 'store-launcher' } else { 'trial' }
    openStoreOnStart = $isStoreLauncher
    storeProductId = if ($isStoreLauncher) { $StoreProductId } else { '' }
} | ConvertTo-Json
[System.IO.File]::WriteAllText((Join-Path $variantDir 'store-launcher.json'), $settings, (New-Object System.Text.UTF8Encoding($false)))

$publishArgs = @(
    'publish',
    (Join-Path $exeRoot 'LeCercleDesJeux.WindowsExe.csproj'),
    '--configuration', 'Release',
    '--runtime', 'win-x64',
    '--self-contained', 'true',
    '--output', $variantDir,
    '-p:PublishSingleFile=true',
    '-p:IncludeNativeLibrariesForSelfExtract=true',
    ("-p:AssetsRoot=$assetsRoot"),
    ("-p:AssemblyName=" + [System.IO.Path]::GetFileNameWithoutExtension($exeName))
)
& dotnet @publishArgs
if ($LASTEXITCODE -ne 0) { throw 'La compilation du fichier EXE a échoué.' }

$readmePath = Join-Path $variantDir 'LIRE-MOI.txt'
if ($isStoreLauncher) {
    @'
LE CERCLE DES JEUX — LANCEUR MICROSOFT STORE

Au démarrage, cet EXE ouvre la fiche Microsoft Store configurée pour le jeu.
La fiche ne sera accessible qu’après publication de l’application.
'@ | Set-Content -LiteralPath $readmePath -Encoding UTF8
} else {
    @'
LE CERCLE DES JEUX — VERSION D’ESSAI POUR WINDOWS

1. Extrayez ce dossier, puis ouvrez LeCercleDesJeux-Essai.exe.
2. Le mode solo fonctionne sans Internet. Les défis France demandent une connexion et l’API du site doit être configurée.
3. Si Windows indique que WebView2 manque, installez le Runtime WebView2 de Microsoft puis relancez l’EXE.

La progression et les trophées de cette version d’essai sont enregistrés localement sur ce PC.
Les succès Windows Store et les trophées Android seront intégrés séparément dans leurs versions officielles.
'@ | Set-Content -LiteralPath $readmePath -Encoding UTF8
}

$archivePath = Join-Path $outputRoot ("LeCercleDesJeux-$variantFolder.zip")
Compress-Archive -Path (Join-Path $variantDir '*') -DestinationPath $archivePath -CompressionLevel Optimal -Force

Write-Host "EXE : $(Join-Path $variantDir $exeName)"
Write-Host "Dossier complet : $archivePath"
Get-Item (Join-Path $variantDir $exeName), $archivePath | Select-Object FullName, Length
