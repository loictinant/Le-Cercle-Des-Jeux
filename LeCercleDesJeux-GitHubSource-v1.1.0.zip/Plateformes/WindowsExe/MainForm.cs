using System.Diagnostics;
using System.Reflection;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace LeCercleDesJeux.WindowsExe;

internal sealed class MainForm : Form
{
    private const string VirtualHostName = "lecercle.local";
    private readonly string _resourcePrefix;
    private readonly WebView2 _browser = new();
    private readonly Label _status = new();

    public MainForm(string resourcePrefix)
    {
        _resourcePrefix = resourcePrefix;
        Text = "Le Cercle des jeux — version d’essai";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(960, 680);
        Size = new Size(1360, 900);
        BackColor = Color.FromArgb(246, 243, 235);

        _status.Text = "Ouverture du jeu…";
        _status.Dock = DockStyle.Fill;
        _status.TextAlign = ContentAlignment.MiddleCenter;
        _status.Font = new Font("Segoe UI", 12F);
        _status.ForeColor = Color.FromArgb(49, 93, 78);
        Controls.Add(_status);

        _browser.Dock = DockStyle.Fill;
        _browser.Visible = false;
        Controls.Add(_browser);
        _browser.BringToFront();
        Load += OnLoad;
    }

    private async void OnLoad(object? sender, EventArgs e)
    {
        try
        {
            var assetsFolder = ExtractWebAssets();
            var localData = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "LeCercleDesJeux",
                "Essai");
            var profileFolder = Path.Combine(localData, "WebView2");
            Directory.CreateDirectory(profileFolder);

            var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: profileFolder);
            await _browser.EnsureCoreWebView2Async(environment);
            _browser.CoreWebView2.SetVirtualHostNameToFolderMapping(
                VirtualHostName,
                assetsFolder,
                CoreWebView2HostResourceAccessKind.Allow);
            _browser.CoreWebView2.NavigationStarting += OnNavigationStarting;
            _browser.Source = new Uri($"https://{VirtualHostName}/index.html");

            _status.Visible = false;
            _browser.Visible = true;
            _browser.BringToFront();
        }
        catch (WebView2RuntimeNotFoundException)
        {
            ShowStartupError(
                "Le composant d’affichage WebView2 est absent de ce PC. Installez le Runtime WebView2 de Microsoft, puis relancez cet EXE.");
        }
        catch (Exception ex)
        {
            ShowStartupError($"Le jeu n’a pas pu démarrer.\n\n{ex.Message}");
        }
    }

    private string ExtractWebAssets()
    {
        var assembly = Assembly.GetExecutingAssembly();
        var files = assembly.GetManifestResourceNames()
            .Where(name => name.StartsWith(_resourcePrefix, StringComparison.Ordinal))
            .ToArray();
        if (files.Length == 0)
            throw new InvalidOperationException("Les fichiers du jeu sont absents de cet EXE.");

        var target = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "LeCercleDesJeux",
            "Essai",
            "www");
        Directory.CreateDirectory(target);

        foreach (var resourceName in files)
        {
            var fileName = resourceName[_resourcePrefix.Length..];
            using var source = assembly.GetManifestResourceStream(resourceName)
                ?? throw new InvalidOperationException($"Impossible de lire la ressource {fileName}.");
            using var destination = File.Create(Path.Combine(target, fileName));
            source.CopyTo(destination);
        }

        return target;
    }

    private static void OnNavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        if (Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri) &&
            uri.Host.Equals(VirtualHostName, StringComparison.OrdinalIgnoreCase))
            return;

        e.Cancel = true;
        try
        {
            Process.Start(new ProcessStartInfo(e.Uri) { UseShellExecute = true });
        }
        catch
        {
            // Unsupported external links stay in the app without interrupting play.
        }
    }

    private void ShowStartupError(string message)
    {
        _status.Text = message;
        _status.ForeColor = Color.FromArgb(150, 54, 45);
        _status.Padding = new Padding(40);
        _status.Font = new Font("Segoe UI", 11F);
        MessageBox.Show(message, "Le Cercle des jeux — version d’essai", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        Close();
    }
}
