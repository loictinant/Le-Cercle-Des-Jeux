using Windows.UI.Xaml.Controls;

namespace LeCercleDesJeux.Windows
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
