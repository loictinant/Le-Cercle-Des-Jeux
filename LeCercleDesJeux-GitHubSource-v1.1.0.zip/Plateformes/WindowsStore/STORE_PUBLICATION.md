# Version Windows Store

Le projet est une application UWP empaquetée en MSIX. Le mode solo reste utilisable hors ligne ; les défis France facultatifs nécessitent Internet et le service PHP/MySQL décrit dans `server/mysql-api/`. La participation au classement demande un accord explicite dans le jeu. Le projet ne remplace pas les deux propositions visuelles conservées dans `Propositions/`.

Le manifeste reprend l’éditeur utilisé par vos autres applications (`TINANT LOIC`, certificat `CN=D67E21A8-DC00-45EF-86D1-375158FB659F`). Le nom d’identité proposé est `TINANTLOIC.LeCercleDesJeux` ; vérifiez qu’il correspond à l’identité affichée dans Partner Center après avoir réservé le nom. Le package local signé est destiné au développement ; Microsoft re-signe les packages acceptés pour la distribution Store.

Le script `build.ps1` synchronise le jeu de base et produit les packages dans `deliverables/LeCercleDesJeux/Windows`. La progression et les trophées solo restent locaux ; les scores du défi sont envoyés au service en ligne quand il est configuré. Les succès Xbox ne sont pas activés dans cette version.
