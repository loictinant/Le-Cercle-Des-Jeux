$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$assets = Join-Path $PSScriptRoot 'Assets'
New-Item -ItemType Directory -Path $assets -Force | Out-Null
$master = New-Object System.Drawing.Bitmap 512, 512, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$graphics = [System.Drawing.Graphics]::FromImage($master)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$graphics.Clear([System.Drawing.Color]::FromArgb(24, 62, 58))

$back = New-Object System.Drawing.Rectangle 28, 28, 456, 456
$backPath = New-Object System.Drawing.Drawing2D.GraphicsPath
$radius = 92
$backPath.AddArc($back.X, $back.Y, $radius, $radius, 180, 90)
$backPath.AddArc($back.Right - $radius, $back.Y, $radius, $radius, 270, 90)
$backPath.AddArc($back.Right - $radius, $back.Bottom - $radius, $radius, $radius, 0, 90)
$backPath.AddArc($back.X, $back.Bottom - $radius, $radius, $radius, 90, 90)
$backPath.CloseFigure()
$backgroundBrush = [System.Drawing.Drawing2D.LinearGradientBrush]::new($back, [System.Drawing.Color]::FromArgb(49, 93, 78), [System.Drawing.Color]::FromArgb(25, 60, 62), 45)
$graphics.FillPath($backgroundBrush, $backPath)

$tileColors = @(
    [System.Drawing.Color]::FromArgb(232, 240, 220), [System.Drawing.Color]::FromArgb(246, 243, 235), [System.Drawing.Color]::FromArgb(217, 187, 119),
    [System.Drawing.Color]::FromArgb(246, 243, 235), [System.Drawing.Color]::FromArgb(201, 131, 82), [System.Drawing.Color]::FromArgb(246, 243, 235),
    [System.Drawing.Color]::FromArgb(217, 187, 119), [System.Drawing.Color]::FromArgb(246, 243, 235), [System.Drawing.Color]::FromArgb(232, 240, 220)
)
$start = 102
$tileSize = 88
$gap = 18
for ($row = 0; $row -lt 3; $row++) {
    for ($column = 0; $column -lt 3; $column++) {
        $index = $row * 3 + $column
        $x = $start + $column * ($tileSize + $gap)
        $y = $start + $row * ($tileSize + $gap)
        $tileRect = New-Object System.Drawing.Rectangle ($x), ($y + 7), $tileSize, $tileSize
        $tilePath = New-Object System.Drawing.Drawing2D.GraphicsPath
        $r = 20
        $tilePath.AddArc($tileRect.X, $tileRect.Y, $r, $r, 180, 90)
        $tilePath.AddArc($tileRect.Right - $r, $tileRect.Y, $r, $r, 270, 90)
        $tilePath.AddArc($tileRect.Right - $r, $tileRect.Bottom - $r, $r, $r, 0, 90)
        $tilePath.AddArc($tileRect.X, $tileRect.Bottom - $r, $r, $r, 90, 90)
        $tilePath.CloseFigure()
        $shadow = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(42, 6, 23, 21))
        $graphics.FillPath($shadow, $tilePath)
        $actualRect = New-Object System.Drawing.Rectangle $x, $y, $tileSize, $tileSize
        $tileEnd = [System.Drawing.Color]::FromArgb([Math]::Max(0, $tileColors[$index].R - 20), [Math]::Max(0, $tileColors[$index].G - 20), [Math]::Max(0, $tileColors[$index].B - 20))
        $tileBrush = [System.Drawing.Drawing2D.LinearGradientBrush]::new($actualRect, $tileColors[$index], $tileEnd, 45)
        $graphics.FillPath($tileBrush, $tilePath)
        $tileBrush.Dispose(); $shadow.Dispose(); $tilePath.Dispose()
    }
}

$sparkle = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(245, 217, 187, 119)), 7
$sparkle.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
$sparkle.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
$graphics.DrawLine($sparkle, 395, 84, 395, 122)
$graphics.DrawLine($sparkle, 376, 103, 414, 103)
$sparkle.Dispose()

function Save-ScaledPng([System.Drawing.Bitmap]$Source, [string]$Path, [int]$Width, [int]$Height) {
    $bitmap = New-Object System.Drawing.Bitmap $Width, $Height, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bitmap)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.DrawImage($Source, 0, 0, $Width, $Height)
    $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bitmap.Dispose()
}

Save-ScaledPng $master (Join-Path $assets 'StoreLogo.png') 50 50
Save-ScaledPng $master (Join-Path $assets 'GooglePlayIcon512.png') 512 512
Save-ScaledPng $master (Join-Path $assets 'Square44x44Logo.png') 44 44
Save-ScaledPng $master (Join-Path $assets 'Square44x44Logo.targetsize-24_altform-unplated.png') 24 24
Save-ScaledPng $master (Join-Path $assets 'Square150x150Logo.png') 150 150
Save-ScaledPng $master (Join-Path $assets 'Square310x310Logo.png') 310 310
Save-ScaledPng $master (Join-Path $assets 'Wide310x150Logo.png') 310 150
Save-ScaledPng $master (Join-Path $assets 'SplashScreen.png') 620 300

$graphics.Dispose(); $master.Dispose(); $backgroundBrush.Dispose(); $backPath.Dispose()
