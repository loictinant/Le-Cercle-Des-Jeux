# Le Cercle des jeux — version 1.5.0

Jeu de réflexion en français : sudoku, mots croisés, mots fléchés, mots mêlés et mémory. Le mode solo fonctionne hors connexion. Les classements et comptes en ligne sont facultatifs.

## Nouveautés 1.5.0

- Les mots fléchés affichent maintenant leurs définitions et flèches dans la grille ; les mots croisés gardent leurs définitions à côté.
- Les classements solo sont filtrés par jeu, difficulté, pays ou monde.
- Scores par niveau, difficulté et identifiants des trophées sont enregistrés dans MySQL avec le compte joueur.
- L’historique des défis quotidiens reste en base tant que le compte existe ; phpMyAdmin permet de consulter ou exporter ces données.
- Le partage public des trophées reste facultatif ; désactiver le partage masque le classement sans effacer les données du compte.
- Ajout de la migration MySQL `migration-v1.5.0.sql` et du guide phpMyAdmin `GUIDE-ACCES-BASE-MYSQL.md`.
- Réglage de difficulté Tranquille, Classique ou Expert, avec des grilles adaptées dans les cinq jeux.
- Sauvegarde automatique de la partie en cours et reprise depuis l’accueil.
- Réglages d’accessibilité : texte agrandi, contraste renforcé et meilleure navigation au clavier.
- Banque de mots français enrichie et progression de niveau expliquée.
- 60 trophées internes à l’application. Ils ne sont pas des succès Xbox/Windows Store ni des trophées Android.

## Jouer

Ouvrez `index.html` dans un navigateur ou lancez `Lancer-Le-Cercle.bat`. La partie en cours et la progression hors ligne restent sur l’appareil. Les scores envoyés au classement et les trophées du compte sont enregistrés dans MySQL.

## Défis quotidiens et comptes facultatifs

La grille quotidienne est commune. Le jeu peut estimer le pays via l’adresse IP et proposer un classement par pays ou mondial. La participation est facultative : le joueur choisit son pseudo et peut créer un compte avec adresse e-mail vérifiée pour le récupérer. Le GPS n’est pas utilisé.

Pour installer le serveur, suivre `server/mysql-api/README.md`. Les identifiants MySQL doivent rester dans `config.php` sur l’hébergement et ne figurent pas dans cette archive publique.

Les joueurs qui acceptent la politique du compte peuvent envoyer les niveaux solo terminés et choisir un classement par jeu et difficulté. Le profil permet de modifier ou supprimer le compte. Le partage public des trophées est distinct et facultatif ; s’il est activé, le pseudo et les totaux bronze, argent, or et diamant sont visibles au classement.

L’envoi et la récupération de compte par e-mail exigent un fournisseur SMTP configuré dans le fichier privé `config.php` de l’hébergement. Les paramètres du fournisseur ne sont pas inclus dans le jeu.

## Sauvegardes et réglages

La sauvegarde manuelle et les boutons Exporter/Importer permettent de conserver ou restaurer une partie localement. Le thème clair ou foncé se choisit dans la barre du haut. Les trophées affichent leur progression et leur pourcentage.

## Plateformes

- `Plateformes/WindowsExe/` : version d’essai Windows.
- `Plateformes/WindowsStore/` : projet et paquet Windows Store.
- `Plateformes/Android/` : projet Android et instructions de compilation.
- `Propositions/` : les deux présentations visuelles alternatives, conservées séparément.

La politique de confidentialité est dans `privacy.html`. Les clés de signature ne sont pas incluses.
