# Défis France — installation PHP/MySQL

Le service fournit une grille quotidienne identique à tous les joueurs en France et un classement asynchrone par jeu. Il nécessite PHP 8.2+, l’extension PDO MySQL et un site accessible en HTTPS.

## Étapes d’installation

1. Dans le panneau de ton hébergeur, crée une base MySQL et un utilisateur avec les droits de lecture, écriture et création/modification de tables (`SELECT`, `INSERT`, `UPDATE`, `DELETE`, `CREATE`, `ALTER`, `INDEX` et `REFERENCES`) sur cette base.
2. Importe `schema.sql` dans cette base neuve avec phpMyAdmin. Pour une base déjà en version 1.4.0, fais une sauvegarde puis importe `migration-v1.5.0.sql` une seule fois. Pour une base 1.3.0, applique `migration-v1.4.0.sql`, puis `migration-v1.5.0.sql`. Pour une base 1.1/1.2, applique dans l’ordre `migration-v1.3.0.sql`, `migration-v1.4.0.sql` et `migration-v1.5.0.sql`.
3. Téléverse les dossiers et fichiers du paquet dans `public_html/lecercle-api/`. Le point d’entrée sera `public_html/lecercle-api/v1/index.php`.
4. Dans le gestionnaire de fichiers de l’hébergeur, copie `config.example.php` sous le nom `config.php`. Remplis le nom de la base, l’hôte, l’utilisateur et le mot de passe MySQL de ton hébergeur. Remplace `challenge_secret` par une longue valeur aléatoire privée d’au moins 32 caractères. `ip_geolocation_enabled` active la détection approximative par IP via ipapi.co si le serveur ne fournit pas déjà un code pays.
5. Pour les codes de protection/récupération du compte, récupère dans le panneau de ton fournisseur e-mail le serveur SMTP, le port, la sécurité TLS/SSL, l’identifiant et le mot de passe d’application. Dans `config.php`, garde `mail_transport` à `smtp`, puis renseigne `mail_from`, `smtp_host`, `smtp_port`, `smtp_security`, `smtp_username` et `smtp_password`. Le port 587 utilise normalement STARTTLS (`tls`), et le port 465 le TLS direct (`ssl`). Utilise un mot de passe d’application dédié si le fournisseur le propose. Le jeu affiche un état explicite tant que ces paramètres ne sont pas configurés.
6. Ne publie jamais `config.php` ni les identifiants MySQL ou SMTP sur GitHub et ne les envoie pas dans le chat. Le fichier `.htaccess` bloque l’accès public à la configuration et au schéma SQL.
7. Vérifie que `pdo_mysql` est disponible et que le site a un certificat HTTPS valide.

## XAMPP déjà configuré pour envoyer des e-mails

Si XAMPP utilise déjà `sendmail.exe` pour une autre application PHP, le jeu peut réutiliser la fonction native `mail()` : ajoute `mail_transport => 'php'` et une adresse `mail_from` valide au `config.php` privé. Le jeu ne reçoit pas les identifiants SMTP.

Si l’autre application configure son serveur SMTP dans son propre code, ces paramètres ne sont pas partagés automatiquement. Copie les paramètres SMTP dans le `config.php` privé du jeu et conserve `mail_transport => 'smtp'`. Voir `INSTALLATION-XAMPP-SMTP.txt` et `config.xampp.example.php`.

Le jeu appelle cette adresse :

`https://loic-apps.duckdns.org/lecercle-api/v1/index.php`

Après l’installation, ouvre cette adresse avec `?action=challenge&mode=sudoku`. La réponse doit contenir `"ok":true`, la date, le niveau et la graine du défi. Ensuite, ouvre le jeu, choisis un pseudo, coche la participation et crée le profil : cela vérifie la connexion à MySQL.

L’API annonce ses capacités dans `features` de `?action=challenges`. Pour la version 1.5.0, importe d’abord la migration puis remplace `v1/index.php`. Les classements solo par difficulté et l’enregistrement détaillé des trophées s’activent après détection des tables et colonnes requises. Les profils déjà présents doivent accepter la nouvelle politique dans le jeu avant l’envoi des résultats et des trophées.

## Données et durée

- Le joueur choisit un pseudo unique de 3 à 20 lettres, chiffres, tirets ou tirets bas, seulement après le choix explicite de participer. Il peut le modifier depuis le jeu.
- La date de participation et la version de la politique acceptée sont conservées avec le profil.
- Le jeton d’accès est conservé dans le stockage local du jeu ; seule son empreinte SHA-256 est gardée en base.
- Les défis quotidiens enregistrent le jeu, la date, le meilleur temps, les aides et les erreurs dans `daily_scores`. L’historique est conservé tant que le compte existe.
- Les niveaux solo conservent le meilleur temps de chaque joueur, jeu, difficulté et niveau dans `career_scores`. Les classements peuvent être filtrés par jeu et par difficulté.
- Les totaux de trophées et leur visibilité sont stockés dans `players`. Les identifiants des trophées individuels et leur date de premier enregistrement sur le serveur sont conservés dans `player_trophies`, même si le joueur ne partage pas publiquement son classement.
- Les profils sans e-mail vérifié et sans activité depuis 12 mois sont purgés automatiquement. Un compte avec e-mail vérifié est conservé jusqu’à sa suppression depuis le jeu. La suppression d’un compte efface ses scores et trophées associés.
- La suppression du pseudo depuis le jeu supprime immédiatement le profil et ses scores associés.

Le pseudo et le temps sont visibles sur le classement du jour ; le pseudo et la progression sont visibles sur les classements solo par jeu, difficulté, pays ou monde. Le code pays est estimé à partir de l’IP ; cette estimation n’est pas précise dans tous les cas. Si le partage des trophées est activé séparément, le pseudo et les totaux par niveau sont visibles dans les classements de trophées. L’adresse e-mail est enregistrée uniquement après vérification et sert à récupérer le compte. L’hébergeur peut traiter l’adresse IP dans ses journaux selon sa configuration.

Pour retrouver facilement les données dans phpMyAdmin, consulte `GUIDE-ACCES-BASE-MYSQL.md`.

## Limites du premier prototype

Les résultats sont envoyés par le client après la partie. Le serveur protège les requêtes SQL et les jetons, mais ne rejoue pas la grille pour vérifier le résultat ; un joueur peut donc falsifier un score. Le classement convient aux défis amicaux, sans prix ni récompense.

Les défis sont asynchrones : chacun joue quand il veut. Il n’y a ni salon en direct ni WebSocket. Le mode solo ne dépend pas de cette API.
