CREATE TABLE IF NOT EXISTS players (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nickname VARCHAR(20) NOT NULL,
  token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  country_code CHAR(2) CHARACTER SET ascii COLLATE ascii_bin NULL,
  email VARCHAR(254) NULL,
  email_verified_at DATETIME NULL,
  pending_email VARCHAR(254) NULL,
  email_code_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
  email_expires DATETIME NULL,
  email_sent_at DATETIME NULL,
  email_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  recovery_code_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
  recovery_expires DATETIME NULL,
  recovery_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  share_trophies TINYINT(1) NOT NULL DEFAULT 0,
  trophy_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  trophy_bronze SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  trophy_silver SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  trophy_gold SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  trophy_diamond SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL,
  consented_at DATETIME NOT NULL,
  consent_version VARCHAR(32) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_players_token_hash (token_hash),
  UNIQUE KEY uq_players_nickname (nickname),
  UNIQUE KEY uq_players_email (email),
  KEY ix_players_country_trophies (country_code, share_trophies, trophy_count),
  KEY ix_players_country_trophy_bronze (country_code, share_trophies, trophy_bronze),
  KEY ix_players_country_trophy_silver (country_code, share_trophies, trophy_silver),
  KEY ix_players_country_trophy_gold (country_code, share_trophies, trophy_gold),
  KEY ix_players_country_trophy_diamond (country_code, share_trophies, trophy_diamond),
  KEY ix_players_last_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS career_scores (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  player_id BIGINT UNSIGNED NOT NULL,
  game_mode ENUM('sudoku','crossword','arrows','search','memory') NOT NULL,
  difficulty ENUM('relaxed','normal','expert') NOT NULL DEFAULT 'normal',
  level INT UNSIGNED NOT NULL,
  best_seconds INT UNSIGNED NOT NULL,
  hints_used SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  mistakes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  ranking_key BIGINT UNSIGNED NOT NULL,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_player_career_level_difficulty (player_id, game_mode, difficulty, level),
  KEY ix_career_leaderboard (game_mode, difficulty, level, ranking_key),
  CONSTRAINT fk_career_scores_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS player_trophies (
  player_id BIGINT UNSIGNED NOT NULL,
  trophy_id VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (player_id, trophy_id),
  KEY ix_player_trophies_id (trophy_id),
  CONSTRAINT fk_player_trophies_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS daily_scores (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  player_id BIGINT UNSIGNED NOT NULL,
  challenge_date DATE NOT NULL,
  game_mode ENUM('sudoku','crossword','arrows','search','memory') NOT NULL,
  best_seconds INT UNSIGNED NOT NULL,
  hints_used SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  mistakes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  ranking_key BIGINT UNSIGNED NOT NULL,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_player_daily_mode (player_id, challenge_date, game_mode),
  KEY ix_daily_leaderboard (challenge_date, game_mode, ranking_key),
  CONSTRAINT fk_daily_scores_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
