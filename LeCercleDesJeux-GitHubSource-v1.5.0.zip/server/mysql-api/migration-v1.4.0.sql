-- À exécuter une seule fois sur une base déjà en service en version 1.3.0.
-- Exporter une sauvegarde de la base avant l'import.
ALTER TABLE players
  ADD COLUMN trophy_bronze SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER trophy_count,
  ADD COLUMN trophy_silver SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER trophy_bronze,
  ADD COLUMN trophy_gold SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER trophy_silver,
  ADD COLUMN trophy_diamond SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER trophy_gold,
  ADD KEY ix_players_country_trophy_bronze (country_code, share_trophies, trophy_bronze),
  ADD KEY ix_players_country_trophy_silver (country_code, share_trophies, trophy_silver),
  ADD KEY ix_players_country_trophy_gold (country_code, share_trophies, trophy_gold),
  ADD KEY ix_players_country_trophy_diamond (country_code, share_trophies, trophy_diamond);

CREATE TABLE career_scores (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  player_id BIGINT UNSIGNED NOT NULL,
  game_mode ENUM('sudoku','crossword','arrows','search','memory') NOT NULL,
  level INT UNSIGNED NOT NULL,
  best_seconds INT UNSIGNED NOT NULL,
  hints_used SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  mistakes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  ranking_key BIGINT UNSIGNED NOT NULL,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_player_career_level (player_id, game_mode, level),
  KEY ix_career_leaderboard (game_mode, level, ranking_key),
  CONSTRAINT fk_career_scores_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
