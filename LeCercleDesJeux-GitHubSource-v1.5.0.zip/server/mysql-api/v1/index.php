<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Cache-Control: no-store, max-age=0');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ok(array $data = []): never
{
    respond(['ok' => true, 'data' => $data]);
}

function fail(string $message, int $status = 400): never
{
    respond(['ok' => false, 'error' => $message], $status);
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > 8192) {
        fail('La requête est trop volumineuse.', 413);
    }
    $value = json_decode($raw, true);
    if (!is_array($value)) {
        fail('Le contenu JSON est invalide.');
    }
    return $value;
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $configPath = dirname(__DIR__) . '/config.php';
    if (!is_file($configPath)) {
        fail('Le service multijoueur n’est pas encore configuré sur le site.', 503);
    }
    $config = require $configPath;
    if (!is_array($config) || empty($config['dsn']) || empty($config['username']) || !isset($config['password']) || strlen((string)($config['challenge_secret'] ?? '')) < 32) {
        fail('La configuration du service multijoueur est incomplète.', 503);
    }

    try {
        $pdo = new PDO((string)$config['dsn'], (string)$config['username'], (string)$config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Throwable $exception) {
        error_log('Le Cercle des jeux API: connexion MySQL impossible.');
        fail('Le classement est temporairement indisponible.', 503);
    }
    return $pdo;
}

function allowedMode(string $mode): string
{
    $modes = ['sudoku', 'crossword', 'arrows', 'search', 'memory'];
    if (!in_array($mode, $modes, true)) fail('Jeu inconnu.');
    return $mode;
}

function allowedDifficulty(string $difficulty): string
{
    if (!in_array($difficulty, ['relaxed', 'normal', 'expert'], true)) fail('Niveau de difficulté inconnu.');
    return $difficulty;
}

function normalizeNickname(mixed $value): string
{
    if (!is_string($value)) fail('Saisis un pseudo pour le classement.');
    $nickname = trim($value);
    if (preg_match('/\A[\p{L}\p{N}_-]{3,20}\z/u', $nickname) !== 1) {
        fail('Le pseudo doit contenir de 3 à 20 lettres, chiffres, tirets ou tirets bas.');
    }
    return $nickname;
}

function nicknameIsTaken(PDO $pdo, string $nickname, ?int $exceptPlayerId = null): bool
{
    $sql = 'SELECT id FROM players WHERE nickname = :nickname';
    $values = ['nickname' => $nickname];
    if ($exceptPlayerId !== null) {
        $sql .= ' AND id <> :except_player_id';
        $values['except_player_id'] = $exceptPlayerId;
    }
    $query = $pdo->prepare($sql . ' LIMIT 1');
    $query->execute($values);
    return $query->fetchColumn() !== false;
}

function parisToday(): DateTimeImmutable
{
    return new DateTimeImmutable('now', new DateTimeZone('Europe/Paris'));
}

function databaseUtcTimestamp(mixed $value): ?int
{
    if (!is_string($value) || trim($value) === '') return null;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', trim($value), new DateTimeZone('UTC'));
    return $date instanceof DateTimeImmutable ? $date->getTimestamp() : null;
}
function clientIp(): string
{
    $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
}

function detectedCountry(array $config): array
{
    foreach (['HTTP_CF_IPCOUNTRY', 'GEOIP_COUNTRY_CODE'] as $key) {
        $code = strtoupper(trim((string)($_SERVER[$key] ?? '')));
        if (preg_match('/\A[A-Z]{2}\z/', $code) && $code !== 'XX' && $code !== 'T1') return ['code' => $code, 'source' => 'header'];
    }
    $ip = clientIp();
    if ($ip !== '' && ($config['ip_geolocation_enabled'] ?? true) === true) {
        $url = 'https://ipapi.co/' . rawurlencode($ip) . '/country/';
        $context = stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true, 'header' => "User-Agent: LeCercleDesJeux/1.3\r\n"]]);
        $code = @file_get_contents($url, false, $context);
        $code = strtoupper(trim(is_string($code) ? $code : ''));
        if (preg_match('/\A[A-Z]{2}\z/', $code)) return ['code' => $code, 'source' => 'ip'];
    }
    return ['code' => 'FR', 'source' => 'fallback'];
}

function countryName(string $code): string
{
    $names = ['FR'=>'France','BE'=>'Belgique','CH'=>'Suisse','CA'=>'Canada','LU'=>'Luxembourg','GB'=>'Royaume-Uni','US'=>'États-Unis','DE'=>'Allemagne','ES'=>'Espagne','IT'=>'Italie','NL'=>'Pays-Bas','PT'=>'Portugal'];
    return $names[$code] ?? $code;
}

function normalizedEmail(mixed $value): string
{
    if (!is_string($value)) fail('Saisis une adresse e-mail valide.');
    $email = strtolower(trim($value));
    if (strlen($email) > 254 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) fail('Saisis une adresse e-mail valide.');
    return $email;
}

function maskedEmail(string $email): string
{
    [$name, $domain] = array_pad(explode('@', $email, 2), 2, '');
    return substr($name, 0, 1) . str_repeat('•', max(2, min(8, strlen($name) - 1))) . '@' . $domain;
}

function emailDeliveryConfigured(array $config): bool
{
    $from = trim((string)($config['mail_from'] ?? ''));
    if (filter_var($from, FILTER_VALIDATE_EMAIL) === false) return false;
    $transport = strtolower(trim((string)($config['mail_transport'] ?? 'smtp')));
    if ($transport === 'php') return function_exists('mail');
    $host = trim((string)($config['smtp_host'] ?? ''));
    $port = filter_var($config['smtp_port'] ?? null, FILTER_VALIDATE_INT);
    $security = strtolower(trim((string)($config['smtp_security'] ?? 'tls')));
    return $host !== '' && $port !== false && $port > 0 && $port <= 65535 && in_array($security, ['tls', 'ssl'], true);
}

function smtpReadResponse($socket, array $expectedCodes): bool
{
    $response = '';
    do {
        $line = fgets($socket, 515);
        if ($line === false) return false;
        $response .= $line;
        if (!preg_match('/^(\d{3})([ -])/', $line, $matches)) return false;
        $code = (int)$matches[1];
        $more = $matches[2] === '-';
    } while ($more);
    return in_array($code, $expectedCodes, true);
}

function smtpCommand($socket, string $command, array $expectedCodes): bool
{
    if (fwrite($socket, $command . "\r\n") === false) return false;
    return smtpReadResponse($socket, $expectedCodes);
}

function sendSmtpMessage(array $config, string $email, string $subject, string $message): bool
{
    $host = trim((string)($config['smtp_host'] ?? ''));
    $port = (int)($config['smtp_port'] ?? 587);
    $security = strtolower(trim((string)($config['smtp_security'] ?? 'tls')));
    $from = trim((string)($config['mail_from'] ?? ''));
    $username = (string)($config['smtp_username'] ?? '');
    $password = (string)($config['smtp_password'] ?? '');
    if (!emailDeliveryConfigured($config) || strtolower((string)($config['mail_transport'] ?? 'smtp')) !== 'smtp') return false;

    $remote = ($security === 'ssl' ? 'ssl://' : '') . $host . ':' . $port;
    $context = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host]]);
    $socket = @stream_socket_client($remote, $errno, $error, 12, STREAM_CLIENT_CONNECT, $context);
    if (!is_resource($socket)) return false;
    stream_set_timeout($socket, 12);
    try {
        if (!smtpReadResponse($socket, [220])) return false;
        $clientName = preg_replace('/[^A-Za-z0-9.-]/', '', (string)($_SERVER['SERVER_NAME'] ?? 'localhost')) ?: 'localhost';
        if (!smtpCommand($socket, 'EHLO ' . $clientName, [250])) return false;
        if ($security === 'tls') {
            if (!smtpCommand($socket, 'STARTTLS', [220])) return false;
            if (@stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) !== true) return false;
            if (!smtpCommand($socket, 'EHLO ' . $clientName, [250])) return false;
        }
        if ($username !== '') {
            if (!smtpCommand($socket, 'AUTH LOGIN', [334]) || !smtpCommand($socket, base64_encode($username), [334]) || !smtpCommand($socket, base64_encode($password), [235])) return false;
        }
        if (!smtpCommand($socket, 'MAIL FROM:<' . $from . '>', [250]) || !smtpCommand($socket, 'RCPT TO:<' . $email . '>', [250, 251]) || !smtpCommand($socket, 'DATA', [354])) return false;
        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $headers = 'From: Le Cercle des jeux <' . $from . ">\r\n" . 'To: ' . $email . "\r\n" . 'Subject: ' . $encodedSubject . "\r\n" . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n";
        $body = preg_replace('/\r?\n/', "\r\n", $message);
        $body = preg_replace('/(^|\r\n)\./', '$1..', (string)$body);
        if (fwrite($socket, $headers . $body . "\r\n.\r\n") === false || !smtpReadResponse($socket, [250])) return false;
        smtpCommand($socket, 'QUIT', [221, 250]);
        return true;
    } catch (Throwable $exception) {
        error_log('Le Cercle des jeux API: échec d’envoi SMTP.');
        return false;
    } finally {
        fclose($socket);
    }
}

function sendAccountCode(array $config, string $email, string $code, string $purpose): bool
{
    $from = trim((string)($config['mail_from'] ?? ''));
    $subject = $purpose === 'verify' ? 'Confirmez votre adresse — Le Cercle des jeux' : 'Récupération du compte — Le Cercle des jeux';
    $message = "Votre code est : {$code}\r\n\r\nIl expire dans 15 minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.\r\n";
    $transport = strtolower(trim((string)($config['mail_transport'] ?? 'smtp')));
    if ($transport === 'smtp') return sendSmtpMessage($config, $email, $subject, $message);
    if ($transport === 'php' && emailDeliveryConfigured($config)) {
        // Reuse the mail transport configured for XAMPP/PHP (sendmail.exe or PHP's Windows SMTP settings).
        // Encode both subject and body so French accents survive the relay.
        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $encodedBody = chunk_split(base64_encode($message), 76, "\r\n");
        $headers = [
            'From' => 'Le Cercle des jeux <' . $from . '>',
            'MIME-Version' => '1.0',
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Content-Transfer-Encoding' => 'base64',
        ];
        $sent = @mail($email, $encodedSubject, $encodedBody, $headers);
        if (!$sent) error_log('Le Cercle des jeux API: PHP mail() a échoué; vérifier la configuration de XAMPP/PHP.');
        return $sent;
    }
    return false;
}

function apiFeatureFlags(array $config): array
{
    $flags = ['api_version' => '1.5.0', 'custom_nickname' => true, 'country_ranking' => true, 'world_ranking' => true, 'solo_leaderboard' => false, 'solo_difficulty_leaderboard' => false, 'trophy_tier_leaderboard' => false, 'trophy_data_storage' => false, 'email_delivery_configured' => emailDeliveryConfigured($config)];
    try {
        if (empty($config['dsn']) || !isset($config['username'], $config['password'])) return $flags;
        $pdo = new PDO((string)$config['dsn'], (string)$config['username'], (string)$config['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]);
        $flags['solo_leaderboard'] = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'career_scores'")->fetchColumn() > 0;
        $difficultyColumn = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'career_scores' AND COLUMN_NAME = 'difficulty'")->fetchColumn();
        $flags['solo_difficulty_leaderboard'] = $flags['solo_leaderboard'] && $difficultyColumn === 1;
        $columns = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'players' AND COLUMN_NAME IN ('trophy_bronze','trophy_silver','trophy_gold','trophy_diamond')")->fetchColumn();
        $flags['trophy_tier_leaderboard'] = (int)$columns === 4;
        $flags['trophy_data_storage'] = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'player_trophies'")->fetchColumn() > 0;
    } catch (Throwable $exception) {
        // Les classements de défis restent utilisables pendant une migration.
    }
    return $flags;
}

function cleanupExpiredData(PDO $pdo): void
{
    // Keep daily results for the full account history; deleting the account removes them via the foreign key.
    $profileCutoff = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->modify('-365 days')->format('Y-m-d H:i:s');
    $players = $pdo->prepare('DELETE FROM players WHERE last_seen_at < :cutoff AND email_verified_at IS NULL');
    $players->execute(['cutoff' => $profileCutoff]);
}

function challengePayload(string $mode, array $config): array
{
    $today = parisToday();
    $date = $today->format('Y-m-d');
    $digest = hash_hmac('sha256', $date . '|' . $mode . '|generator-v1', (string)$config['challenge_secret'], true);
    $unpacked = unpack('Nseed', substr($digest, 0, 4));
    $seed = (int)($unpacked['seed'] ?? 1);
    if ($seed === 0) $seed = 1;
    return [
        'date' => $date,
        'date_label' => $today->format('d/m/Y'),
        'mode' => $mode,
        'seed' => $seed,
        'level' => ((int)$today->format('z') % 5) + 1,
        'region' => 'FR',
        'generator_version' => 1,
        'features' => ['custom_nickname' => true],
    ];
}

function bearerToken(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, 'Authorization') === 0) { $header = (string)$value; break; }
        }
    }
    if (!preg_match('/^Bearer ([a-f0-9]{64})$/i', trim($header), $matches)) {
        fail('Profil multijoueur manquant. Enregistre un pseudo.', 401);
    }
    return strtolower($matches[1]);
}

function authenticatedPlayer(PDO $pdo): array
{
    $token = bearerToken();
    $query = $pdo->prepare('SELECT * FROM players WHERE token_hash = :token_hash LIMIT 1');
    $query->execute(['token_hash' => hash('sha256', $token)]);
    $player = $query->fetch();
    if (!$player) fail('Profil introuvable. Enregistre un nouveau pseudo.', 401);
    $country = detectedCountry(is_array($GLOBALS['apiConfig'] ?? null) ? $GLOBALS['apiConfig'] : []);
    $touch = $pdo->prepare('UPDATE players SET last_seen_at = UTC_TIMESTAMP(), country_code = :country_code WHERE id = :id');
    $touch->execute(['id' => $player['id'], 'country_code' => $country['code']]);
    $player['country_code'] = $country['code'];
    return $player;
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$action = strtolower(trim((string)($_GET['action'] ?? '')));
$mode = (string)($_GET['mode'] ?? '');

try {
    $configPath = dirname(__DIR__) . '/config.php';
    $config = is_file($configPath) ? require $configPath : [];
    $GLOBALS['apiConfig'] = is_array($config) ? $config : [];

    if ($method === 'GET' && $action === 'challenge') {
        $mode = allowedMode($mode);
        if (!is_array($config) || strlen((string)($config['challenge_secret'] ?? '')) < 32) {
            fail('Le service multijoueur n’est pas encore configuré sur le site.', 503);
        }
        $payload = challengePayload($mode, $config);
        $country = detectedCountry($config);
        $payload['region'] = $country['code']; $payload['country_name'] = countryName($country['code']); $payload['region_source'] = $country['source'];
        $payload['features'] = apiFeatureFlags($config);
        ok($payload);
    }

    if ($method === 'GET' && $action === 'challenges') {
        if (!is_array($config) || strlen((string)($config['challenge_secret'] ?? '')) < 32) {
            fail('Le service multijoueur n’est pas encore configuré sur le site.', 503);
        }
        $country = detectedCountry($config); $items = [];
        foreach (['sudoku', 'crossword', 'arrows', 'search', 'memory'] as $dailyMode) {
            $item = challengePayload($dailyMode, $config); $item['region'] = $country['code']; $item['country_name'] = countryName($country['code']); $item['region_source'] = $country['source']; $items[] = $item;
        }
        ok(['challenges' => $items, 'region' => $country['code'], 'country_name' => countryName($country['code']), 'region_source' => $country['source'], 'features' => apiFeatureFlags($config)]);
    }

    $pdo = database();
    cleanupExpiredData($pdo);

    if ($method === 'POST' && $action === 'register') {
        $body = requestBody();
        if (($body['consent'] ?? false) !== true || ($body['consent_version'] ?? '') !== 'privacy-2026-11-22-v1.5.0') {
            fail('Coche la case de participation avant de créer un pseudo.');
        }
        $nickname = normalizeNickname($body['nickname'] ?? null);
        if (nicknameIsTaken($pdo, $nickname)) {
            fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
        }
        $country = detectedCountry($config);
        $insert = $pdo->prepare('INSERT INTO players (nickname, token_hash, country_code, last_seen_at, consented_at, consent_version) VALUES (:nickname, :token_hash, :country_code, UTC_TIMESTAMP(), UTC_TIMESTAMP(), :consent_version)');
        $token = bin2hex(random_bytes(32));
        try {
            $insert->execute(['nickname' => $nickname, 'token_hash' => hash('sha256', $token), 'country_code' => $country['code'], 'consent_version' => $body['consent_version']]);
        } catch (PDOException $exception) {
            if (nicknameIsTaken($pdo, $nickname)) {
                fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
            }
            throw $exception;
        }
        ok(['nickname' => $nickname, 'token' => $token]);
    }

    if ($method === 'POST' && $action === 'rename') {
        $player = authenticatedPlayer($pdo);
        $body = requestBody();
        $nickname = normalizeNickname($body['nickname'] ?? null);
        $playerId = (int)$player['id'];
        if (nicknameIsTaken($pdo, $nickname, $playerId)) {
            fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
        }
        $rename = $pdo->prepare('UPDATE players SET nickname = :nickname WHERE id = :id');
        try {
            $rename->execute(['nickname' => $nickname, 'id' => $playerId]);
        } catch (PDOException $exception) {
            if (nicknameIsTaken($pdo, $nickname, $playerId)) {
                fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
            }
            throw $exception;
        }
        ok(['nickname' => $nickname]);
    }

    if ($method === 'GET' && $action === 'leaderboard') {
        $mode = allowedMode($mode);
        $today = parisToday();
        $scope = strtolower((string)($_GET['scope'] ?? 'country')) === 'world' ? 'world' : 'country';
        $country = detectedCountry($config); $whereCountry = $scope === 'country' ? ' AND p.country_code = :country_code' : '';
        $query = $pdo->prepare(
            'SELECT p.nickname, s.best_seconds, s.hints_used, s.mistakes
             FROM daily_scores s INNER JOIN players p ON p.id = s.player_id
             WHERE s.challenge_date = :challenge_date AND s.game_mode = :game_mode' . $whereCountry . '
             ORDER BY s.ranking_key ASC, s.submitted_at ASC, p.id ASC LIMIT 50'
        );
        $parameters = ['challenge_date' => $today->format('Y-m-d'), 'game_mode' => $mode]; if ($scope === 'country') $parameters['country_code'] = $country['code'];
        $query->execute($parameters);
        ok(['date_label' => $today->format('d/m/Y'), 'region' => $country['code'], 'country_name' => countryName($country['code']), 'scope' => $scope, 'entries' => $query->fetchAll()]);
    }

    if ($method === 'POST' && $action === 'submit') {
        $player = authenticatedPlayer($pdo);
        if (($player['consent_version'] ?? '') !== 'privacy-2026-11-22-v1.5.0') fail('Confirme la politique de confidentialité mise à jour dans le jeu avant d’envoyer un résultat.', 403);
        $body = requestBody();
        $submitMode = allowedMode((string)($body['mode'] ?? ''));
        $today = parisToday();
        $date = (string)($body['date'] ?? '');
        if ($date !== $today->format('Y-m-d')) fail('Ce défi n’est plus celui du jour.', 409);
        $seconds = filter_var($body['elapsed_seconds'] ?? null, FILTER_VALIDATE_INT);
        $hints = filter_var($body['hints_used'] ?? 0, FILTER_VALIDATE_INT);
        $mistakes = filter_var($body['mistakes'] ?? 0, FILTER_VALIDATE_INT);
        if ($seconds === false || $seconds < 1 || $seconds > 86400 || $hints === false || $hints < 0 || $hints > 999 || $mistakes === false || $mistakes < 0 || $mistakes > 999) {
            fail('Le résultat envoyé est invalide.');
        }

        $rankingKey = ($seconds * 1000000) + ($hints * 1000) + $mistakes;
        $previousQuery = $pdo->prepare('SELECT ranking_key FROM daily_scores WHERE player_id = :player_id AND challenge_date = :challenge_date AND game_mode = :game_mode LIMIT 1');
        $previousQuery->execute(['player_id' => $player['id'], 'challenge_date' => $date, 'game_mode' => $submitMode]);
        $previousKey = $previousQuery->fetchColumn();
        $improved = $previousKey === false || $rankingKey < (int)$previousKey;
        $upsert = $pdo->prepare(
            'INSERT INTO daily_scores (player_id, challenge_date, game_mode, best_seconds, hints_used, mistakes, ranking_key, submitted_at)
             VALUES (:player_id, :challenge_date, :game_mode, :best_seconds, :hints_used, :mistakes, :ranking_key, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE
               best_seconds = IF(VALUES(ranking_key) < ranking_key, VALUES(best_seconds), best_seconds),
               hints_used = IF(VALUES(ranking_key) < ranking_key, VALUES(hints_used), hints_used),
               mistakes = IF(VALUES(ranking_key) < ranking_key, VALUES(mistakes), mistakes),
               submitted_at = IF(VALUES(ranking_key) < ranking_key, UTC_TIMESTAMP(), submitted_at),
               ranking_key = LEAST(ranking_key, VALUES(ranking_key))'
        );
        $upsert->execute([
            'player_id' => $player['id'], 'challenge_date' => $date, 'game_mode' => $submitMode,
            'best_seconds' => $seconds, 'hints_used' => $hints, 'mistakes' => $mistakes, 'ranking_key' => $rankingKey,
        ]);
        $resultQuery = $pdo->prepare('SELECT best_seconds FROM daily_scores WHERE player_id = :player_id AND challenge_date = :challenge_date AND game_mode = :game_mode');
        $resultQuery->execute(['player_id' => $player['id'], 'challenge_date' => $date, 'game_mode' => $submitMode]);
        $bestSeconds = (int)$resultQuery->fetchColumn();
        ok(['improved' => $improved, 'best_seconds' => $bestSeconds]);
    }

    if ($method === 'POST' && $action === 'level-submit') {
        $player = authenticatedPlayer($pdo);
        if (($player['consent_version'] ?? '') !== 'privacy-2026-11-22-v1.5.0') fail('Confirme la politique de confidentialité mise à jour dans le jeu avant d’envoyer un résultat.', 403);
        $body = requestBody(); $submitMode = allowedMode((string)($body['mode'] ?? ''));
        $difficulty = allowedDifficulty((string)($body['difficulty'] ?? 'normal'));
        $level = filter_var($body['level'] ?? null, FILTER_VALIDATE_INT);
        $seconds = filter_var($body['elapsed_seconds'] ?? null, FILTER_VALIDATE_INT);
        $hints = filter_var($body['hints_used'] ?? 0, FILTER_VALIDATE_INT);
        $mistakes = filter_var($body['mistakes'] ?? 0, FILTER_VALIDATE_INT);
        if ($level === false || $level < 1 || $level > 1000000 || $seconds === false || $seconds < 1 || $seconds > 86400 || $hints === false || $hints < 0 || $hints > 999 || $mistakes === false || $mistakes < 0 || $mistakes > 999) fail('Le résultat envoyé est invalide.');
        $rankingKey = ($seconds * 1000000) + ($hints * 1000) + $mistakes;
        $previous = $pdo->prepare('SELECT ranking_key FROM career_scores WHERE player_id = :player_id AND game_mode = :game_mode AND difficulty = :difficulty AND level = :level LIMIT 1');
        $previous->execute(['player_id' => $player['id'], 'game_mode' => $submitMode, 'difficulty' => $difficulty, 'level' => $level]);
        $previousKey = $previous->fetchColumn(); $improved = $previousKey === false || $rankingKey < (int)$previousKey;
        $upsert = $pdo->prepare(
            'INSERT INTO career_scores (player_id, game_mode, difficulty, level, best_seconds, hints_used, mistakes, ranking_key, submitted_at)
             VALUES (:player_id, :game_mode, :difficulty, :level, :best_seconds, :hints_used, :mistakes, :ranking_key, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE
               best_seconds = IF(VALUES(ranking_key) < ranking_key, VALUES(best_seconds), best_seconds),
               hints_used = IF(VALUES(ranking_key) < ranking_key, VALUES(hints_used), hints_used),
               mistakes = IF(VALUES(ranking_key) < ranking_key, VALUES(mistakes), mistakes),
               submitted_at = IF(VALUES(ranking_key) < ranking_key, UTC_TIMESTAMP(), submitted_at),
               ranking_key = LEAST(ranking_key, VALUES(ranking_key))'
        );
        $upsert->execute(['player_id' => $player['id'], 'game_mode' => $submitMode, 'difficulty' => $difficulty, 'level' => $level, 'best_seconds' => $seconds, 'hints_used' => $hints, 'mistakes' => $mistakes, 'ranking_key' => $rankingKey]);
        $best = $pdo->prepare('SELECT best_seconds FROM career_scores WHERE player_id = :player_id AND game_mode = :game_mode AND difficulty = :difficulty AND level = :level');
        $best->execute(['player_id' => $player['id'], 'game_mode' => $submitMode, 'difficulty' => $difficulty, 'level' => $level]);
        ok(['improved' => $improved, 'best_seconds' => (int)$best->fetchColumn()]);
    }

    if ($method === 'GET' && $action === 'career-leaderboard') {
        $mode = allowedMode($mode);
        $difficulty = allowedDifficulty((string)($_GET['difficulty'] ?? 'normal'));
        $scope = strtolower((string)($_GET['scope'] ?? 'country')) === 'world' ? 'world' : 'country';
        $country = detectedCountry($config); $whereCountry = $scope === 'country' ? ' AND p.country_code = :country_code' : '';
        $query = $pdo->prepare(
            'SELECT p.nickname, COUNT(s.id) AS completed_levels, MAX(s.level) AS highest_level, SUM(s.best_seconds) AS total_seconds
             FROM career_scores s INNER JOIN players p ON p.id = s.player_id
             WHERE s.game_mode = :game_mode AND s.difficulty = :difficulty' . $whereCountry . '
             GROUP BY p.id, p.nickname
             ORDER BY highest_level DESC, completed_levels DESC, total_seconds ASC, p.nickname ASC LIMIT 50'
        );
        $parameters = ['game_mode' => $mode, 'difficulty' => $difficulty]; if ($scope === 'country') $parameters['country_code'] = $country['code'];
        $query->execute($parameters);
        ok(['region' => $country['code'], 'country_name' => countryName($country['code']), 'scope' => $scope, 'difficulty' => $difficulty, 'entries' => $query->fetchAll()]);
    }

    if ($method === 'POST' && $action === 'delete') {
        $player = authenticatedPlayer($pdo);
        $delete = $pdo->prepare('DELETE FROM players WHERE id = :id');
        $delete->execute(['id' => $player['id']]);
        ok(['deleted' => true]);
    }

    if ($method === 'GET' && $action === 'account-status') {
        $player = authenticatedPlayer($pdo); $email = (string)($player['email'] ?? '');
        ok(['email_verified' => !empty($player['email_verified_at']), 'email_masked' => $email !== '' ? maskedEmail($email) : '', 'pending_email' => (string)($player['pending_email'] ?? ''), 'share_trophies' => (bool)($player['share_trophies'] ?? false), 'consent_version' => (string)($player['consent_version'] ?? ''), 'email_delivery_configured' => emailDeliveryConfigured($config)]);
    }

    if ($method === 'POST' && $action === 'update-consent') {
        $player = authenticatedPlayer($pdo); $body = requestBody();
        if (($body['consent'] ?? false) !== true || ($body['consent_version'] ?? '') !== 'privacy-2026-11-22-v1.5.0') fail('Confirmez la nouvelle politique pour enregistrer votre choix.');
        $pdo->prepare('UPDATE players SET consented_at = UTC_TIMESTAMP(), consent_version = :version WHERE id = :id')->execute(['version' => 'privacy-2026-11-22-v1.5.0', 'id' => $player['id']]);
        ok(['consent_version' => 'privacy-2026-11-22-v1.5.0']);
    }

    if ($method === 'POST' && $action === 'email-start') {
        $player = authenticatedPlayer($pdo); $body = requestBody(); $email = normalizedEmail($body['email'] ?? null);
        if (!emailDeliveryConfigured($config)) fail('L’envoi d’e-mail n’est pas configuré sur le serveur. Ajoutez les paramètres SMTP dans config.php.', 503);
        $emailSentAt = databaseUtcTimestamp($player['email_sent_at'] ?? null);
        if ($emailSentAt !== null && $emailSentAt > time() - 60) fail('Attends une minute avant de demander un autre code.');
        $check = $pdo->prepare('SELECT id FROM players WHERE email = :email AND id <> :id LIMIT 1'); $check->execute(['email' => $email, 'id' => $player['id']]); if ($check->fetchColumn() !== false) fail('Cette adresse est déjà associée à un autre compte.', 409);
        $code = (string)random_int(100000, 999999); $config = is_array($GLOBALS['apiConfig'] ?? null) ? $GLOBALS['apiConfig'] : [];
        if (!sendAccountCode($config, $email, $code, 'verify')) fail('Le serveur mail n’a pas envoyé le code. Vérifiez les réglages SMTP dans config.php puis réessayez.', 503);
        $saveCode = $pdo->prepare('UPDATE players SET pending_email = :email, email_code_hash = :code_hash, email_expires = DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE), email_sent_at = UTC_TIMESTAMP(), email_attempts = 0 WHERE id = :id');
        $saveCode->execute(['email' => $email, 'code_hash' => hash('sha256', $code), 'id' => $player['id']]);
        ok(['message' => 'Code envoyé. Vérifiez votre messagerie ; il expire dans 15 minutes.']);
    }

    if ($method === 'POST' && $action === 'email-verify') {
        $player = authenticatedPlayer($pdo); $body = requestBody(); $code = trim((string)($body['code'] ?? ''));
        $emailExpiresAt = databaseUtcTimestamp($player['email_expires'] ?? null);
        if (preg_match('/\A\d{6}\z/', $code) !== 1 || empty($player['pending_email']) || empty($player['email_code_hash']) || $emailExpiresAt === null || $emailExpiresAt < time() || (int)$player['email_attempts'] >= 5 || !hash_equals((string)$player['email_code_hash'], hash('sha256', $code))) {
            $pdo->prepare('UPDATE players SET email_attempts = email_attempts + 1 WHERE id = :id')->execute(['id' => $player['id']]); fail('Code invalide ou expiré. Vous pouvez demander un nouveau code.');
        }
        $pdo->prepare('UPDATE players SET email = pending_email, email_verified_at = UTC_TIMESTAMP(), pending_email = NULL, email_code_hash = NULL, email_expires = NULL, email_attempts = 0 WHERE id = :id')->execute(['id' => $player['id']]);
        ok(['email_masked' => maskedEmail((string)$player['pending_email'])]);
    }

    if ($method === 'POST' && $action === 'recover-start') {
        $body = requestBody(); $nickname = normalizeNickname($body['nickname'] ?? null); $email = normalizedEmail($body['email'] ?? null);
        if (!emailDeliveryConfigured($config)) fail('L’envoi d’e-mail n’est pas configuré sur le serveur. Ajoutez les paramètres SMTP dans config.php.', 503);
        $find = $pdo->prepare('SELECT id, email_verified_at, recovery_expires FROM players WHERE nickname = :nickname AND email = :email LIMIT 1'); $find->execute(['nickname' => $nickname, 'email' => $email]); $account = $find->fetch();
        if ($account && !empty($account['email_verified_at'])) {
            $code = (string)random_int(100000, 999999); $config = is_array($GLOBALS['apiConfig'] ?? null) ? $GLOBALS['apiConfig'] : [];
            $recoveryExpiresAt = databaseUtcTimestamp($account['recovery_expires'] ?? null);
            $recent = $recoveryExpiresAt !== null && $recoveryExpiresAt > time() - 14 * 60;
            if (!$recent && sendAccountCode($config, $email, $code, 'recover')) $pdo->prepare('UPDATE players SET recovery_code_hash = :hash, recovery_expires = DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE), recovery_attempts = 0 WHERE id = :id')->execute(['hash' => hash('sha256', $code), 'id' => $account['id']]);
        }
        ok(['message' => 'Si le pseudo et l’adresse e-mail correspondent à un compte confirmé, un code a été envoyé.']);
    }

    if ($method === 'POST' && $action === 'recover-finish') {
        $body = requestBody(); $nickname = normalizeNickname($body['nickname'] ?? null); $email = normalizedEmail($body['email'] ?? null); $code = trim((string)($body['code'] ?? ''));
        $find = $pdo->prepare('SELECT * FROM players WHERE nickname = :nickname AND email = :email AND email_verified_at IS NOT NULL LIMIT 1'); $find->execute(['nickname' => $nickname, 'email' => $email]); $player = $find->fetch();
        $recoveryExpiresAt = $player ? databaseUtcTimestamp($player['recovery_expires'] ?? null) : null;
        if (!$player || preg_match('/\A\d{6}\z/', $code) !== 1 || empty($player['recovery_code_hash']) || $recoveryExpiresAt === null || $recoveryExpiresAt < time() || (int)$player['recovery_attempts'] >= 5 || !hash_equals((string)$player['recovery_code_hash'], hash('sha256', $code))) {
            if ($player) $pdo->prepare('UPDATE players SET recovery_attempts = recovery_attempts + 1 WHERE id = :id')->execute(['id' => $player['id']]);
            fail('Code invalide ou expiré. Demandez un nouveau code.');
        }
        $token = bin2hex(random_bytes(32)); $country = detectedCountry($config);
        $pdo->prepare('UPDATE players SET token_hash = :hash, country_code = :country, recovery_code_hash = NULL, recovery_expires = NULL, recovery_attempts = 0, last_seen_at = UTC_TIMESTAMP() WHERE id = :id')->execute(['hash' => hash('sha256', $token), 'country' => $country['code'], 'id' => $player['id']]);
        ok(['nickname' => $nickname, 'token' => $token]);
    }

    if ($method === 'POST' && $action === 'trophy-progress') {
        $player = authenticatedPlayer($pdo); $body = requestBody(); $share = ($body['share'] ?? false) === true;
        if (($player['consent_version'] ?? '') !== 'privacy-2026-11-22-v1.5.0') fail('Confirmez la politique de confidentialité mise à jour dans le jeu avant d’enregistrer vos trophées.', 403);
        $unlocked = $body['unlocked_ids'] ?? [];
        if (!is_array($unlocked) || count($unlocked) > 200) fail('La liste des trophées est invalide.');
        $unlockedIds = [];
        foreach ($unlocked as $trophyId) {
            if (!is_string($trophyId) || preg_match('/\A[a-z0-9_-]{1,64}\z/', $trophyId) !== 1) fail('Identifiant de trophée invalide.');
            $unlockedIds[] = $trophyId;
        }
        $unlockedIds = array_values(array_unique($unlockedIds));
        $counts = [];
        foreach (['total' => 'trophy_count', 'bronze' => 'trophy_bronze', 'silver' => 'trophy_silver', 'gold' => 'trophy_gold', 'diamond' => 'trophy_diamond'] as $key => $column) {
            $value = filter_var($body[$key] ?? ($key === 'total' ? ($body['count'] ?? 0) : 0), FILTER_VALIDATE_INT);
            if ($value === false || $value < 0 || $value > 10000) fail('Nombre de trophées invalide.');
            $counts[$column] = $value;
        }
        if (array_sum($counts) - $counts['trophy_count'] > $counts['trophy_count']) fail('Le nombre de trophées par niveau ne peut pas dépasser le total.');
        $pdo->beginTransaction();
        try {
        $update = $pdo->prepare('UPDATE players SET share_trophies = :share, trophy_count = :total, trophy_bronze = :bronze, trophy_silver = :silver, trophy_gold = :gold, trophy_diamond = :diamond WHERE id = :id');
        $update->execute(['share' => $share ? 1 : 0, 'total' => $counts['trophy_count'], 'bronze' => $counts['trophy_bronze'], 'silver' => $counts['trophy_silver'], 'gold' => $counts['trophy_gold'], 'diamond' => $counts['trophy_diamond'], 'id' => $player['id']]);
            $insertTrophy = $pdo->prepare('INSERT IGNORE INTO player_trophies (player_id, trophy_id, recorded_at) VALUES (:player_id, :trophy_id, UTC_TIMESTAMP())');
            foreach ($unlockedIds as $trophyId) {
                $insertTrophy->execute(['player_id' => $player['id'], 'trophy_id' => $trophyId]);
            }
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $exception;
        }
        ok(['shared' => $share, 'stored_trophies' => count($unlockedIds)]);
    }

    if ($method === 'GET' && $action === 'trophy-leaderboard') {
        $player = authenticatedPlayer($pdo); if (empty($player['share_trophies'])) fail('Activez le partage facultatif pour comparer votre progression.');
        $scope = strtolower((string)($_GET['scope'] ?? 'country')) === 'world' ? 'world' : 'country'; $country = detectedCountry($config);
        $tier = strtolower((string)($_GET['tier'] ?? 'total'));
        $columns = ['total' => 'trophy_count', 'bronze' => 'trophy_bronze', 'silver' => 'trophy_silver', 'gold' => 'trophy_gold', 'diamond' => 'trophy_diamond'];
        if (!isset($columns[$tier])) fail('Niveau de trophée inconnu.');
        $column = $columns[$tier]; $countryCondition = $scope === 'country' ? ' AND country_code = :country_code' : '';
        $countQuery = $pdo->prepare('SELECT COUNT(*) FROM players WHERE share_trophies = 1' . $countryCondition);
        $parameters = []; if ($scope === 'country') $parameters['country_code'] = $country['code']; $countQuery->execute($parameters); $total = (int)$countQuery->fetchColumn();
        $rankQuery = $pdo->prepare('SELECT COUNT(*) FROM players WHERE share_trophies = 1 AND ' . $column . ' > :mine' . $countryCondition);
        $rankParams = ['mine' => (int)$player[$column]]; if ($scope === 'country') $rankParams['country_code'] = $country['code']; $rankQuery->execute($rankParams); $rank = (int)$rankQuery->fetchColumn() + 1;
        $list = $pdo->prepare('SELECT nickname, ' . $column . ' AS count FROM players WHERE share_trophies = 1' . $countryCondition . ' ORDER BY ' . $column . ' DESC, nickname ASC, id ASC LIMIT 50');
        $list->execute($parameters);
        ok(['scope' => $scope, 'tier' => $tier, 'country_name' => countryName($country['code']), 'rank' => $rank, 'total_players' => $total, 'entries' => $list->fetchAll()]);
    }

    if ($method === 'GET' && $action === 'trophy-compare') {
        $player = authenticatedPlayer($pdo); if (empty($player['share_trophies'])) fail('Activez le partage anonyme pour comparer votre progression.');
        $scope = strtolower((string)($_GET['scope'] ?? 'country')) === 'world' ? 'world' : 'country'; $country = detectedCountry($config);
        $condition = $scope === 'country' ? ' AND country_code = :country_code' : '';
        $counts = $pdo->prepare('SELECT COUNT(*) AS total, SUM(trophy_count > :mine) AS above_count FROM players WHERE share_trophies = 1' . $condition);
        $values = ['mine' => (int)$player['trophy_count']]; if ($scope === 'country') $values['country_code'] = $country['code']; $counts->execute($values); $stats = $counts->fetch();
        $total = (int)($stats['total'] ?? 0); $rank = (int)($stats['above_count'] ?? 0) + 1; $percentile = $total ? (int)round((($total - $rank) / max(1, $total - 1)) * 100) : 100;
        ok(['scope' => $scope, 'country_name' => countryName($country['code']), 'rank' => min($rank, max(1, $total)), 'total_players' => $total, 'percentile' => $percentile]);
    }

    fail('Action inconnue.', 404);
} catch (Throwable $exception) {
    error_log('Le Cercle des jeux API: erreur interne.');
    fail('Le service multijoueur a rencontré une erreur.', 500);
}
