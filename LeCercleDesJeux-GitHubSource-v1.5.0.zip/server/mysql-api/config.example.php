<?php
return [
    // Remplace ces valeurs avec celles créées dans le panneau d’hébergement.
    'dsn' => 'mysql:host=localhost;dbname=lecercle_des_jeux;charset=utf8mb4',
    'username' => 'UTILISATEUR_MYSQL',
    'password' => 'MOT_DE_PASSE_MYSQL',
    // Génére une longue valeur aléatoire indépendante des identifiants MySQL.
    'challenge_secret' => 'REMPLACER_PAR_UN_SECRET_ALEATOIRE_D_AU_MOINS_32_CARACTERES',
    // Envoi du code de protection et de récupération du compte.
    // Choisis "smtp" et recopie les paramètres fournis par ton hébergeur.
    'mail_transport' => 'smtp',
    'mail_from' => '',
    'smtp_host' => '',
    'smtp_port' => 587,
    'smtp_security' => 'tls', // tls (STARTTLS) ou ssl (TLS implicite).
    'smtp_username' => '',
    'smtp_password' => '',
    // Utilise ipapi.co uniquement si aucun code pays fiable n’est fourni par l’hébergement.
    'ip_geolocation_enabled' => true,
];
