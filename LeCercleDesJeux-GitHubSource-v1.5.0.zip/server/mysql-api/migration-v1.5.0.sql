-- À exécuter une seule fois après la migration v1.4.0.
-- Faire une sauvegarde de la base avant l'import.

ALTER TABLE career_scores
  DROP INDEX uq_player_career_level,
  DROP INDEX ix_career_leaderboard,
  ADD COLUMN difficulty ENUM('relaxed','normal','expert') NOT NULL DEFAULT 'normal' AFTER game_mode,
  ADD UNIQUE KEY uq_player_career_level_difficulty (player_id, game_mode, difficulty, level),
  ADD KEY ix_career_leaderboard (game_mode, difficulty, level, ranking_key);

CREATE TABLE IF NOT EXISTS player_trophies (
  player_id BIGINT UNSIGNED NOT NULL,
  trophy_id VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (player_id, trophy_id),
  KEY ix_player_trophies_id (trophy_id),
  CONSTRAINT fk_player_trophies_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
