<?php
// À fusionner dans le tableau retourné par votre config.php privé.
// Utilise le transport mail() déjà configuré dans XAMPP (sendmail.ini / php.ini).
// Le relais XAMPP doit autoriser cette adresse d’expédition.
return [
    'mail_transport' => 'php',
    'mail_from' => 'loic.tinant@outlook.fr',
];
