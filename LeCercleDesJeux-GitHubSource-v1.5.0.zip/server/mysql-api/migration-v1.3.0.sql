-- À exécuter une seule fois sur la base utilisée par les versions 1.1/1.2.
-- Exporter une sauvegarde de la base avant l'import.
ALTER TABLE players
  ADD COLUMN country_code CHAR(2) CHARACTER SET ascii COLLATE ascii_bin NULL AFTER token_hash,
  ADD COLUMN email VARCHAR(254) NULL AFTER country_code,
  ADD COLUMN email_verified_at DATETIME NULL AFTER email,
  ADD COLUMN pending_email VARCHAR(254) NULL AFTER email_verified_at,
  ADD COLUMN email_code_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL AFTER pending_email,
  ADD COLUMN email_expires DATETIME NULL AFTER email_code_hash,
  ADD COLUMN email_sent_at DATETIME NULL AFTER email_expires,
  ADD COLUMN email_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER email_expires,
  ADD COLUMN recovery_code_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL AFTER email_attempts,
  ADD COLUMN recovery_expires DATETIME NULL AFTER recovery_code_hash,
  ADD COLUMN recovery_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER recovery_expires,
  ADD COLUMN share_trophies TINYINT(1) NOT NULL DEFAULT 0 AFTER recovery_attempts,
  ADD COLUMN trophy_count SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER share_trophies,
  ADD UNIQUE KEY uq_players_email (email),
  ADD KEY ix_players_country_trophies (country_code, share_trophies, trophy_count);

-- Les profils existants restent dans le classement mondial. Leur pays sera détecté
-- et enregistré à leur prochaine requête authentifiée.
