# Retrouver les classements dans MySQL

Les classements du compte sont conservés dans la base MySQL de l’API. Dans le panneau de l’hébergeur, ouvre **phpMyAdmin**, sélectionne la base du jeu, puis l’onglet **SQL** pour exécuter les requêtes ci-dessous. Si tu as renommé les tables, adapte leurs noms dans les requêtes.

## Tables principales

- `players` : pseudo, pays, état de partage des trophées et totaux par rang.
- `daily_scores` : meilleur résultat de chaque compte pour chaque défi quotidien, conservé pendant toute la durée du compte.
- `career_scores` : meilleur résultat enregistré pour chaque compte, jeu, difficulté et niveau.
- `player_trophies` : identifiant et date de déblocage de chaque trophée associé au compte.

Les difficultés sont `relaxed` (Tranquille), `normal` (Classique) et `expert` (Expert). Les jeux sont `sudoku`, `crossword`, `arrows`, `search` et `memory`.

## Progression solo par jeu et difficulté

```sql
SELECT p.nickname, c.game_mode, c.difficulty,
       COUNT(*) AS niveaux_enregistres,
       MAX(c.level) AS niveau_le_plus_eleve,
       SUM(c.best_seconds) AS temps_cumule_secondes
FROM career_scores AS c
JOIN players AS p ON p.id = c.player_id
GROUP BY p.id, p.nickname, c.game_mode, c.difficulty
ORDER BY c.game_mode, c.difficulty, niveau_le_plus_eleve DESC;
```

## Résultat détaillé par niveau

```sql
SELECT p.nickname, c.game_mode, c.difficulty, c.level,
       c.best_seconds, c.hints_used, c.mistakes, c.submitted_at
FROM career_scores AS c
JOIN players AS p ON p.id = c.player_id
ORDER BY p.nickname, c.game_mode, c.difficulty, c.level;
```

## Défis quotidiens encore conservés

```sql
SELECT p.nickname, d.challenge_date, d.game_mode,
       d.best_seconds, d.hints_used, d.mistakes, d.submitted_at
FROM daily_scores AS d
JOIN players AS p ON p.id = d.player_id
ORDER BY d.challenge_date DESC, d.game_mode, d.best_seconds;
```

## Trophées débloqués

```sql
SELECT p.nickname, t.trophy_id, t.recorded_at
FROM player_trophies AS t
JOIN players AS p ON p.id = t.player_id
ORDER BY p.nickname, t.recorded_at;
```

Les identifiants (`trophy_id`) sont les clés techniques de la liste des trophées du jeu. Les totaux par rang sont dans `players` : `trophy_count`, `trophy_bronze`, `trophy_silver`, `trophy_gold` et `trophy_diamond`. Le champ `share_trophies` indique si le joueur a choisi d’apparaître dans les classements publics ; désactiver ce partage masque son classement, sans effacer ses données privées.

Les résultats quotidiens, les niveaux solo et les trophées restent en base tant que le compte existe. Les comptes sans adresse e-mail vérifiée et sans activité depuis 12 mois sont supprimés automatiquement ; les comptes supprimés depuis le jeu effacent aussi leurs résultats. Dans phpMyAdmin, sélectionne la base puis **Exporter** pour télécharger une copie des tables. Fais régulièrement une sauvegarde de la base pour conserver une copie indépendante.

La sauvegarde de partie hors ligne reste sur l’appareil. Ces tables conservent les données de compte, de classement et de trophées, pas l’état d’une grille en cours.
