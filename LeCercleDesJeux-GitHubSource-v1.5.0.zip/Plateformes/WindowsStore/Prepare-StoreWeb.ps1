param(
    [Parameter(Mandatory = $true)]
    [string]$Destination
)

$ErrorActionPreference = 'Stop'
$destinationPath = [System.IO.Path]::GetFullPath($Destination)
$indexPath = Join-Path $destinationPath 'index.html'
$appScriptPath = Join-Path $destinationPath 'app.js'
$privacyPath = Join-Path $destinationPath 'privacy.html'

Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'monetization.js') -Destination (Join-Path $destinationPath 'monetization.js') -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'monetization.css') -Destination (Join-Path $destinationPath 'monetization.css') -Force

$html = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
$styleAnchor = '<link rel="stylesheet" href="details.css">'
if (-not $html.Contains('monetization.css')) {
    if (-not $html.Contains($styleAnchor)) { throw 'Le lien details.css est introuvable dans index.html.' }
    $html = $html.Replace($styleAnchor, $styleAnchor + "`r`n  <link rel=`"stylesheet`" href=`"monetization.css`">")
}
$scriptAnchor = '<script src="app.js"></script>'
if (-not $html.Contains('monetization.js')) {
    if (-not $html.Contains($scriptAnchor)) { throw 'Le script app.js est introuvable dans index.html.' }
    $html = $html.Replace($scriptAnchor, $scriptAnchor + "`r`n  <script src=`"monetization.js`"></script>")
}
[System.IO.File]::WriteAllText($indexPath, $html, (New-Object System.Text.UTF8Encoding($false)))

# Expose only a tiny restart hook in the packaged Store copy. The shared game,
# trial EXE, Android build, website and visual proposals remain untouched.
$appJs = [System.IO.File]::ReadAllText($appScriptPath, [System.Text.Encoding]::UTF8)
$backHomeAnchor = '  function backHome() {'
$restartHook = @'
  window.__LeCercleStore = window.__LeCercleStore || {};
  window.__LeCercleStore.restartCurrentGame = function () {
    if (!activeMode || !game || game.finished) return false;
    startGame(activeMode);
    return true;
  };

  function backHome() {
'@
if (-not $appJs.Contains('window.__LeCercleStore.restartCurrentGame')) {
    if (-not $appJs.Contains($backHomeAnchor)) { throw 'Le point d’insertion du redémarrage est introuvable dans app.js.' }
    $appJs = $appJs.Replace($backHomeAnchor, $restartHook.TrimEnd())
}
[System.IO.File]::WriteAllText($appScriptPath, $appJs, (New-Object System.Text.UTF8Encoding($false)))

# The Store version may send ad-related data to Liftoff Monetize. Keep the
# Store privacy page accurate and provide the provider's interest-ad opt-out.
if (Test-Path -LiteralPath $privacyPath) {
    $privacy = [System.IO.File]::ReadAllText($privacyPath, [System.Text.Encoding]::UTF8)
    $privacy = $privacy.Replace('Dernière mise à jour : 16 novembre 2026', 'Dernière mise à jour : 18 novembre 2026')
    $oldAdParagraph = '<p>Cette version ne contient ni publicité, ni suivi publicitaire, ni outil d’analyse. Elle ne demande aucune permission d’accès aux contacts, à la localisation, au microphone ou à l’appareil photo.</p>'
    $newAdParagraph = '<p>Dans l’édition Microsoft Store, des publicités peuvent être proposées par Liftoff Monetize (Vungle) lorsque cette fonction est activée. Le fournisseur peut traiter des identifiants publicitaires ou techniques, des informations sur l’appareil et le réseau, ainsi que les interactions avec les publicités, pour les diffuser et en mesurer les résultats. Le SDK prévoit un écran de consentement avant les annonces pour les utilisateurs de l’Union européenne ; sa configuration devra être vérifiée avant l’activation. Vous pouvez aussi consulter la <a href="https://liftoff.ai/opt-out/">page de désactivation des publicités ciblées de Liftoff</a>. L’achat intégré « Sans publicité » retire les publicités, y compris les vidéos facultatives.</p><p>Le jeu ne demande pas l’accès aux contacts, à la localisation, au microphone ou à l’appareil photo.</p>'
    if ($privacy.Contains($oldAdParagraph)) {
        $privacy = $privacy.Replace($oldAdParagraph, $newAdParagraph)
        [System.IO.File]::WriteAllText($privacyPath, $privacy, (New-Object System.Text.UTF8Encoding($false)))
    }
}
