using System;
using System.Threading.Tasks;
using Windows.Services.Store;
using Windows.UI.Core;
using Windows.UI.Xaml.Controls;
using VungleSDK;

namespace LeCercleDesJeux.Windows
{
    public sealed partial class MainPage : Page
    {
        private VungleAd _adSdk;
        private StoreContext _storeContext;
        private bool _adsInitialized;
        private volatile bool _rewardedReady;
        private volatile bool _interstitialReady;
        private bool _noAds;
        private bool _pendingRewardedRestart;

        public MainPage()
        {
            InitializeComponent();
            GameView.ScriptNotify += GameView_ScriptNotify;
            GameView.NavigationCompleted += GameView_NavigationCompleted;

            if (MonetizationConfig.AdsConfigured)
            {
                InitializeAds();
            }
        }

        private async void GameView_NavigationCompleted(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            if (args.IsSuccess)
            {
                await PublishMonetizationStateAsync();
            }
        }

        private async void GameView_ScriptNotify(object sender, NotifyEventArgs args)
        {
            switch (args.Value)
            {
                case "lcj:state":
                    await PublishMonetizationStateAsync();
                    break;
                case "lcj:reward-restart":
                    await PlayRewardedRestartAsync();
                    break;
                case "lcj:remove-ads":
                    await PurchaseRemoveAdsAsync();
                    break;
                case "lcj:interstitial":
                    await PlayInterstitialAsync();
                    break;
            }
        }

        private void InitializeAds()
        {
            try
            {
                _adSdk = AdFactory.GetInstance(MonetizationConfig.LiftoffAppId);
                _adSdk.OnInitCompleted += Ads_OnInitCompleted;
                _adSdk.OnAdPlayableChanged += Ads_OnAdPlayableChanged;
                _adSdk.OnAdEnd += Ads_OnAdEnd;
            }
            catch
            {
                _adsInitialized = false;
            }
        }

        private void Ads_OnInitCompleted(object sender, ConfigEventArgs args)
        {
            _adsInitialized = args.Initialized;
            if (!_adsInitialized)
            {
                return;
            }

            _adSdk.LoadAd(MonetizationConfig.RewardedRestartPlacementId);
            _adSdk.LoadAd(MonetizationConfig.InterstitialPlacementId);
        }

        private void Ads_OnAdPlayableChanged(object sender, AdPlayableEventArgs args)
        {
            if (string.Equals(args.Placement, MonetizationConfig.RewardedRestartPlacementId, StringComparison.Ordinal))
            {
                _rewardedReady = args.AdPlayable;
                _ = PublishMonetizationStateOnUiThreadAsync();
            }
            else if (string.Equals(args.Placement, MonetizationConfig.InterstitialPlacementId, StringComparison.Ordinal))
            {
                _interstitialReady = args.AdPlayable;
            }
        }

        private async void Ads_OnAdEnd(object sender, AdEndEventArgs args)
        {
            bool isRewardedRestart = string.Equals(args.Placement, MonetizationConfig.RewardedRestartPlacementId, StringComparison.Ordinal);
            bool isInterstitial = string.Equals(args.Placement, MonetizationConfig.InterstitialPlacementId, StringComparison.Ordinal);
            bool rewardEarned = args.IsCompletedView || args.CallToActionClicked;

            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                if (isRewardedRestart && _pendingRewardedRestart)
                {
                    _pendingRewardedRestart = false;
                    if (rewardEarned)
                    {
                        _ = InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.rewardCompleted();");
                    }
                    else
                    {
                        _ = InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.rewardCancelled();");
                    }
                }

                if (isRewardedRestart)
                {
                    _rewardedReady = false;
                    _adSdk.LoadAd(MonetizationConfig.RewardedRestartPlacementId);
                    _ = PublishMonetizationStateAsync();
                }
                else if (isInterstitial)
                {
                    _interstitialReady = false;
                    _adSdk.LoadAd(MonetizationConfig.InterstitialPlacementId);
                }
            });
        }

        private async Task PlayRewardedRestartAsync()
        {
            if (_noAds)
            {
                await InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.rewardCompleted();");
                return;
            }

            if (!_adsInitialized || !_rewardedReady || _adSdk == null)
            {
                await InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.adUnavailable();");
                return;
            }

            _pendingRewardedRestart = true;
            _rewardedReady = false;
            await PublishMonetizationStateAsync();
            try
            {
                await _adSdk.PlayAdAsync(new AdConfig(), MonetizationConfig.RewardedRestartPlacementId);
            }
            catch
            {
                _pendingRewardedRestart = false;
                _ = InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.rewardCancelled();");
                _adSdk.LoadAd(MonetizationConfig.RewardedRestartPlacementId);
            }
        }

        private async Task PlayInterstitialAsync()
        {
            if (_noAds || !_adsInitialized || !_interstitialReady || _adSdk == null)
            {
                return;
            }

            _interstitialReady = false;
            try
            {
                await _adSdk.PlayAdAsync(new AdConfig(), MonetizationConfig.InterstitialPlacementId);
            }
            catch
            {
                _adSdk.LoadAd(MonetizationConfig.InterstitialPlacementId);
            }
        }

        private async Task PurchaseRemoveAdsAsync()
        {
            if (!MonetizationConfig.StorePurchaseConfigured)
            {
                await InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.purchaseUnavailable();");
                return;
            }

            try
            {
                if (_storeContext == null)
                {
                    _storeContext = StoreContext.GetDefault();
                }

                StorePurchaseResult result = await _storeContext.RequestPurchaseAsync(MonetizationConfig.RemoveAdsStoreId);
                if (result.Status == StorePurchaseStatus.Succeeded || result.Status == StorePurchaseStatus.AlreadyPurchased)
                {
                    _noAds = true;
                    await RefreshRemoveAdsLicenseAsync();
                    await PublishMonetizationStateAsync();
                }
                else
                {
                    await InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.purchaseCancelled();");
                }
            }
            catch
            {
                await InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.purchaseUnavailable();");
            }
        }

        private async Task RefreshRemoveAdsLicenseAsync()
        {
            if (!MonetizationConfig.StorePurchaseConfigured)
            {
                _noAds = false;
                return;
            }

            try
            {
                if (_storeContext == null)
                {
                    _storeContext = StoreContext.GetDefault();
                }

                StoreAppLicense license = await _storeContext.GetAppLicenseAsync();
                // This add-on is lifetime and cannot be revoked; preserve a confirmed purchase if
                // the Store license refresh is briefly stale after checkout.
                if (license.AddOnLicenses.ContainsKey(MonetizationConfig.RemoveAdsStoreId))
                {
                    _noAds = true;
                }
            }
            catch
            {
                // Keep the last confirmed license state when the Store is temporarily unavailable.
            }
        }

        private async Task PublishMonetizationStateAsync()
        {
            await RefreshRemoveAdsLicenseAsync();
            string state = "{\"adsConfigured\":" + (MonetizationConfig.AdsConfigured ? "true" : "false")
                + ",\"storeConfigured\":" + (MonetizationConfig.StorePurchaseConfigured ? "true" : "false")
                + ",\"rewardedReady\":" + (_rewardedReady ? "true" : "false")
                + ",\"noAds\":" + (_noAds ? "true" : "false") + "}";
            await InvokeGameScriptAsync("window.LeCercleMonetization&&window.LeCercleMonetization.setNativeState(" + state + ");");
        }

        private async Task PublishMonetizationStateOnUiThreadAsync()
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                _ = PublishMonetizationStateAsync();
            });
        }

        private async Task InvokeGameScriptAsync(string script)
        {
            try
            {
                await GameView.InvokeScriptAsync("eval", new[] { script });
            }
            catch
            {
                // The web content may be navigating or not ready yet.
            }
        }
    }
}
