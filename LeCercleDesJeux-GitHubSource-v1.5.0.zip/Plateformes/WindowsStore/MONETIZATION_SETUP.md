# Activer la monétisation Windows Store

La version Windows Store est préparée pour le modèle suivant : jeu gratuit, vidéos facultatives pour recommencer une grille, publicité de transition après quatre victoires, et achat intégré unique pour supprimer toutes les publicités. L’EXE d’essai, le site et Android ne chargent pas ce SDK.

Pour l’instant, les identifiants sont vides : aucune publicité ne démarre et les boutons de monétisation ne sont pas affichés. Ne publiez pas une version monétisée avant d’avoir terminé les étapes ci-dessous et vérifié les informations de confidentialité.

## 1. Créer les placements publicitaires

1. Créez un compte éditeur Liftoff Monetize (Vungle).
2. Ajoutez une application de type **Universal Windows Platform**.
3. Créez deux placements : un placement **rewarded** pour recommencer une grille et un placement **interstitial** pour les transitions.
4. Récupérez l’identifiant de l’application et les deux identifiants de placement.
5. Inscrivez-les dans `MonetizationConfig.cs` : `LiftoffAppId`, `RewardedRestartPlacementId` et `InterstitialPlacementId`.

Le SDK UWP actuellement publié par Liftoff est la version 6.11.6 (mise à jour du 30 septembre 2024). Sa documentation précise la prise en charge de Windows 11 et ARM64. Vérifiez auprès de Liftoff que ce SDK reste accepté pour votre compte et votre distribution avant la publication.

## 2. Créer l’achat « Sans publicité »

1. Réservez l’identité de l’application Windows Store dans Partner Center.
2. Créez un add-on durable, acheté une seule fois, nommé **Sans publicité**.
3. Copiez son Store ID dans `RemoveAdsStoreId` de `MonetizationConfig.cs`.
4. Vérifiez le prix, les pays de vente, le profil fiscal et le profil de paiement dans Partner Center.

L’achat est contrôlé par la licence durable retournée par Microsoft Store. Une fois reconnu, il désactive les vidéos récompensées et les publicités de transition ; le joueur peut alors recommencer une grille gratuitement.

## 3. Confidentialité et consentement

La page `privacy.html` du paquet Windows Store est générée avec la mention de Liftoff Monetize et un lien vers la désactivation des publicités ciblées. Le SDK Liftoff peut transmettre des identifiants publicitaires ou techniques, des informations d’appareil/réseau et des interactions avec les annonces. Dans l’Espace économique européen, le SDK peut présenter son dialogue de consentement.

Avant de soumettre, vérifiez que la politique publique liée à la fiche Store reprend également ces informations et reste accessible sans connexion. Dans Partner Center, indiquez correctement si le jeu est destiné aux enfants, puis complétez les déclarations de confidentialité et de publicité demandées.

## 4. Compiler et vérifier avant publication

Après avoir ajouté les quatre identifiants, relancez `build.ps1` depuis ce dossier. Vérifiez le paquet MSIX en environnement de test Store, l’achat de test, l’état « Sans publicité », le redémarrage au même niveau et le fait que le compteur de victoires, la série et les trophées restent intacts. Vérifiez aussi qu’une publicité interrompue ne redémarre pas la grille.

Ne cliquez jamais sur vos propres publicités réelles pour les tester. Utilisez les placements ou procédures de test fournis par Liftoff. La publication au public se fait ensuite depuis Partner Center après certification.
