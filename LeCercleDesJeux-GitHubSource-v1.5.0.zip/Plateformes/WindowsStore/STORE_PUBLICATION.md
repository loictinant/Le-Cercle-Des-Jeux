# Version Windows Store

Le projet est une application UWP empaquetée en MSIX, avec le jeu principal inclus hors ligne dans une WebView. Il ne contient pas les deux propositions visuelles non validées.

Le manifeste reprend l’éditeur utilisé par vos autres applications (`TINANT LOIC`, certificat `CN=D67E21A8-DC00-45EF-86D1-375158FB659F`). Le nom d’identité proposé est `TINANTLOIC.LeCercleDesJeux` ; vérifiez qu’il correspond à l’identité affichée dans Partner Center après avoir réservé le nom. Le package local signé est destiné au développement ; Microsoft re-signe les packages acceptés pour la distribution Store.

Le script `build.ps1` synchronise le jeu puis prépare le code de monétisation propre à l’édition Store. Il produit les packages dans `deliverables/LeCercleDesJeux/Windows`. La progression reste locale à chaque appareil et n’est pas partagée entre Windows et Android.

## Monétisation Windows Store

Le modèle prévu est un téléchargement gratuit, une vidéo facultative pour générer une nouvelle grille au niveau actuel, une courte publicité de transition après quatre victoires, et un achat intégré unique « Sans publicité ». Cet achat désactive toutes les publicités. La nouvelle grille ne modifie ni le nombre de victoires, ni les trophées, ni la série enregistrée.

La connexion publicitaire et l’achat sont volontairement inactifs tant que les identifiants ne sont pas configurés dans `MonetizationConfig.cs`. Il faut d’abord créer l’application et ses placements dans Liftoff Monetize (Vungle), puis créer l’extension durable « Sans publicité » dans Partner Center et copier son Store ID. Les étapes sont détaillées dans `MONETIZATION_SETUP.md`.

La version EXE d’essai, le site et l’APK Android ne chargent pas le SDK publicitaire et ne sont pas modifiés par cette intégration. La politique de confidentialité intégrée au paquet Store décrit le fournisseur publicitaire et son mécanisme de désactivation des annonces ciblées.
