namespace LeCercleDesJeux.Windows
{
    // These IDs are deliberately blank until the publisher accounts and Store add-on exist.
    // The Store edition keeps monetization hidden and inactive while any value is blank.
    internal static class MonetizationConfig
    {
        internal const string LiftoffAppId = "";
        internal const string RewardedRestartPlacementId = "";
        internal const string InterstitialPlacementId = "";
        internal const string RemoveAdsStoreId = "";

        internal static bool AdsConfigured
        {
            get
            {
                return !string.IsNullOrWhiteSpace(LiftoffAppId)
                    && !string.IsNullOrWhiteSpace(RewardedRestartPlacementId)
                    && !string.IsNullOrWhiteSpace(InterstitialPlacementId);
            }
        }

        internal static bool StorePurchaseConfigured
        {
            get { return !string.IsNullOrWhiteSpace(RemoveAdsStoreId); }
        }
    }
}
