(() => {
  'use strict';

  const state = { adsConfigured: false, storeConfigured: false, rewardedReady: false, noAds: false };
  let pendingReward = false;
  let completedRounds = 0;
  let interstitialPending = false;
  let toolsObserver = null;

  function notify(action) {
    try {
      if (window.external && typeof window.external.notify === 'function') {
        window.external.notify(`lcj:${action}`);
        return true;
      }
    } catch (_) { /* This bridge exists only in the Windows Store package. */ }
    return false;
  }

  function toast(message) {
    const target = document.getElementById('toast');
    if (!target) return;
    target.textContent = message;
    target.classList.add('show');
    window.setTimeout(() => target.classList.remove('show'), 2600);
  }

  function createOffer() {
    if (document.getElementById('lcjStoreOffer')) return;
    const heading = document.querySelector('.section-heading');
    if (!heading) return;
    const offer = document.createElement('aside');
    offer.id = 'lcjStoreOffer';
    offer.className = 'lcj-store-offer';
    offer.hidden = true;
    offer.innerHTML = '<span class="lcj-offer-icon" aria-hidden="true">✦</span><div class="lcj-offer-copy"><small>OPTION FACULTATIVE</small><b>Jouez sans publicité</b><span>Un achat unique dans le Microsoft Store. Les vidéos récompensées seront également désactivées.</span></div><button id="lcjRemoveAds" type="button">Sans publicité <span>→</span></button>';
    heading.parentNode.insertBefore(offer, heading);
  }

  function ensureRestartAction() {
    const tools = document.getElementById('toolsPanel');
    if (!tools || document.getElementById('lcjRestartWithAd')) return;
    const wrap = document.createElement('div');
    wrap.className = 'lcj-restart-wrap';
    wrap.innerHTML = '<button id="lcjRestartWithAd" type="button" class="lcj-restart-button" disabled><span aria-hidden="true">↻</span><span><b>Nouvelle grille</b><small>Vidéo facultative pour garder votre progression</small></span></button>';
    tools.appendChild(wrap);
  }

  function observeToolsPanel() {
    const tools = document.getElementById('toolsPanel');
    if (!tools || toolsObserver || !window.MutationObserver) return;
    toolsObserver = new MutationObserver(ensureRestartAction);
    toolsObserver.observe(tools, { childList: true });
  }

  function renderState() {
    createOffer();
    ensureRestartAction();

    const offer = document.getElementById('lcjStoreOffer');
    if (offer) offer.hidden = !state.storeConfigured || state.noAds;

    const restart = document.getElementById('lcjRestartWithAd');
    if (restart) {
      const buttonTitle = restart.querySelector('b');
      const buttonHelp = restart.querySelector('small');
      restart.closest('.lcj-restart-wrap').hidden = !(state.noAds || state.adsConfigured);
      const canRestart = state.noAds || (state.adsConfigured && state.rewardedReady);
      restart.disabled = !canRestart;
      if (buttonTitle) buttonTitle.textContent = state.noAds ? 'Nouvelle grille gratuite' : 'Nouvelle grille';
      if (buttonHelp) {
        buttonHelp.textContent = state.noAds
          ? 'Votre achat retire les pubs et garde vos statistiques'
          : state.rewardedReady
            ? 'Regardez une vidéo pour garder vos victoires'
            : 'La vidéo sera proposée quand elle sera disponible';
      }
    }
  }

  function restartCurrentGrid() {
    if (window.__LeCercleStore && typeof window.__LeCercleStore.restartCurrentGame === 'function') {
      const restarted = window.__LeCercleStore.restartCurrentGame();
      if (restarted) toast('Nouvelle grille lancée. Vos statistiques et trophées sont conservés.');
      return restarted;
    }
    toast('Ouvrez d’abord une partie pour recommencer une grille.');
    return false;
  }

  function setNativeState(next) {
    Object.assign(state, next || {});
    renderState();
  }

  function rewardCompleted() {
    pendingReward = false;
    restartCurrentGrid();
  }

  function rewardCancelled() {
    pendingReward = false;
    toast('Vidéo interrompue : la grille n’a pas été recommencée.');
    renderState();
  }

  function adUnavailable() {
    pendingReward = false;
    toast('Aucune vidéo n’est disponible pour le moment. Réessayez plus tard.');
    renderState();
  }

  window.LeCercleMonetization = {
    setNativeState,
    rewardCompleted,
    rewardCancelled,
    adUnavailable,
    purchaseUnavailable: () => toast('L’achat sera disponible après la publication sur le Microsoft Store.'),
    purchaseCancelled: () => toast('Aucun achat n’a été effectué.')
  };

  document.addEventListener('click', event => {
    const restart = event.target.closest('#lcjRestartWithAd');
    if (restart) {
      if (state.noAds) {
        restartCurrentGrid();
      } else if (!pendingReward && state.adsConfigured && state.rewardedReady) {
        pendingReward = true;
        notify('reward-restart');
      }
      return;
    }

    if (event.target.closest('#lcjRemoveAds')) {
      notify('remove-ads');
      return;
    }

    if (interstitialPending && state.adsConfigured && !state.noAds
        && event.target.closest('#backHome, [data-action="next"]')) {
      interstitialPending = false;
      window.setTimeout(() => notify('interstitial'), 150);
    }
  });

  const feedback = document.getElementById('boardFeedback');
  if (feedback && window.MutationObserver) {
    const observer = new MutationObserver(() => {
      const completed = feedback.classList.contains('success');
      if (!completed) {
        delete feedback.dataset.lcjAdCounted;
        return;
      }
      if (feedback.dataset.lcjAdCounted === 'true') return;
      feedback.dataset.lcjAdCounted = 'true';
      completedRounds++;
      if (!state.noAds && state.adsConfigured && completedRounds % 4 === 0) {
        interstitialPending = true;
      }
    });
    observer.observe(feedback, { attributes: true, attributeFilter: ['class'], childList: true });
  }

  renderState();
  observeToolsPanel();
  notify('state');
})();
