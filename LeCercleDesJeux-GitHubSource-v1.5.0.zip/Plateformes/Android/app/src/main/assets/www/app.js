(() => {
  'use strict';

  const MODES = [
    { id: 'sudoku', title: 'Sudoku', icon: '▦', short: 'Les chiffres trouvent leur place.', caption: 'UNE GRILLE, NEUF CHIFFRES', intro: 'Complétez chaque ligne, chaque colonne et chaque carré sans répéter de chiffre.' },
    { id: 'crossword', title: 'Mots croisés', icon: '✳', short: 'Croisez les mots et les idées.', caption: 'LES MOTS SE CROISENT', intro: 'Lisez les définitions, choisissez une case et remplissez les mots qui se croisent.' },
    { id: 'arrows', title: 'Mots fléchés', icon: '↘', short: 'Suivez les flèches jusqu’au mot.', caption: 'SUIVEZ LES FLÈCHES', intro: 'Chaque flèche indique le départ et la direction d’un mot. Complétez toute la grille.' },
    { id: 'search', title: 'Mots mêlés', icon: '⌕', short: 'Retrouvez les mots cachés.', caption: 'CHERCHEZ DANS LA GRILLE', intro: 'Repérez les mots de la liste dans la grille. Ils peuvent se lire dans plusieurs directions.' },
    { id: 'memory', title: 'Mémory', icon: '❋', short: 'Retrouvez les paires cachées.', caption: 'RETROUVEZ LES PAIRES', intro: 'Retournez deux cartes à la fois et rassemblez toutes les paires.' }
  ];

  const DIFFICULTIES = {
    relaxed: { label: 'Tranquille', explanation: 'Moins de cases à remplir et des grilles plus courtes.' },
    normal: { label: 'Classique', explanation: 'Un rythme équilibré, avec une difficulté qui monte au fil des niveaux.' },
    expert: { label: 'Expert', explanation: 'Davantage de cases, de mots ou de paires à résoudre.' }
  };

  const WORDS = [
    ['ABEILLE', 'Insecte qui fabrique le miel'], ['ABRICOT', 'Fruit orange d’été'], ['ANANAS', 'Fruit à couronne épineuse'], ['ARDOISE', 'Tablette pour écrire à la craie'],
    ['AROMATE', 'Plante qui parfume un plat'], ['AVION', 'Appareil qui vole'], ['BANANE', 'Fruit jaune en forme de croissant'], ['BATEAU', 'Il navigue sur l’eau'],
    ['BICHE', 'Femelle du cerf'], ['BOUSSOLE', 'Elle indique le nord'], ['CABANE', 'Petite maison dans les bois'], ['CAMPAGNE', 'Paysage de champs et de villages'],
    ['CANARD', 'Oiseau qui nage et fait coin-coin'], ['CAROTTE', 'Légume orange qui pousse en terre'], ['CERISE', 'Petit fruit rouge à noyau'], ['CHEVAL', 'Animal que l’on peut monter'],
    ['CITRON', 'Agrume jaune et acidulé'], ['CLAVIER', 'On y pose les doigts pour écrire'], ['COCCINELLE', 'Petit insecte rouge à points noirs'], ['COQUILLE', 'Enveloppe dure d’un œuf'],
    ['COTON', 'Fibre douce des vêtements'], ['COUTEAU', 'Ustensile pour couper'], ['CRAYON', 'On écrit ou dessine avec lui'], ['CUISINE', 'Pièce où l’on prépare les repas'],
    ['DESSERT', 'Dernier plat du repas'], ['DOMINO', 'Petit jeu de pièces à points'], ['ECUREUIL', 'Petit grimpeur à queue touffue'], ['ECOLE', 'Lieu où les enfants apprennent'],
    ['EPICE', 'Elle relève le goût d’un plat'], ['ETOILE', 'Lumière visible dans le ciel nocturne'], ['FARINE', 'Poudre pour faire du pain'], ['FEUILLE', 'Partie verte d’un arbre'],
    ['FLEUR', 'Elle s’ouvre au printemps'], ['FORET', 'Grand espace couvert d’arbres'], ['FROMAGE', 'Produit laitier affiné'], ['GATEAU', 'Dessert cuit au four'],
    ['GIRAFE', 'Animal au très long cou'], ['GUITARE', 'Instrument à cordes pincées'], ['HIVER', 'Saison la plus froide'], ['JARDIN', 'On y cultive fleurs et légumes'],
    ['JOURNAL', 'On y lit les nouvelles'], ['LANTERNE', 'Lampe portative protégée'], ['LAPIN', 'Animal aux longues oreilles'], ['MELON', 'Fruit d’été à chair sucrée'],
    ['MONTAGNE', 'Sommet que l’on peut gravir'], ['MOUTON', 'Animal qui donne de la laine'], ['MUSIQUE', 'Elle s’écoute et se joue'], ['NUAGE', 'Masse blanche dans le ciel'],
    ['OISEAU', 'Animal à plumes qui vole'], ['ORANGE', 'Agrume rond et coloré'], ['PAPILLON', 'Insecte aux ailes colorées'], ['PARAPLUIE', 'Il protège de la pluie'],
    ['PAYSAGE', 'Vue que l’on découvre au loin'], ['PIMENT', 'Petit fruit qui peut être fort'], ['POMME', 'Fruit croquant du verger'], ['POULE', 'Elle pond des œufs'],
    ['RENARD', 'Animal roux rusé'], ['RIVIERE', 'Cours d’eau qui rejoint un fleuve'], ['SALADE', 'Plat frais souvent vert'], ['SOURIS', 'Petit rongeur ou accessoire d’ordinateur'],
    ['TABLEAU', 'Surface pour écrire ou peindre'], ['TOMATE', 'Fruit rouge souvent utilisé en salade'], ['TORTUE', 'Reptile protégé par une carapace'], ['VALISE', 'On y range ses affaires en voyage'],
    ['VELOURS', 'Tissu doux au toucher'], ['VIOLETTE', 'Petite fleur au parfum délicat'], ['VOYAGE', 'Déplacement vers une autre région'], ['ZEBRE', 'Animal rayé noir et blanc'],
    ['AIGLE', 'Grand oiseau qui plane'], ['AILE', 'Elle permet à un oiseau de voler'], ['ARBRE', 'Il porte des branches et des feuilles'], ['AUTOMNE', 'Saison des feuilles rousses'], ['BALAI', 'Outil pour nettoyer le sol'],
    ['BALCON', 'Petite terrasse en hauteur'], ['BALLON', 'On le lance ou on le frappe en jouant'], ['BARQUE', 'Petit bateau à rames'], ['BASILIC', 'Plante parfumée souvent mise dans le pesto'], ['BIBLIOTHEQUE', 'Lieu où l’on emprunte des livres'],
    ['BOUTON', 'Petite pièce qui ferme un vêtement'], ['BRANCHE', 'Elle pousse sur le tronc d’un arbre'], ['BUREAU', 'Table pour travailler ou meuble du directeur'], ['CANNELLE', 'Épice parfumée souvent mise dans un dessert'], ['CARTON', 'Boîte légère pour ranger ou déménager'],
    ['CHAPEAU', 'On le porte sur la tête'], ['CHATEAU', 'Grande demeure fortifiée ou royale'], ['CHENILLE', 'Larve qui deviendra parfois un papillon'], ['CHIEN', 'Compagnon fidèle qui aboie'], ['CHOCOLAT', 'Douceur préparée avec du cacao'],
    ['CLOCHE', 'Elle sonne dans un clocher'], ['CLOWN', 'Artiste qui fait rire au cirque'], ['COLLINE', 'Petite hauteur dans le paysage'], ['COLOMBE', 'Oiseau blanc, symbole de paix'], ['CONCOMBRE', 'Légume vert souvent servi en salade'],
    ['CORBEAU', 'Grand oiseau noir au cri rauque'], ['CORDE', 'Elle peut servir à grimper ou à attacher'], ['CORAIL', 'Il forme des récifs colorés dans la mer'], ['COUSSIN', 'Petit oreiller posé sur un canapé'], ['CROISSANT', 'Viennoiserie en forme de lune'],
    ['CUILLERE', 'Ustensile pour manger une soupe'], ['DAUPHIN', 'Mammifère marin réputé joueur'], ['DENT', 'Elle sert à mâcher les aliments'], ['DIAMANT', 'Pierre précieuse très dure'], ['DINOSAURE', 'Animal géant disparu il y a longtemps'],
    ['DRAGON', 'Créature imaginaire qui crache du feu'], ['ECHARPE', 'Elle tient chaud autour du cou'], ['ECLAIR', 'Éclair lumineux dans un orage ou gâteau au chocolat'], ['ENCRE', 'Liquide utilisé pour écrire'], ['ESCARGOT', 'Petit animal à coquille qui avance lentement'],
    ['FENETRE', 'Ouverture vitrée dans un mur'], ['FLAMME', 'Partie brillante d’un feu'], ['FLOCON', 'Petit cristal de neige'], ['FONTAINE', 'Elle fait couler de l’eau sur une place'], ['FOURMI', 'Petit insecte qui vit en colonie'],
    ['FRAMBOISE', 'Petit fruit rouge composé de grains'], ['FUSEE', 'Elle s’envole vers les étoiles'], ['GALAXIE', 'Immense ensemble d’étoiles dans l’espace'], ['GARAGE', 'Lieu où l’on range une voiture'], ['GOMME', 'Elle efface les traits de crayon'],
    ['GRENOUILLE', 'Amphibien qui saute près de l’eau'], ['GROSEILLE', 'Petite baie rouge en grappe'], ['HARICOT', 'Légume vert ou graine blanche'], ['HORLOGE', 'Elle indique l’heure accrochée au mur'], ['JONQUILLE', 'Fleur jaune qui annonce le printemps'],
    ['LACET', 'Il tient une chaussure fermée'], ['LION', 'Grand félin à crinière'], ['LOUPE', 'Elle grossit les petits détails'], ['LUCIOLE', 'Petit insecte qui brille dans la nuit'], ['LUNETTE', 'Elle aide à mieux voir'],
    ['MACHINE', 'Appareil qui réalise un travail'], ['MAISON', 'Bâtiment où l’on habite'], ['MARTEAU', 'Outil pour enfoncer un clou'], ['MEDUSE', 'Animal marin transparent aux longs filaments'], ['MOUETTE', 'Oiseau blanc que l’on voit près du port'],
    ['MUSEE', 'Lieu où l’on découvre des œuvres'], ['NAVIRE', 'Grand bateau qui traverse les mers'], ['NEIGE', 'Elle tombe en flocons pendant l’hiver'], ['PAILLE', 'Petit tube pour boire une boisson'], ['PALAIS', 'Bâtiment majestueux d’un roi'],
    ['PANIER', 'On y transporte des fruits ou des courses'], ['PANTHERE', 'Félin agile au pelage tacheté'], ['PIRATE', 'Marin d’aventure qui cherche un trésor'], ['PLUME', 'Elle pousse sur un oiseau et sert à écrire'], ['PONT', 'Construction pour franchir une rivière'],
    ['POIVRE', 'Épice noire que l’on met sur les plats'], ['PRAIRIE', 'Grand champ couvert d’herbe'], ['PRINCESSE', 'Fille d’un roi dans les contes'], ['PYJAMA', 'Vêtement confortable pour dormir'], ['QUARTZ', 'Minéral que l’on trouve dans certaines roches'],
    ['RAQUETTE', 'On l’utilise pour jouer au tennis'], ['ROBOT', 'Machine qui peut effectuer des tâches'], ['ROSEAU', 'Grande plante qui pousse au bord de l’eau'], ['RUBAN', 'Bande décorative de tissu'], ['SABLIER', 'Objet qui mesure le temps avec du sable'],
    ['SAVON', 'Il mousse pour laver les mains'], ['SIRENE', 'Personnage marin avec une queue de poisson'], ['SOLEIL', 'Étoile qui éclaire la Terre'], ['SPECTACLE', 'Représentation que l’on regarde en public'], ['TAMBOUR', 'Instrument que l’on frappe avec des baguettes'],
    ['TIGRE', 'Grand félin rayé'], ['TORCHE', 'Lampe portative à pile'], ['TOURNESOL', 'Grande fleur qui suit la lumière'], ['TRESOR', 'Richesse cachée que l’on cherche dans les histoires'], ['TROMPETTE', 'Instrument à vent brillant et cuivré'],
    ['TULIPE', 'Fleur de printemps en forme de coupe'], ['VAGUE', 'Elle roule à la surface de la mer'], ['VOLCAN', 'Montagne qui peut rejeter de la lave'], ['YACHT', 'Bateau de plaisance élégant'], ['YAOURT', 'Dessert frais au lait fermenté']
  ].map(([word, clue]) => ({ word, clue }));

  const EMOJIS = ['🍋','🌿','🐚','🍓','🪁','🌼','🍐','🦋','🍄','🌙','🐝','🍊','🐢','🪻','🐞','🍇','🌵','🧩','🌻','🦊','🍉','🐌','🪺','🌈'];
  const TROPHIES = [
    { id: 'first', icon: '🌱', title: 'Première grille', description: 'Terminez votre première partie.', category: 'Découverte', tier: 'Bronze', unlocked: () => save.solved >= 1 },
    { id: 'sudoku', icon: '🔢', title: 'Le goût des chiffres', description: 'Terminez un sudoku.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.sudoku || 0) >= 1 },
    { id: 'crossword', icon: '✳️', title: 'Mots croisés', description: 'Terminez une grille de mots croisés.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.crossword || 0) >= 1 },
    { id: 'arrows', icon: '➡️', title: 'Dans la bonne direction', description: 'Terminez une grille de mots fléchés.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.arrows || 0) >= 1 },
    { id: 'search', icon: '🔎', title: 'Œil de lynx', description: 'Trouvez tous les mots cachés.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.search || 0) >= 1 },
    { id: 'memory', icon: '🧠', title: 'Mémoire d’éléphant', description: 'Retrouvez toutes les paires.', category: 'Découverte', tier: 'Bronze', unlocked: () => (save.modeWins.memory || 0) >= 1 },
    { id: 'no-hints', icon: '🧭', title: 'Sans aide', description: 'Terminez une partie sans demander d’indice.', category: 'Défis', tier: 'Argent', unlocked: () => !!game && game.hintsUsed === 0 },
    { id: 'perfect', icon: '💎', title: 'Grille parfaite', description: 'Terminez une partie sans erreur signalée.', category: 'Défis', tier: 'Or', unlocked: () => !!game && game.mistakes === 0 },
    { id: 'streak', icon: '🔥', title: 'Belle série', description: 'Terminez cinq parties de suite.', category: 'Assiduité', tier: 'Argent', unlocked: () => save.streak >= 5 },
    { id: 'daily-1', icon: '☀️', title: 'Rendez-vous du jour', description: 'Terminez un défi quotidien.', category: 'Défis quotidiens', tier: 'Bronze', unlocked: () => (save.dailyCompletions || 0) >= 1 },
    { id: 'daily-7', icon: '📅', title: 'Une semaine fidèle', description: 'Terminez les défis quotidiens 7 jours de suite.', category: 'Défis quotidiens', tier: 'Argent', unlocked: () => (save.dailyStreak || 0) >= 7 },
    { id: 'daily-30', icon: '🌙', title: 'Un mois de défis', description: 'Terminez les défis quotidiens 30 jours de suite.', category: 'Défis quotidiens', tier: 'Or', unlocked: () => (save.dailyStreak || 0) >= 30 },
    { id: 'daily-100', icon: '🌟', title: 'Cent jours de curiosité', description: 'Terminez les défis quotidiens 100 jours de suite.', category: 'Défis quotidiens', tier: 'Diamant', unlocked: () => (save.dailyStreak || 0) >= 100 },
    { id: 'ten', icon: '🏅', title: 'Régulier', description: 'Terminez dix parties.', category: 'Assiduité', tier: 'Bronze', unlocked: () => save.solved >= 10 },
    { id: 'fifty', icon: '🏆', title: 'Passionné', description: 'Terminez cinquante parties.', category: 'Assiduité', tier: 'Argent', unlocked: () => save.solved >= 50 },
    { id: 'memory-pro', icon: '🎴', title: 'Mémoire affûtée', description: 'Finissez un mémory avec au plus deux essais de plus que le nombre de paires, sans indice.', category: 'Défis', tier: 'Or', unlocked: () => !!game && activeMode === 'memory' && game.hintsUsed === 0 && game.moves <= game.pairs + 2 },
    ...MODES.flatMap(mode => [
      { id: `wins-${mode.id}-5`, icon: mode.icon, title: `${mode.title} assidu`, description: `Terminez 5 parties de ${mode.title.toLowerCase()}.`, category: 'Spécialités', tier: 'Bronze', unlocked: () => (save.modeWins[mode.id] || 0) >= 5 },
      { id: `wins-${mode.id}-25`, icon: '🥈', title: `Expert ${mode.title.toLowerCase()}`, description: `Terminez 25 parties de ${mode.title.toLowerCase()}.`, category: 'Spécialités', tier: 'Argent', unlocked: () => (save.modeWins[mode.id] || 0) >= 25 },
      { id: `wins-${mode.id}-100`, icon: '🏆', title: `Maître ${mode.title.toLowerCase()}`, description: `Terminez 100 parties de ${mode.title.toLowerCase()}.`, category: 'Spécialités', tier: 'Diamant', unlocked: () => (save.modeWins[mode.id] || 0) >= 100 }
    ]),
    ...MODES.map(mode => ({ id: `clean-${mode.id}`, icon: '✨', title: `Sans faute : ${mode.title}`, description: `Terminez une partie de ${mode.title.toLowerCase()} sans erreur signalée.`, category: 'Défis', tier: 'Argent', unlocked: () => (save.cleanWins[mode.id] || 0) >= 1 })),
    ...MODES.map(mode => ({ id: `no-hint-${mode.id}`, icon: '🧭', title: `En autonomie : ${mode.title}`, description: `Terminez une partie de ${mode.title.toLowerCase()} sans indice.`, category: 'Défis', tier: 'Argent', unlocked: () => (save.noHintWins[mode.id] || 0) >= 1 })),
    ...[25, 100, 250, 500].map(total => ({ id: `total-${total}`, icon: total < 100 ? '🎖️' : '🏅', title: `${total} parties`, description: `Terminez ${total} parties, tous jeux confondus.`, category: 'Assiduité', tier: total < 100 ? 'Argent' : total < 250 ? 'Or' : 'Diamant', unlocked: () => save.solved >= total })),
    ...[3, 10, 25].map(streak => ({ id: `streak-${streak}`, icon: '🔥', title: `Série de ${streak}`, description: `Terminez ${streak} parties d’affilée sans abandonner.`, category: 'Assiduité', tier: streak < 10 ? 'Bronze' : streak < 25 ? 'Or' : 'Diamant', unlocked: () => save.streak >= streak })),
    ...[
      { modeId: 'sudoku', seconds: 300 }, { modeId: 'crossword', seconds: 300 }, { modeId: 'arrows', seconds: 300 },
      { modeId: 'search', seconds: 120 }, { modeId: 'memory', seconds: 180 }
    ].map(challenge => ({ id: `speed-${challenge.modeId}`, icon: '⏱️', title: `Coup de ${modeInfo(challenge.modeId).title.toLowerCase()}`, description: `Terminez ${modeInfo(challenge.modeId).title.toLowerCase()} en ${Math.floor(challenge.seconds / 60)} min maximum.`, category: 'Défis', tier: 'Or', unlocked: () => Number.isFinite(save.fastest[challenge.modeId]) && save.fastest[challenge.modeId] <= challenge.seconds })),
    { id: 'memory-exact', icon: '🃏', title: 'Du premier coup', description: 'Trouvez toutes les paires du mémory sans vous tromper ni demander d’indice.', category: 'Défis', tier: 'Diamant', unlocked: () => !!game && activeMode === 'memory' && game.hintsUsed === 0 && game.moves === game.pairs },
    { id: 'clean-streak-3', icon: '🌟', title: 'Trois parties impeccables', description: 'Terminez trois parties de suite sans erreur signalée.', category: 'Défis', tier: 'Or', unlocked: () => save.cleanStreak >= 3 },
    ...MODES.map(mode => ({ id: `no-hint-${mode.id}-10`, icon: '🧭', title: `Sans indice, toujours : ${mode.title}`, description: `Terminez 10 parties de ${mode.title.toLowerCase()} sans utiliser d’indice.`, category: 'Spécialités', tier: 'Diamant', unlocked: () => (save.noHintWins[mode.id] || 0) >= 10 }))
  ];
  const SAVE_KEY = 'le-cercle-des-jeux-v1';
  const MANUAL_SAVE_KEY = 'le-cercle-des-jeux-manual-v1';
  const AUTO_SAVE_KEY = 'le-cercle-des-jeux-auto-v1';
  const emptySave = () => ({ levels: {}, solved: 0, streak: 0, bestStreak: 0, lastMode: 'sudoku', difficulty: 'normal', trophies: {}, modeWins: {}, cleanWins: {}, noHintWins: {}, fastest: {}, modeStats: {}, cleanStreak: 0, dailyCompletions: 0, dailyStreak: 0, lastDailyDate: '' });
  let save = emptySave();
  try {
    const stored = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}');
    save = { ...emptySave(), ...stored, trophies: { ...emptySave().trophies, ...(stored.trophies || {}) }, modeWins: { ...emptySave().modeWins, ...(stored.modeWins || {}) }, cleanWins: { ...emptySave().cleanWins, ...(stored.cleanWins || {}) }, noHintWins: { ...emptySave().noHintWins, ...(stored.noHintWins || {}) }, fastest: { ...emptySave().fastest, ...(stored.fastest || {}) }, modeStats: { ...(stored.modeStats || {}) } };
  } catch (_) { /* Le jeu reste jouable si le navigateur désactive le stockage local. */ }

  const $ = id => document.getElementById(id);
  const homeView = $('homeView'), gameView = $('gameView'), gameGrid = $('gameGrid');
  const boardMount = $('boardMount'), toolsPanel = $('toolsPanel'), feedback = $('boardFeedback');
  let activeMode = null, activeLevel = 1, activeDifficulty = 'normal', game = null, timerHandle = null, autoSavePulse = null, autoSaveHandle = null, startedAt = 0, toastHandle = null;
  let searchPointerSelection = null, suppressNextSearchClick = false;
  let activeChallenge = null, challengeRandomState = null;
  let trophyFilter = 'all', trophyNotificationQueue = [], trophyNotificationTimer = null, activeTrophyNotification = null;

  function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (_) { /* Progression conservée en mémoire pour cette session. */ } }
  function serializeSpecial(_key, value) { if (value instanceof Map) return { __lcdjType: 'Map', entries: [...value] }; if (value instanceof Set) return { __lcdjType: 'Set', values: [...value] }; return value; }
  function reviveSpecial(_key, value) { if (value && value.__lcdjType === 'Map') return new Map(value.entries); if (value && value.__lcdjType === 'Set') return new Set(value.values); return value; }
  function manualSaveExists() { try { return !!localStorage.getItem(MANUAL_SAVE_KEY); } catch (_) { return false; } }
  function automaticSaveExists() { try { const item = JSON.parse(localStorage.getItem(AUTO_SAVE_KEY) || 'null'); return !!item && item.schema === 1 && MODES.some(mode => mode.id === item.mode) && !!item.state; } catch (_) { return false; } }
  function snapshotCurrentGame() {
    if (!game || !activeMode || game.finished) return null;
    const state = JSON.parse(JSON.stringify(game, serializeSpecial), reviveSpecial);
    if (activeMode === 'memory' && state.locked) { state.cards.forEach(card => { if (!card.matched) card.open = false; }); state.open = []; state.locked = false; }
    return { schema: 1, mode: activeMode, level: activeLevel, difficulty: activeDifficulty, challenge: activeChallenge, elapsed: Math.max(0, Math.floor((Date.now() - startedAt) / 1000)), state };
  }
  function persistAutomaticSave() {
    clearTimeout(autoSaveHandle); autoSaveHandle = null;
    const snapshot = snapshotCurrentGame(); if (!snapshot) return false;
    try {
      localStorage.setItem(AUTO_SAVE_KEY, JSON.stringify(snapshot, serializeSpecial));
      const status = $('autoSaveStatus'); if (status) status.textContent = 'Partie enregistrée automatiquement';
      const resume = $('resumeAutoHome'); if (resume) resume.classList.remove('hidden');
      return true;
    } catch (_) {
      const status = $('autoSaveStatus'); if (status) status.textContent = 'Sauvegarde automatique indisponible';
      return false;
    }
  }
  function scheduleAutomaticSave() {
    if (!game || game.finished || !activeMode) return;
    clearTimeout(autoSaveHandle);
    const status = $('autoSaveStatus'); if (status) status.textContent = 'Enregistrement…';
    autoSaveHandle = setTimeout(persistAutomaticSave, 450);
  }
  function startAutomaticSavePulse() {
    clearInterval(autoSavePulse);
    autoSavePulse = setInterval(persistAutomaticSave, 15000);
  }
  function clearAutomaticSave() {
    clearTimeout(autoSaveHandle); clearInterval(autoSavePulse); autoSaveHandle = null; autoSavePulse = null;
    try { localStorage.removeItem(AUTO_SAVE_KEY); } catch (_) { /* La fin de partie reste valide même sans stockage. */ }
    const resume = $('resumeAutoHome'); if (resume) resume.classList.add('hidden');
  }
  function saveCurrentGame() {
    if (!game || !activeMode || game.finished) { showToast('Aucune partie en cours à sauvegarder.'); return; }
    if (game.locked) { showToast('Attendez que les cartes soient de nouveau accessibles.'); return; }
    const snapshot = { schema: 1, mode: activeMode, level: activeLevel, difficulty: activeDifficulty, challenge: activeChallenge, elapsed: Math.max(0, Math.floor((Date.now() - startedAt) / 1000)), state: game };
    try { localStorage.setItem(MANUAL_SAVE_KEY, JSON.stringify(snapshot, serializeSpecial)); $('restoreManualHome').classList.remove('hidden'); showToast('Partie sauvegardée sur cet appareil.'); }
    catch (_) { showToast('Impossible d’enregistrer la partie sur cet appareil.'); }
  }
  function restoreGameSnapshot(snapshot = null, storageKey = MANUAL_SAVE_KEY) {
    try {
      const data = snapshot || JSON.parse(localStorage.getItem(storageKey) || 'null', reviveSpecial);
      if (!data || data.schema !== 1 || !MODES.some(item => item.id === data.mode) || !data.state || typeof data.state !== 'object') throw new Error('Sauvegarde invalide.');
       clearInterval(timerHandle); clearInterval(autoSavePulse); clearTimeout(autoSaveHandle); activeMode = data.mode; activeChallenge = data.challenge || null; activeLevel = Math.max(1, Number(data.level) || 1); game = data.state; game.hintStage = Math.max(0, Math.min(2, Number(game.hintStage) || 0));
      game.hintsUsed = Math.max(0, Number(game.hintsUsed) || 0); game.mistakes = Math.max(0, Number(game.mistakes) || 0);
      if (activeMode === 'memory' && game.locked) { game.cards.forEach(card => { if (!card.matched) card.open = false; }); game.open = []; game.locked = false; }
      activeDifficulty = DIFFICULTIES[data.difficulty] ? data.difficulty : (save.difficulty || 'normal');
      challengeRandomState = activeChallenge ? (Number(activeChallenge.seed) >>> 0) : null;
      const info = modeInfo(activeMode); $('gameIcon').textContent = info.icon; $('gameTitle').textContent = info.title; $('gameEyebrow').textContent = `JEU DE RÉFLEXION · ${info.caption}`; $('levelLabel').textContent = pad(activeLevel); $('boardCaption').textContent = activeChallenge ? `DÉFI DU JOUR · ${info.caption}` : info.caption;
      $('timerLabel').textContent = clockText(Number(data.elapsed) || 0); feedback.className = 'feedback'; feedback.textContent = ''; homeView.classList.add('hidden'); gameView.classList.remove('hidden');
      startedAt = Date.now() - (Math.max(0, Number(data.elapsed) || 0) * 1000); timerHandle = setInterval(() => { $('timerLabel').textContent = clockText(Math.floor((Date.now() - startedAt) / 1000)); }, 1000); startAutomaticSavePulse();
      if (activeMode === 'sudoku') renderSudoku(); else if (activeMode === 'crossword' || activeMode === 'arrows') renderWordGrid(); else if (activeMode === 'search') renderWordSearch(); else renderMemory();
       renderTools(); updateLevelExplanation(); scheduleAutomaticSave(); showToast('Partie restaurée.'); return true;
    } catch (error) { showToast(error.message || 'Impossible de restaurer cette partie.'); return false; }
  }
  function downloadBackup() {
    if (game?.locked) { showToast('Attendez que les cartes soient de nouveau accessibles avant l’export.'); return; }
    const payload = { product: 'Le Cercle des jeux', schema: 1, exportedAt: new Date().toISOString(), progression: save, activeGame: game && !game.finished ? { mode: activeMode, level: activeLevel, challenge: activeChallenge, elapsed: Math.max(0, Math.floor((Date.now() - startedAt) / 1000)), state: game } : null };
    const blob = new Blob([JSON.stringify(payload, serializeSpecial, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'le-cercle-des-jeux-sauvegarde.json'; a.click(); URL.revokeObjectURL(url);
  }
  async function importBackup(file) {
    try {
      const payload = JSON.parse(await file.text(), reviveSpecial); if (!payload || payload.product !== 'Le Cercle des jeux' || payload.schema !== 1 || !payload.progression) throw new Error('Ce fichier n’est pas une sauvegarde du jeu.');
      save = { ...emptySave(), ...payload.progression, trophies: { ...payload.progression.trophies }, modeWins: { ...payload.progression.modeWins }, cleanWins: { ...payload.progression.cleanWins }, noHintWins: { ...payload.progression.noHintWins }, fastest: { ...payload.progression.fastest }, modeStats: { ...(payload.progression.modeStats || {}) } }; persist(); renderHome();
      if (payload.activeGame) { localStorage.setItem(MANUAL_SAVE_KEY, JSON.stringify({ schema: 1, ...payload.activeGame }, serializeSpecial)); restoreGameSnapshot(); }
      else showToast('Progression restaurée.');
    } catch (error) { showToast(error.message || 'Fichier de sauvegarde illisible.'); }
  }
  function updateDailyRecord() {
    const date = String(activeChallenge?.date || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return;
    if (save.lastDailyDate === date) return;
    save.dailyCompletions = (save.dailyCompletions || 0) + 1;
    const previous = save.lastDailyDate ? new Date(`${save.lastDailyDate}T12:00:00Z`) : null; const current = new Date(`${date}T12:00:00Z`);
    const yesterday = previous ? new Date(current.getTime() - 86400000).toISOString().slice(0, 10) : '';
    save.dailyStreak = save.lastDailyDate === yesterday ? (save.dailyStreak || 0) + 1 : 1; save.lastDailyDate = date;
  }
  function trophyProgress(trophy) {
    if (save.trophies[trophy.id]) return 100;
    let current = 0, target = 1;
    let match = trophy.id.match(/^total-(\d+)$/); if (match) { current = save.solved || 0; target = Number(match[1]); }
    else if ((match = trophy.id.match(/^streak-(\d+)$/))) { current = save.streak || 0; target = Number(match[1]); }
    else if ((match = trophy.id.match(/^wins-([a-z]+)-(\d+)$/))) { current = save.modeWins[match[1]] || 0; target = Number(match[2]); }
    else if ((match = trophy.id.match(/^no-hint-([a-z]+)-10$/))) { current = save.noHintWins[match[1]] || 0; target = 10; }
    else if ((match = trophy.id.match(/^daily-(\d+)$/))) { current = save.dailyStreak || 0; target = Number(match[1]); }
    else if (trophy.id === 'first') { current = save.solved || 0; }
    else if (['sudoku','crossword','arrows','search','memory'].includes(trophy.id)) current = save.modeWins[trophy.id] || 0;
    return Math.min(99, Math.floor((current / target) * 100));
  }
  function applyTheme() { const dark = localStorage.getItem('lcdj.theme') === 'dark'; document.documentElement.dataset.theme = dark ? 'dark' : 'light'; $('themeToggle').innerHTML = dark ? '☀ <span>Thème clair</span>' : '☾ <span>Thème foncé</span>'; $('themeToggle').setAttribute('aria-label', dark ? 'Activer le thème clair' : 'Activer le thème foncé'); }
  function applyAccessibilitySettings() {
    let size = 'normal', contrast = false;
    try { size = localStorage.getItem('lcdj.textSize') || 'normal'; contrast = localStorage.getItem('lcdj.highContrast') === 'true'; } catch (_) { /* Les réglages restent disponibles pendant cette session. */ }
    if (!['normal', 'large', 'largest'].includes(size)) size = 'normal';
    document.documentElement.dataset.textSize = size; document.documentElement.dataset.contrast = contrast ? 'high' : 'normal';
    $('textScaleSelect').value = size; $('highContrastToggle').checked = contrast;
  }
  function closeAccessibilityPanel() { $('accessibilityPanel').classList.add('hidden'); $('accessibilityToggle').setAttribute('aria-expanded', 'false'); }
  async function shareGame() { const url = 'https://loic-apps.duckdns.org/index.html'; const data = { title: 'Le Cercle des jeux', text: 'Des jeux de réflexion gratuits : sudoku, mots croisés, mots fléchés, mots mêlés et mémory.', url }; try { if (navigator.share) await navigator.share(data); else if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(url); showToast('Lien du jeu copié.'); } else { window.prompt('Copiez le lien du jeu :', url); } } catch (error) { if (error.name !== 'AbortError') showToast('Le partage n’a pas pu être ouvert.'); } }
  function modeInfo(id) { return MODES.find(mode => mode.id === id) || MODES[0]; }
  function levelFor(id) { return Math.max(1, Number(save.levels[id]) || 1); }
  function puzzleSettings(modeId, level = activeLevel, difficulty = activeDifficulty) {
    const n = Math.max(1, Number(level) || 1);
    if (modeId === 'sudoku') {
      const profile = difficulty === 'relaxed' ? [28, 0.45, 46] : difficulty === 'expert' ? [42, 0.9, 64] : [34, 0.7, 55];
      return { holes: Math.min(profile[2], profile[0] + Math.floor((n - 1) * profile[1])) };
    }
    if (modeId === 'crossword' || modeId === 'arrows') {
      const target = difficulty === 'relaxed' ? 4 + Math.floor((n - 1) / 3) : difficulty === 'expert' ? 6 + n - 1 : 5 + Math.floor((n - 1) / 2);
      return { words: Math.min(difficulty === 'expert' ? 12 : 10, target) };
    }
    if (modeId === 'search') {
      const count = difficulty === 'relaxed' ? 5 + Math.floor((n - 1) / 6) : difficulty === 'expert' ? 9 + Math.floor((n - 1) / 2) : 7 + Math.floor((n - 1) / 4);
      return { words: Math.min(14, count), size: difficulty === 'relaxed' ? 11 : difficulty === 'expert' || n > 8 ? 14 : 12 };
    }
    const pairs = difficulty === 'relaxed' ? 3 + Math.floor((n - 1) / 4) : difficulty === 'expert' ? 6 + Math.floor((n - 1) / 2) : 4 + Math.floor((n - 1) / 2);
    return { pairs: Math.min(12, pairs) };
  }
  function updateLevelExplanation() {
    const label = $('levelExplanation'); if (!label || !game) return;
    const difficulty = DIFFICULTIES[activeDifficulty] || DIFFICULTIES.normal;
    let detail = '';
    if (activeMode === 'sudoku') detail = `${game.values.flat().filter(value => value === 0).length} cases à compléter`;
    else if (activeMode === 'crossword' || activeMode === 'arrows') detail = `${game.entries.length} mots à trouver`;
    else if (activeMode === 'search') detail = `${game.entries.length} mots dans une grille de ${game.size} × ${game.size}`;
    else if (activeMode === 'memory') detail = `${game.pairs} paires à mémoriser`;
    label.textContent = `Niveau ${pad(activeLevel)} · ${difficulty.label} : ${detail}.`;
  }
  function random() {
    if (challengeRandomState === null) return Math.random();
    challengeRandomState = (challengeRandomState + 0x6D2B79F5) >>> 0;
    let value = challengeRandomState;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  }
  function shuffle(list) { const out = [...list]; for (let i = out.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [out[i], out[j]] = [out[j], out[i]]; } return out; }
  function pad(value) { return String(value).padStart(2, '0'); }
  function clockText(seconds) { return `${pad(Math.floor(seconds / 60))}:${pad(seconds % 60)}`; }
  function renderHome() {
    gameGrid.innerHTML = MODES.map(mode => `<button class="game-card" data-game="${mode.id}" aria-label="Lancer ${mode.title}, niveau ${pad(levelFor(mode.id))}">
      <div class="game-card-top"><span class="game-symbol">${mode.icon}</span><span class="card-level">NIVEAU ${pad(levelFor(mode.id))}</span></div>
      <h3>${mode.title}</h3><p>${mode.short}</p><div class="card-footer"><span>∞ &nbsp;Niveaux sans fin</span><span class="card-arrow">↗</span></div>
    </button>`).join('');
    $('solvedCount').textContent = save.solved || 0;
    $('bestStreak').textContent = save.bestStreak || 0;
    $('restoreManualHome').classList.toggle('hidden', !manualSaveExists());
    $('resumeAutoHome').classList.toggle('hidden', !automaticSaveExists());
    $('difficultySelect').value = DIFFICULTIES[save.difficulty] ? save.difficulty : 'normal';
    $('difficultyDescription').textContent = DIFFICULTIES[$('difficultySelect').value].explanation;
    renderTrophySummary();
    renderModeStatistics();
    if (save.solved > 0) {
      $('progressTitle').textContent = `${save.solved} partie${save.solved > 1 ? 's' : ''} terminée${save.solved > 1 ? 's' : ''}`;
      $('progressSub').textContent = `Votre meilleure série : ${save.bestStreak || 0} partie${save.bestStreak === 1 ? '' : 's'}.`;
      $('continueButton').innerHTML = `Continuer au niveau ${pad(levelFor(save.lastMode))} <span>→</span>`;
    }
  }

  function renderModeStatistics() {
    const mount = $('modeStatsGrid');
    if (!mount) return;
    mount.innerHTML = MODES.map(mode => {
      const stats = save.modeStats[mode.id] || {};
      const recorded = Number(stats.sessions) || 0;
      const average = recorded ? clockText(Math.round((Number(stats.totalSeconds) || 0) / recorded)) : 'À venir';
      const best = Number.isFinite(save.fastest[mode.id]) ? clockText(save.fastest[mode.id]) : '—';
      const mistakes = Number(stats.mistakes) || 0;
      return `<article class="mode-stat-card"><div class="mode-stat-title"><span aria-hidden="true">${mode.icon}</span><h3>${mode.title}</h3></div><div class="mode-stat-values"><div><b>${save.modeWins[mode.id] || 0}</b><small>parties</small></div><div><b>${best}</b><small>record</small></div><div><b>${average}</b><small>moyenne</small></div><div><b>${Number(stats.hints) || 0}</b><small>indices</small></div></div><p>${mistakes} erreur${mistakes === 1 ? '' : 's'} signalée${mistakes === 1 ? '' : 's'} dans cette version</p></article>`;
    }).join('');
  }

  function hintActionMarkup() {
    const next = Math.min(3, (Number(game?.hintStage) || 0) + 1);
    return `<button class="action-button" data-action="hint" aria-label="Demander l’indice ${next} sur 3">Indice progressif <small>${next}/3</small></button>`;
  }

  function refreshHintAction() {
    const button = toolsPanel.querySelector('[data-action="hint"]');
    if (!button) return;
    const next = Math.min(3, (Number(game?.hintStage) || 0) + 1);
    button.innerHTML = `Indice progressif <small>${next}/3</small>`;
    button.setAttribute('aria-label', `Demander l’indice ${next} sur 3`);
  }

  function startGame(modeId, challenge = null) {
    if (game && !game.finished) persistAutomaticSave();
    clearInterval(timerHandle); clearInterval(autoSavePulse); clearTimeout(autoSaveHandle);
    activeMode = modeId;
    activeChallenge = challenge ? { ...challenge, mode: modeId } : null;
    activeDifficulty = activeChallenge ? 'normal' : (DIFFICULTIES[save.difficulty] ? save.difficulty : 'normal');
    challengeRandomState = activeChallenge ? (Number(activeChallenge.seed) >>> 0) : null;
    activeLevel = activeChallenge ? Math.max(1, Number(activeChallenge.level) || 1) : levelFor(modeId); save.lastMode = modeId; persist();
    const info = modeInfo(modeId);
    $('gameIcon').textContent = info.icon; $('gameTitle').textContent = info.title;
    $('gameEyebrow').textContent = `JEU DE RÉFLEXION · ${info.caption}`;
    $('levelLabel').textContent = pad(activeLevel);
    $('boardCaption').textContent = activeChallenge ? `DÉFI FRANCE · ${info.caption}` : info.caption;
    $('timerLabel').textContent = '00:00';
    const challengeStatus = $('challengeResultStatus'); if (challengeStatus) challengeStatus.textContent = '';
    feedback.className = 'feedback'; feedback.textContent = '';
    homeView.classList.add('hidden'); gameView.classList.remove('hidden');
    startedAt = Date.now(); timerHandle = setInterval(() => { $('timerLabel').textContent = clockText(Math.floor((Date.now() - startedAt) / 1000)); }, 1000);
    if (modeId === 'sudoku') makeSudoku();
    if (modeId === 'crossword' || modeId === 'arrows') makeWordGrid(modeId);
    if (modeId === 'search') makeWordSearch();
    if (modeId === 'memory') makeMemory();
    game.hintsUsed = 0; game.mistakes = 0; game.hintStage = 0; game.hintTarget = null; game.hintEntry = null; game.hintTargetOffset = null; game.hintPath = []; game.hintPair = null;
    renderTools(); updateLevelExplanation(); startAutomaticSavePulse();
  }

  window.startDailyChallenge = (modeId, challenge) => startGame(modeId, challenge);

  function backHome() {
    if (game && !game.finished) persistAutomaticSave();
    clearInterval(timerHandle); clearInterval(autoSavePulse); clearTimeout(autoSaveHandle); activeMode = null; game = null; activeChallenge = null; challengeRandomState = null;
    gameView.classList.add('hidden'); homeView.classList.remove('hidden'); renderHome(); window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function setFeedback(message, kind = '') { feedback.className = `feedback${kind ? ` ${kind}` : ''}`; feedback.textContent = message; }
  function showToast(message) { const el = $('toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastHandle); toastHandle = setTimeout(() => el.classList.remove('show'), 1900); }

  function renderTools() {
    const info = modeInfo(activeMode);
    let specific = '';
    if (activeMode === 'sudoku') specific = `<div class="tool-kicker">VOTRE GRILLE</div><h2>À vous de jouer</h2><p class="tool-copy">Un chiffre de 1 à 9 par ligne, colonne et carré. Sélectionnez une case puis choisissez un chiffre.</p><div class="number-pad">${Array.from({ length: 9 }, (_, i) => `<button class="number-key" data-number="${i + 1}">${i + 1}</button>`).join('')}<button class="number-key erase" data-number="0">Effacer</button></div><div class="tool-actions">${hintActionMarkup()}<button class="action-button primary" data-action="check">Vérifier ma grille <span>→</span></button></div><div class="side-note"><b>Indice en trois étapes</b>Repérez une ligne, découvrez les chiffres possibles, puis placez la solution.</div>`;
    else if (activeMode === 'crossword' || activeMode === 'arrows') specific = `<div class="tool-kicker">LES DÉFINITIONS</div><h2>${activeMode === 'arrows' ? 'Suivez les flèches' : 'Croisez les mots'}</h2><p class="tool-copy">${info.intro} Choisissez une définition ou une case, puis tapez votre réponse.</p><div class="tool-divider"></div><div class="tool-actions">${hintActionMarkup()}<button class="action-button primary" data-action="check">Vérifier mes réponses <span>→</span></button></div><div class="side-note"><b>Indices progressifs</b>Découvrez d’abord une lettre, placez-la, puis complétez le mot sélectionné.</div>`;
    else if (activeMode === 'search') specific = `<div class="tool-kicker">LES MOTS À TROUVER</div><h2>Ouvrez l’œil</h2><p class="tool-copy">Faites glisser la souris ou le doigt de la première à la dernière lettre. Vous pouvez aussi toucher ou cliquer les deux extrémités.</p><div class="tool-divider"></div><div class="tool-actions">${hintActionMarkup()}<button class="action-button" data-action="clearSelection">Effacer la sélection <small>↺</small></button><button class="action-button primary" data-action="check">Voir ma progression <span>→</span></button></div><div class="side-note"><b>Indices progressifs</b>Un rappel de la définition, les deux extrémités du mot, puis sa révélation.</div>`;
    else specific = `<div class="tool-kicker">VOTRE MÉMOIRE</div><h2>À vous de retrouver</h2><p class="tool-copy">Retournez deux cartes. Si elles sont pareilles, elles restent découvertes. Essayez de vous souvenir de leur place.</p><div class="tool-divider"></div><div class="tool-actions">${hintActionMarkup()}<button class="action-button" data-action="restart">Mélanger les cartes <small>↺</small></button></div><div class="side-note"><b>Indices progressifs</b>Un symbole à rechercher, un aperçu de sa paire, puis la paire révélée.</div>`;
    toolsPanel.innerHTML = specific;
  }

  function finishGame() {
    if (!game || game.finished) return;
    game.finished = true; clearInterval(timerHandle); clearAutomaticSave();
    const elapsedSeconds = Math.floor((Date.now() - startedAt) / 1000);
    const completedChallenge = activeChallenge ? { ...activeChallenge } : null;
    save.solved = (save.solved || 0) + 1; save.streak = (save.streak || 0) + 1;
    save.bestStreak = Math.max(save.bestStreak || 0, save.streak);
    save.modeWins[activeMode] = (save.modeWins[activeMode] || 0) + 1;
    save.fastest[activeMode] = Math.min(Number.isFinite(save.fastest[activeMode]) ? save.fastest[activeMode] : Infinity, elapsedSeconds);
    const modeStats = save.modeStats[activeMode] || (save.modeStats[activeMode] = { sessions: 0, totalSeconds: 0, mistakes: 0, hints: 0 });
    modeStats.sessions = (Number(modeStats.sessions) || 0) + 1;
    modeStats.totalSeconds = (Number(modeStats.totalSeconds) || 0) + elapsedSeconds;
    modeStats.mistakes = (Number(modeStats.mistakes) || 0) + (Number(game.mistakes) || 0);
    modeStats.hints = (Number(modeStats.hints) || 0) + (Number(game.hintsUsed) || 0);
    if (game.mistakes === 0) {
      save.cleanWins[activeMode] = (save.cleanWins[activeMode] || 0) + 1;
      save.cleanStreak = (save.cleanStreak || 0) + 1;
    } else save.cleanStreak = 0;
    if (game.hintsUsed === 0) save.noHintWins[activeMode] = (save.noHintWins[activeMode] || 0) + 1;
    if (!completedChallenge) save.levels[activeMode] = activeLevel + 1;
    updateDailyRecord();
    persist();
    const unlocked = unlockTrophies();
    persist(); renderTrophySummary(); renderModeStatistics();
    feedback.className = 'feedback success';
    const award = unlocked.length ? ` <span class="trophy-win">🏆 ${unlocked.map(trophy => trophy.title).join(' · ')}</span>` : '';
    feedback.innerHTML = `Bravo, niveau ${pad(activeLevel)} terminé !${award} <button class="win-banner-next" data-action="next">Niveau ${pad(activeLevel + 1)} →</button>`;
    feedback.querySelector('button').addEventListener('click', () => startGame(activeMode));
    if (completedChallenge) window.dispatchEvent(new CustomEvent('lcdj:challenge-finished', { detail: { ...completedChallenge, difficulty: activeDifficulty, elapsedSeconds, mistakes: game.mistakes || 0, hintsUsed: game.hintsUsed || 0 } }));
    else window.dispatchEvent(new CustomEvent('lcdj:level-finished', { detail: { mode: activeMode, level: activeLevel, difficulty: activeDifficulty, elapsedSeconds, mistakes: game.mistakes || 0, hintsUsed: game.hintsUsed || 0 } }));
    if (unlocked.length) queueTrophyNotifications(unlocked);
  }

  function unlockTrophies() {
    const unlocked = [];
    for (const trophy of TROPHIES) {
      if (!save.trophies[trophy.id] && trophy.unlocked()) { save.trophies[trophy.id] = true; unlocked.push(trophy); }
    }
    return unlocked;
  }

  function renderTrophySummary() {
    const count = TROPHIES.filter(trophy => save.trophies[trophy.id]).length;
    const label = `${count} / ${TROPHIES.length}`;
    $('headerTrophyCount').textContent = label;
    $('homeTrophyCount').textContent = label;
    $('trophyProgressLabel').textContent = label;
    $('trophyModalCount').textContent = label;
    $('trophyProgressBar').style.width = `${Math.round(count / TROPHIES.length * 100)}%`;
    $('trophyPercent').textContent = `${Math.round(count / TROPHIES.length * 100)} %`;
    $('trophyModalCount').textContent = label;
    $('trophyPercent').setAttribute('aria-label', `${Math.round(count / TROPHIES.length * 100)} pour cent des trophées débloqués`);
    const tierCounts = { bronze: 0, silver: 0, gold: 0, diamond: 0 };
    const tierKeys = { Bronze: 'bronze', Argent: 'silver', Or: 'gold', Diamant: 'diamond' };
    for (const trophy of TROPHIES) if (save.trophies[trophy.id] && tierKeys[trophy.tier]) tierCounts[tierKeys[trophy.tier]]++;
    window.leCercleTrophyCounts = { total: count, ...tierCounts };
    window.leCercleUnlockedTrophyIds = TROPHIES.filter(trophy => save.trophies[trophy.id]).map(trophy => trophy.id);
    window.dispatchEvent(new CustomEvent('lcdj:trophy-progress', { detail: window.leCercleTrophyCounts }));
  }

  function renderTrophyCollection() {
    renderTrophySummary();
    const visible = TROPHIES.filter(trophy => trophyFilter === 'all' || (trophyFilter === 'earned' ? !!save.trophies[trophy.id] : !save.trophies[trophy.id]));
    const categories = [...new Set(visible.map(trophy => trophy.category))];
    $('trophyGrid').innerHTML = categories.map(category => `<section class="trophy-group"><h3>${category}<small>${visible.filter(trophy => trophy.category === category).length}</small></h3><div class="trophy-group-grid">${visible.filter(trophy => trophy.category === category).map(trophy => {
      const earned = !!save.trophies[trophy.id];
      const tier = trophy.tier.toLowerCase();
      const progress = trophyProgress(trophy);
      return `<article class="trophy-card ${earned ? 'earned' : 'locked'} tier-${tier}"><span class="trophy-card-icon">${earned ? trophy.icon : '🔒'}</span><span class="trophy-card-copy"><b>${trophy.title}</b><small>${trophy.description}</small><span class="trophy-card-progress"><i style="width:${progress}%"></i></span></span><span class="trophy-state">${earned ? '100 %' : `${progress} %`}</span></article>`;
    }).join('')}</div></section>`).join('') || '<p class="trophy-empty">Aucun trophée dans cette sélection.</p>';
  }

  function openTrophies() {
    clearTimeout(trophyNotificationTimer);
    $('trophyNotification').classList.add('hidden');
    renderTrophyCollection(); $('trophyOverlay').classList.remove('hidden');
  }
  function closeTrophies() { $('trophyOverlay').classList.add('hidden'); showNextTrophyNotification(); }

  function queueTrophyNotifications(trophies) {
    trophyNotificationQueue.push(...trophies);
    showNextTrophyNotification();
  }

  function showNextTrophyNotification() {
    clearTimeout(trophyNotificationTimer);
    if ($('trophyOverlay') && !$('trophyOverlay').classList.contains('hidden')) return;
    const notification = $('trophyNotification');
    if (!activeTrophyNotification) activeTrophyNotification = trophyNotificationQueue.shift();
    const trophy = activeTrophyNotification;
    if (!trophy) { notification.classList.add('hidden'); return; }
    $('trophyNotificationIcon').textContent = trophy.icon;
    $('trophyNotificationTier').textContent = `TROPHÉE ${trophy.tier.toUpperCase()} DÉBLOQUÉ`;
    $('trophyNotificationTitle').textContent = trophy.title;
    $('trophyNotificationDescription').textContent = trophy.description;
    notification.dataset.tier = trophy.tier.toLowerCase();
    notification.classList.remove('hidden');
    trophyNotificationTimer = setTimeout(() => { activeTrophyNotification = null; showNextTrophyNotification(); }, 4800);
  }

  function dismissTrophyNotification() { clearTimeout(trophyNotificationTimer); activeTrophyNotification = null; $('trophyNotification').classList.add('hidden'); showNextTrophyNotification(); }

  function tryAgainMessage(message) { setFeedback(message, 'error'); save.streak = 0; persist(); }

  // Sudoku — shuffled valid Latin-grid pattern, with a growing number of blanks.
  function countSudokuSolutions(values, limit = 2) {
    const board = values.flat();
    const rows = Array(9).fill(0), cols = Array(9).fill(0), boxes = Array(9).fill(0);
    for (let i = 0; i < 81; i++) if (board[i]) {
      const r = Math.floor(i / 9), c = i % 9, box = Math.floor(r / 3) * 3 + Math.floor(c / 3), bit = 1 << board[i];
      rows[r] |= bit; cols[c] |= bit; boxes[box] |= bit;
    }
    let solutions = 0, nodes = 0, aborted = false;
    function solve() {
      if (solutions >= limit || aborted) return;
      if (++nodes > 24000) { aborted = true; return; }
      let best = -1, bestOptions = 0, bestCount = 10;
      for (let i = 0; i < 81; i++) if (!board[i]) {
        const r = Math.floor(i / 9), c = i % 9, box = Math.floor(r / 3) * 3 + Math.floor(c / 3);
        let options = 1022 & ~(rows[r] | cols[c] | boxes[box]), count = 0;
        for (let bits = options; bits; bits &= bits - 1) count++;
        if (!count) return;
        if (count < bestCount) { best = i; bestOptions = options; bestCount = count; if (count === 1) break; }
      }
      if (best < 0) { solutions++; return; }
      const r = Math.floor(best / 9), c = best % 9, box = Math.floor(r / 3) * 3 + Math.floor(c / 3);
      for (let options = bestOptions; options && solutions < limit && !aborted; options &= options - 1) {
        const bit = options & -options, value = Math.log2(bit);
        board[best] = value; rows[r] |= bit; cols[c] |= bit; boxes[box] |= bit;
        solve();
        board[best] = 0; rows[r] ^= bit; cols[c] ^= bit; boxes[box] ^= bit;
      }
    }
    solve();
    return aborted ? limit : solutions;
  }

  function makeSudoku() {
    const bands = shuffle([0, 1, 2]).flatMap(band => shuffle([0, 1, 2]).map(row => band * 3 + row));
    const stacks = shuffle([0, 1, 2]).flatMap(stack => shuffle([0, 1, 2]).map(col => stack * 3 + col));
    const digits = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    const solution = Array.from({ length: 9 }, (_, r) => Array.from({ length: 9 }, (_, c) => digits[(bands[r] * 3 + Math.floor(bands[r] / 3) + stacks[c]) % 9]));
    const values = solution.map(row => [...row]);
    const targetHoles = puzzleSettings('sudoku').holes;
    let removed = 0;
    for (const index of shuffle(Array.from({ length: 81 }, (_, i) => i))) {
      if (removed >= targetHoles) break;
      const r = Math.floor(index / 9), c = index % 9, oldValue = values[r][c];
      values[r][c] = 0;
      if (countSudokuSolutions(values) === 1) removed++;
      else values[r][c] = oldValue;
    }
    game = { solution, values, fixed: values.map(row => row.map(value => value !== 0)), selected: 0, finished: false, checked: false };
    renderSudoku();
  }

  function renderSudoku() {
    const g = game, selectedRow = Math.floor(g.selected / 9), selectedCol = g.selected % 9;
    const selectedValue = g.values[selectedRow][selectedCol];
    boardMount.innerHTML = `<div class="sudoku-grid" role="grid" aria-label="Grille de sudoku">${g.values.flatMap((row, r) => row.map((value, c) => {
      const index = r * 9 + c, sameBox = Math.floor(r / 3) === Math.floor(selectedRow / 3) && Math.floor(c / 3) === Math.floor(selectedCol / 3);
      const related = r === selectedRow || c === selectedCol || sameBox;
      const boxValues = g.values.slice(Math.floor(r / 3) * 3, Math.floor(r / 3) * 3 + 3).flatMap(other => other.slice(Math.floor(c / 3) * 3, Math.floor(c / 3) * 3 + 3));
      const duplicate = value && (row.filter(v => v === value).length > 1 || g.values.filter(other => other[c] === value).length > 1 || boxValues.filter(v => v === value).length > 1);
      const wrong = g.checked && value && value !== g.solution[r][c];
       const classes = ['sudoku-cell', g.fixed[r][c] ? 'fixed' : '', related ? 'related' : '', selectedValue && value === selectedValue ? 'same-number' : '', index === g.selected ? 'selected' : '', index === g.hintTarget ? 'hint-target' : '', duplicate ? 'conflict' : '', wrong ? 'wrong' : ''].filter(Boolean).join(' ');
      return `<button class="${classes}" role="gridcell" data-sudoku="${index}" aria-label="Ligne ${r + 1}, colonne ${c + 1}, ${value || 'vide'}">${value || ''}</button>`;
    })).join('')}</div>`;
    scheduleAutomaticSave();
  }

  function setSudokuValue(value) {
    if (!game || game.finished) return;
    const r = Math.floor(game.selected / 9), c = game.selected % 9;
    if (game.fixed[r][c]) { showToast('Cette case fait partie de la grille.'); return; }
    game.values[r][c] = value; game.checked = false; renderSudoku();
  }

  function checkSudoku() {
    if (game.finished) return;
    const empty = game.values.flat().filter(value => !value).length;
    if (empty) { setFeedback(`Il reste ${empty} case${empty > 1 ? 's' : ''} à remplir.`); return; }
    const errors = game.values.flatMap((row, r) => row.map((value, c) => value === game.solution[r][c] ? null : [r, c])).filter(Boolean);
    if (!errors.length) { finishGame(); return; }
    game.mistakes++; game.checked = true; renderSudoku(); tryAgainMessage(`${errors.length} chiffre${errors.length > 1 ? 's' : ''} à revoir. Les cases en rose sont incorrectes.`);
  }

  function sudokuHint() {
    if (game.finished) return;
    const isUnresolved = index => { const r = Math.floor(index / 9), c = index % 9; return game.values[r][c] !== game.solution[r][c]; };
    if (!Number.isInteger(game.hintTarget) || !isUnresolved(game.hintTarget)) {
      const unresolved = Array.from({ length: 81 }, (_, i) => i).filter(isUnresolved);
      if (!unresolved.length) { showToast('Toutes les cases sont déjà correctes.'); return; }
      const rowCounts = Array.from({ length: 9 }, (_, r) => unresolved.filter(i => Math.floor(i / 9) === r).length);
      const bestRows = rowCounts.map((count, row) => ({ count, row })).filter(item => item.count > 0).sort((a, b) => a.count - b.count);
      const rowChoices = bestRows.filter(item => item.count === bestRows[0].count);
      const row = rowChoices[Math.floor(random() * rowChoices.length)].row;
      game.hintTarget = shuffle(unresolved.filter(i => Math.floor(i / 9) === row))[0]; game.hintStage = 0;
    }
    const index = game.hintTarget, r = Math.floor(index / 9), c = index % 9;
    game.selected = index; game.hintsUsed++; game.checked = false;
    if (!game.hintStage) {
      game.hintStage = 1; renderSudoku(); setFeedback(`Indice 1/3 : observez la ligne ${r + 1}, qui ne contient plus que quelques cases à compléter.`);
    } else if (game.hintStage === 1) {
      const present = new Set();
      for (let i = 0; i < 9; i++) { if (game.values[r][i]) present.add(game.values[r][i]); if (game.values[i][c]) present.add(game.values[i][c]); }
      for (let rr = Math.floor(r / 3) * 3; rr < Math.floor(r / 3) * 3 + 3; rr++) for (let cc = Math.floor(c / 3) * 3; cc < Math.floor(c / 3) * 3 + 3; cc++) if (game.values[rr][cc]) present.add(game.values[rr][cc]);
      const candidates = Array.from({ length: 9 }, (_, i) => i + 1).filter(value => !present.has(value));
      if (!candidates.includes(game.solution[r][c])) candidates.push(game.solution[r][c]);
      candidates.sort((a, b) => a - b); game.hintStage = 2; renderSudoku(); setFeedback(`Indice 2/3 : pour la ligne ${r + 1}, colonne ${c + 1}, les chiffres possibles sont ${candidates.join(', ')}.`);
    } else {
      game.values[r][c] = game.solution[r][c]; game.hintStage = 0; game.hintTarget = null; renderSudoku();
      if (game.values.flat().every((value, i) => value === game.solution[Math.floor(i / 9)][i % 9])) { finishGame(); return; }
      setFeedback(`Indice 3/3 : le chiffre ${game.solution[r][c]} est placé. À vous de continuer !`);
    }
    refreshHintAction();
  }

  // Crosswords and arrowwords are assembled from a reusable French word bank.
  const keyOf = (r, c) => `${r},${c}`;
  function canPlaceWord(cells, entries, word, dir, r, c, blocked = null) {
    if (entries.some(entry => entry.dir === dir && entry.cells.some(cell => cell.r === r && cell.c === c))) return null;
    let crosses = 0; const points = [];
    for (let i = 0; i < word.length; i++) {
      const rr = r + (dir === 'v' ? i : 0), cc = c + (dir === 'h' ? i : 0), existing = cells.get(keyOf(rr, cc));
      if (blocked?.has(keyOf(rr, cc))) return null;
      if (existing && existing.letter !== word[i]) return null;
      if (existing) {
        if (entries.some(entry => entry.dir === dir && entry.cells.some(cell => cell.r === rr && cell.c === cc))) return null;
        crosses++;
      } else {
        const sides = dir === 'h' ? [[rr - 1, cc], [rr + 1, cc]] : [[rr, cc - 1], [rr, cc + 1]];
        if (sides.some(([sr, sc]) => cells.has(keyOf(sr, sc)))) return null;
      }
      points.push({ r: rr, c: cc });
    }
    const before = dir === 'h' ? [r, c - 1] : [r - 1, c], after = dir === 'h' ? [r, c + word.length] : [r + word.length, c];
    if (cells.has(keyOf(...before)) || cells.has(keyOf(...after)) || !crosses) return null;
    return { crosses, points };
  }

  function arrowClueRectangle(dir, r, c) {
    return dir === 'h' ? { r: r - 1, c: c - 3, rows: 2, cols: 3 } : { r: r - 2, c: c - 1, rows: 2, cols: 3 };
  }

  function addArrowClueCells(target, rect) {
    for (let r = rect.r; r < rect.r + rect.rows; r++) for (let c = rect.c; c < rect.c + rect.cols; c++) target.add(keyOf(r, c));
  }

  function arrowClueFits(rect, cells, reserved) {
    for (let r = rect.r; r < rect.r + rect.rows; r++) for (let c = rect.c; c < rect.c + rect.cols; c++) {
      const key = keyOf(r, c); if (cells.has(key) || reserved.has(key)) return false;
    }
    return true;
  }

  function generateCrossword(level, withArrowClues = false) {
    const target = puzzleSettings(activeMode, level).words;
    let best = null;
    for (let attempt = 0; attempt < 110; attempt++) {
      const choices = shuffle(WORDS).slice(0, Math.min(28, WORDS.length));
      const seed = choices.shift();
      const seedRow = 0, seedCol = withArrowClues ? 4 : 0;
      const entries = [{ word: seed.word, clue: seed.clue, dir: 'h', r: seedRow, c: seedCol, cells: [] }];
      const cells = new Map();
      const clueCells = new Set();
      if (withArrowClues) { entries[0].clueRect = arrowClueRectangle('h', seedRow, seedCol); addArrowClueCells(clueCells, entries[0].clueRect); }
      for (let i = 0; i < seed.word.length; i++) { const point = { r: seedRow, c: seedCol + i }; entries[0].cells.push(point); cells.set(keyOf(point.r, point.c), { letter: seed.word[i] }); }
      const remaining = choices.filter(item => item.word !== seed.word);
      while (entries.length < target && remaining.length) {
        const candidates = [];
        for (let wi = 0; wi < remaining.length; wi++) {
          const item = remaining[wi];
          for (const anchor of entries) for (let ai = 0; ai < anchor.word.length; ai++) {
            const anchorPoint = anchor.cells[ai], dir = anchor.dir === 'h' ? 'v' : 'h';
            for (let li = 0; li < item.word.length; li++) if (item.word[li] === anchor.word[ai]) {
              const r = anchorPoint.r - (dir === 'v' ? li : 0), c = anchorPoint.c - (dir === 'h' ? li : 0);
              const placed = canPlaceWord(cells, entries, item.word, dir, r, c, withArrowClues ? clueCells : null);
              const clueRect = withArrowClues ? arrowClueRectangle(dir, r, c) : null;
              if (placed && (!withArrowClues || arrowClueFits(clueRect, cells, clueCells))) candidates.push({ wi, item, dir, r, c, clueRect, ...placed });
            }
          }
        }
        if (!candidates.length) break;
        const topScore = Math.max(...candidates.map(candidate => candidate.crosses));
        const bestFits = candidates.filter(candidate => candidate.crosses === topScore);
        const pick = bestFits[Math.floor(random() * bestFits.length)];
        const entry = { word: pick.item.word, clue: pick.item.clue, dir: pick.dir, r: pick.r, c: pick.c, cells: pick.points, ...(withArrowClues ? { clueRect: pick.clueRect } : {}) };
        entries.push(entry); remaining.splice(pick.wi, 1);
        for (let i = 0; i < entry.word.length; i++) cells.set(keyOf(entry.cells[i].r, entry.cells[i].c), { letter: entry.word[i] });
        if (withArrowClues) addArrowClueCells(clueCells, entry.clueRect);
      }
      if (!best || entries.length > best.entries.length) best = { entries, cells, clueCells: new Set(clueCells) };
      if (best.entries.length >= target) break;
    }
    const entries = best.entries;
    let minR = Infinity, minC = Infinity, maxR = -Infinity, maxC = -Infinity;
    for (const point of [...best.cells.keys(), ...best.clueCells]) { const [r, c] = point.split(',').map(Number); minR = Math.min(minR, r); minC = Math.min(minC, c); maxR = Math.max(maxR, r); maxC = Math.max(maxC, c); }
    for (const entry of entries) {
      entry.cells = entry.cells.map(point => ({ r: point.r - minR + 1, c: point.c - minC + 1 })); entry.r = entry.cells[0].r; entry.c = entry.cells[0].c;
      if (entry.clueRect) entry.clueRect = { ...entry.clueRect, r: entry.clueRect.r - minR + 1, c: entry.clueRect.c - minC + 1 };
    }
    const normalized = new Map();
    for (const entry of entries) entry.cells.forEach((point, index) => normalized.set(keyOf(point.r, point.c), { letter: entry.word[index] }));
    const numbered = new Map(); let nextNumber = 1;
    entries.forEach(entry => { const key = keyOf(entry.r, entry.c); if (!numbered.has(key)) numbered.set(key, nextNumber++); entry.number = numbered.get(key); });
    return { entries, cells: normalized, rows: maxR - minR + 3, cols: maxC - minC + 3, guesses: new Map(), selected: 0, offset: 0, finished: false };
  }

  function makeWordGrid(modeId) {
    game = generateCrossword(activeLevel, modeId === 'arrows'); game.mode = modeId; renderWordGrid();
  }

  function renderWordGrid() {
    const g = game, arrowMode = activeMode === 'arrows', usesArrowTiles = arrowMode && g.entries.every(entry => entry.clueRect); const startMap = new Map();
    g.entries.forEach((entry, index) => { const key = keyOf(entry.r, entry.c); if (!startMap.has(key)) startMap.set(key, []); startMap.get(key).push(index); });
    const selected = g.entries[g.selected];
    const hintEntry = Number.isInteger(g.hintEntry) ? g.entries[g.hintEntry] : null;
    const hintPoint = hintEntry?.cells[g.hintTargetOffset];
    const hintTargetKey = hintPoint ? keyOf(hintPoint.r, hintPoint.c) : null;
    const cellsHtml = [];
    for (let r = 0; r < g.rows; r++) for (let c = 0; c < g.cols; c++) {
      const key = keyOf(r, c), cell = g.cells.get(key), start = startMap.get(key) || [], selectedHere = selected?.cells.some(point => point.r === r && point.c === c);
      const position = `grid-row:${r + 1};grid-column:${c + 1}`;
      if (!cell) { cellsHtml.push(`<span class="word-cell block" style="${position}" aria-hidden="true"></span>`); continue; }
      const number = start.length && !usesArrowTiles ? g.entries[start[0]].number : '';
      const arrow = start.length && arrowMode && !usesArrowTiles ? `<span class="cell-arrow">${g.entries[start[0]].dir === 'h' ? '→' : '↓'}</span>` : '';
      const value = g.guesses.get(key) || '';
      cellsHtml.push(`<button class="word-cell ${selectedHere ? 'selected-word' : ''} ${hintTargetKey === key ? 'hint-target' : ''} ${g.wrong?.has(key) ? 'wrong-letter' : ''}" style="${position}" data-word-cell="${key}" aria-label="Case ${number || ''} ${value || ''}${hintTargetKey === key ? ', case de l’indice' : ''}">${number ? `<span class="cell-num">${number}</span>` : ''}${value}${arrow}</button>`);
    }
    const groups = [['h', activeMode === 'arrows' ? '→ HORIZONTALES' : 'HORIZONTALES'], ['v', activeMode === 'arrows' ? '↓ VERTICALES' : 'VERTICALES']];
    let clueHtml = '';
    if (!usesArrowTiles) {
      for (const [dir, label] of groups) {
        const items = g.entries.map((entry, index) => ({ entry, index })).filter(item => item.entry.dir === dir);
        if (!items.length) continue;
        clueHtml += `<div class="clue-heading">${label}</div>`;
        clueHtml += items.map(({ entry, index }) => `<button class="clue-item ${index === g.selected ? 'active' : ''} ${isEntrySolved(entry) ? 'solved' : ''}" data-entry="${index}"><span class="clue-num">${entry.number}.</span><span class="clue-text">${entry.clue}</span><span class="clue-length">${entry.word.length}</span></button>`).join('');
      }
    }
    const arrowTilesHtml = usesArrowTiles ? g.entries.map((entry, index) => {
      const rect = entry.clueRect, position = `grid-row:${rect.r + 1}/span ${rect.rows};grid-column:${rect.c + 1}/span ${rect.cols}`;
      const direction = entry.dir === 'h' ? 'horizontale' : 'verticale';
      return `<button class="arrow-clue-cell arrow-clue-${entry.dir} ${index === g.selected ? 'active' : ''} ${isEntrySolved(entry) ? 'solved' : ''}" style="${position}" data-entry="${index}" aria-label="Définition ${entry.number} : ${entry.clue}, réponse ${direction} en ${entry.word.length} lettres"><span class="arrow-clue-number">${entry.number}</span><span class="arrow-clue-text">${entry.clue}</span><span class="arrow-clue-direction" aria-hidden="true">${entry.dir === 'h' ? '→' : '↓'}</span><span class="arrow-clue-length">${entry.word.length} lettres</span></button>`;
    }).join('') : '';
    const gridStyle = `--grid-cols:${g.cols};--grid-rows:${g.rows}`;
    const legend = usesArrowTiles ? '<div class="arrow-grid-legend"><span><b>→</b> Réponse horizontale</span><span><b>↓</b> Réponse verticale</span><span>Cliquez sur une définition pour écrire</span></div>' : '';
    boardMount.innerHTML = `<div class="word-layout ${usesArrowTiles ? 'arrow-layout' : ''}"><div class="word-board-wrap"><div class="word-grid ${usesArrowTiles ? 'arrow-word-grid' : ''}" style="${gridStyle}">${cellsHtml.join('')}${arrowTilesHtml}</div>${legend}</div>${usesArrowTiles ? '' : `<div class="clue-list">${clueHtml}</div>`}</div>`;
    scheduleAutomaticSave();
  }

  function isEntrySolved(entry) { return entry.cells.every((point, i) => game.guesses.get(keyOf(point.r, point.c)) === entry.word[i]); }
  function selectEntry(index, offset = 0) { if (game.finished) return; game.selected = index; const entry = game.entries[index]; game.offset = Math.min(offset, entry.word.length - 1); game.hintStage = 0; game.hintEntry = null; game.hintTargetOffset = null; renderWordGrid(); refreshHintAction(); }
  function selectWordCell(key) {
    const entries = game.entries.map((entry, index) => ({ entry, index })).filter(({ entry }) => entry.cells.some(point => keyOf(point.r, point.c) === key));
    if (!entries.length) return;
    const current = entries.findIndex(({ index }) => index === game.selected);
    const pick = entries.length > 1 ? entries[(current + 1) % entries.length] : entries[0];
    const offset = pick.entry.cells.findIndex(point => keyOf(point.r, point.c) === key);
    selectEntry(pick.index, offset);
  }

  function typeWordLetter(letter) {
    if (!game || game.finished) return;
    const entry = game.entries[game.selected]; if (!entry) return;
    while (game.offset < entry.word.length - 1 && entry.cells[game.offset] && game.guesses.get(keyOf(entry.cells[game.offset].r, entry.cells[game.offset].c)) === entry.word[game.offset]) game.offset++;
    const point = entry.cells[game.offset]; game.guesses.set(keyOf(point.r, point.c), letter); game.wrong?.clear();
    if (game.offset < entry.word.length - 1) game.offset++;
    else {
      const next = game.entries.findIndex((candidate, index) => index !== game.selected && !isEntrySolved(candidate));
      if (next >= 0) { game.selected = next; game.offset = 0; }
    }
    if (game.entries.every(isEntrySolved)) { finishGame(); return; }
    renderWordGrid();
  }

  function removeWordLetter() {
    if (!game || game.finished) return;
    const entry = game.entries[game.selected]; if (!entry) return;
    const protectedBySolvedWord = point => {
      const key = keyOf(point.r, point.c);
      return game.entries.some((other, index) => index !== game.selected && isEntrySolved(other) && other.cells.some(cell => keyOf(cell.r, cell.c) === key));
    };
    const current = entry.cells[game.offset];
    if (game.guesses.has(keyOf(current.r, current.c)) && !protectedBySolvedWord(current)) game.guesses.delete(keyOf(current.r, current.c));
    else {
      for (let offset = Math.min(game.offset - 1, entry.cells.length - 1); offset >= 0; offset--) {
        const point = entry.cells[offset], key = keyOf(point.r, point.c);
        if (game.guesses.has(key) && !protectedBySolvedWord(point)) { game.offset = offset; game.guesses.delete(key); break; }
      }
    }
    game.wrong?.clear(); renderWordGrid();
  }

  function checkWordGrid() {
    if (game.finished) return;
    const blanks = [...game.cells.keys()].filter(key => !game.guesses.has(key)).length;
    if (blanks) { setFeedback(`Il reste ${blanks} lettre${blanks > 1 ? 's' : ''} à placer.`); return; }
    const wrong = new Set();
    for (const [key, value] of game.cells) if (game.guesses.get(key) !== value.letter) wrong.add(key);
    if (!wrong.size) { finishGame(); return; }
    game.mistakes++; game.wrong = wrong; renderWordGrid(); tryAgainMessage(`${wrong.size} lettre${wrong.size > 1 ? 's' : ''} à revoir. Les cases sont signalées en rose.`);
  }

  function wordHint() {
    if (game.finished) return;
    let entry = Number.isInteger(game.hintEntry) ? game.entries[game.hintEntry] : null;
    if (!entry || isEntrySolved(entry)) {
      const selected = game.entries[game.selected];
      const index = selected && !isEntrySolved(selected) ? game.selected : game.entries.findIndex(candidate => !isEntrySolved(candidate));
      if (index < 0) { showToast('Tous les mots sont déjà corrects.'); return; }
      game.hintEntry = index; game.hintTargetOffset = null; game.hintStage = 0; entry = game.entries[index];
    }
    const firstMissing = entry.cells.findIndex((point, offset) => game.guesses.get(keyOf(point.r, point.c)) !== entry.word[offset]);
    if (firstMissing < 0) { game.hintStage = 0; game.hintEntry = null; game.hintTargetOffset = null; wordHint(); return; }
    if (game.hintStage && Number.isInteger(game.hintTargetOffset)) {
      const oldPoint = entry.cells[game.hintTargetOffset], oldKey = keyOf(oldPoint.r, oldPoint.c);
      if (game.guesses.get(oldKey) === entry.word[game.hintTargetOffset]) game.hintTargetOffset = firstMissing;
    } else game.hintTargetOffset = firstMissing;
    game.selected = game.hintEntry; game.offset = game.hintTargetOffset; game.hintsUsed++;
    const targetPoint = entry.cells[game.hintTargetOffset], targetKey = keyOf(targetPoint.r, targetPoint.c), letter = entry.word[game.hintTargetOffset];
    if (!game.hintStage) {
      game.hintStage = 1; renderWordGrid(); setFeedback(`Indice 1/3 : la prochaine lettre à placer dans le mot ${entry.number} est « ${letter} ».`);
    } else if (game.hintStage === 1) {
      game.guesses.set(targetKey, letter); game.hintStage = 2; renderWordGrid(); setFeedback(`Indice 2/3 : la lettre « ${letter} » est placée dans le mot ${entry.number}.`);
    } else {
      entry.cells.forEach((point, offset) => { const key = keyOf(point.r, point.c); if (game.guesses.get(key) !== entry.word[offset]) game.guesses.set(key, entry.word[offset]); });
      game.hintStage = 0; game.hintEntry = null; game.hintTargetOffset = null;
      if (game.entries.every(isEntrySolved)) { finishGame(); return; }
      renderWordGrid(); setFeedback(`Indice 3/3 : le mot ${entry.number} est complété.`);
    }
    refreshHintAction();
  }

  // Word search — each next level gets a fresh set and a larger challenge over time.
  function makeWordSearch() {
    const settings = puzzleSettings('search');
    const count = settings.words;
    const chosen = shuffle(WORDS).slice(0, count), size = settings.size;
    const letters = Array.from({ length: size }, () => Array(size).fill(''));
    const allDirections = [[0,1],[1,0],[0,-1],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
    const dirs = activeDifficulty === 'relaxed' ? [[0,1],[1,0]] : activeDifficulty === 'expert' ? allDirections : activeLevel >= 3 ? allDirections : [[0,1],[1,0],[0,-1],[-1,0],[1,1],[-1,-1]];
    const entries = [];
    for (const item of chosen) {
      let placed = false;
      for (let attempt = 0; attempt < 240 && !placed; attempt++) {
        const [dr, dc] = dirs[Math.floor(random() * dirs.length)];
        const r = Math.floor(random() * size), c = Math.floor(random() * size);
        const endR = r + dr * (item.word.length - 1), endC = c + dc * (item.word.length - 1);
        if (endR < 0 || endR >= size || endC < 0 || endC >= size) continue;
        const path = Array.from({ length: item.word.length }, (_, i) => ({ r: r + dr * i, c: c + dc * i }));
        if (path.some((point, i) => letters[point.r][point.c] && letters[point.r][point.c] !== item.word[i])) continue;
        path.forEach((point, i) => { letters[point.r][point.c] = item.word[i]; });
        entries.push({ word: item.word, clue: item.clue, path, found: false }); placed = true;
      }
    }
    const alphabet = 'ABCDEFGHIJKLMNOPRSTUV';
    letters.forEach(row => row.forEach((value, i) => { if (!value) row[i] = alphabet[Math.floor(random() * alphabet.length)]; }));
    game = { letters, size, entries, first: null, preview: [], finished: false };
    renderWordSearch();
  }

  function renderWordSearch() {
    const found = new Set(game.entries.filter(entry => entry.found).flatMap(entry => entry.path.map(point => keyOf(point.r, point.c))));
    const preview = new Set(game.preview.map(point => keyOf(point.r, point.c)));
    const hint = new Set((game.hintPath || []).map(point => keyOf(point.r, point.c)));
    const grid = game.letters.flatMap((row, r) => row.map((letter, c) => {
      const key = keyOf(r, c), classes = ['search-cell', found.has(key) ? 'found' : '', game.first && key === keyOf(game.first.r, game.first.c) ? 'start' : '', preview.has(key) ? 'selected-path' : '', hint.has(key) ? 'hint-target' : ''].filter(Boolean).join(' ');
      return `<button class="${classes}" data-search-cell="${key}" aria-label="Ligne ${r + 1}, colonne ${c + 1}, ${letter}${hint.has(key) ? ', extrémité du mot' : ''}">${letter}</button>`;
    })).join('');
    const chips = game.entries.map((entry, index) => `<span class="word-chip ${entry.found ? 'found' : ''} ${index === game.hintEntry ? 'hint-word' : ''}" data-word-chip="${index}">${entry.word}</span>`).join('');
    const columns = Math.min(34, Math.max(22, Math.floor((boardMount.clientWidth - (game.size - 1) * 3 - 24) / game.size)));
    boardMount.innerHTML = `<div class="search-layout"><div class="search-grid" style="grid-template-columns:repeat(${game.size},${columns}px)">${grid}</div><div class="word-bank">${chips}</div></div>`;
    scheduleAutomaticSave();
  }

  function wordSearchHint() {
    if (game.finished) return;
    let index = Number.isInteger(game.hintEntry) && !game.entries[game.hintEntry]?.found ? game.hintEntry : -1;
    if (index < 0) {
      const remaining = game.entries.map((entry, i) => ({ entry, i })).filter(item => !item.entry.found);
      if (!remaining.length) { showToast('Tous les mots ont été trouvés.'); return; }
      index = remaining[Math.floor(random() * remaining.length)].i; game.hintEntry = index; game.hintStage = 0; game.hintPath = [];
    }
    const entry = game.entries[index]; game.hintsUsed++;
    if (!game.hintStage) {
      game.hintStage = 1; renderWordSearch(); setFeedback(`Indice 1/3 : « ${entry.clue} » — le mot compte ${entry.word.length} lettres.`);
    } else if (game.hintStage === 1) {
      game.hintStage = 2; game.hintPath = [entry.path[0], entry.path[entry.path.length - 1]]; renderWordSearch();
      const first = entry.path[0], last = entry.path[entry.path.length - 1];
      setFeedback(`Indice 2/3 : repérez les extrémités en ligne ${first.r + 1}, colonne ${first.c + 1}, et ligne ${last.r + 1}, colonne ${last.c + 1}.`);
    } else {
      entry.found = true; game.hintStage = 0; game.hintEntry = null; game.hintPath = []; game.first = null; game.preview = []; renderWordSearch();
      if (game.entries.every(item => item.found)) { finishGame(); return; }
      setFeedback(`Indice 3/3 : « ${entry.word} » est révélé dans la grille.`);
    }
    refreshHintAction();
  }

  function onSearchCell(key) {
    if (game.finished) return;
    const [r, c] = key.split(',').map(Number);
    if (!game.first) { game.first = { r, c }; game.preview = [{ r, c }]; renderWordSearch(); setFeedback('Choisissez maintenant la dernière lettre du mot.'); return; }
    completeSearchSelection(game.first, { r, c });
  }

  function searchPathBetween(first, last) {
    const drRaw = last.r - first.r, dcRaw = last.c - first.c;
    const straight = drRaw === 0 || dcRaw === 0 || Math.abs(drRaw) === Math.abs(dcRaw);
    if (!straight) return null;
    const dr = Math.sign(drRaw), dc = Math.sign(dcRaw), length = Math.max(Math.abs(drRaw), Math.abs(dcRaw)) + 1;
    return Array.from({ length }, (_, i) => ({ r: first.r + dr * i, c: first.c + dc * i }));
  }

  function completeSearchSelection(first, last) {
    if (!game || game.finished) return;
    const path = searchPathBetween(first, last);
    if (!path || path.length < 2) {
      game.first = { ...last }; game.preview = [{ ...last }]; renderWordSearch(); setFeedback('Le mot doit suivre une ligne droite. Choisissez sa dernière lettre.'); return;
    }
    const match = game.entries.find(entry => !entry.found && (samePath(entry.path, path) || samePath(entry.path, [...path].reverse())));
    game.first = null; game.preview = [];
    if (match) {
      match.found = true; renderWordSearch(); setFeedback(`Bien trouvé : ${match.word} !`, 'success');
      if (game.entries.every(entry => entry.found)) finishGame();
    } else { game.mistakes++; renderWordSearch(); showToast('Ce n’est pas un mot de la liste.'); }
  }

  function searchCellAtPoint(x, y) {
    const target = document.elementFromPoint(x, y);
    return target && target.closest ? target.closest('[data-search-cell]') : null;
  }

  function updateSearchDragPreview(cell) {
    if (!searchPointerSelection || !cell || !game || game.finished) return;
    const key = cell.dataset.searchCell, [r, c] = key.split(',').map(Number), last = { r, c };
    searchPointerSelection.lastKey = key;
    document.querySelectorAll('.search-cell.drag-path,.search-cell.drag-end').forEach(item => item.classList.remove('drag-path', 'drag-end'));
    const path = searchPathBetween(searchPointerSelection.start, last);
    if (path) for (const point of path) {
      const pathCell = boardMount.querySelector(`[data-search-cell="${keyOf(point.r, point.c)}"]`);
      if (pathCell) pathCell.classList.add('drag-path');
    }
    cell.classList.add('drag-end');
  }

  function samePath(a, b) { return a.length === b.length && a.every((point, i) => point.r === b[i].r && point.c === b[i].c); }

  // Memory — the number of pairs increases as the levels progress.
  function makeMemory() {
    const pairs = puzzleSettings('memory').pairs;
    const deck = shuffle(EMOJIS).slice(0, pairs).flatMap((emoji, index) => [{ id: `${index}-a`, pair: index, emoji, open: false, matched: false }, { id: `${index}-b`, pair: index, emoji, open: false, matched: false }]);
    game = { cards: shuffle(deck), open: [], moves: 0, pairs, locked: false, finished: false };
    renderMemory();
  }

  function renderMemory() {
    const matched = game.cards.filter(card => card.matched).length / 2;
    boardMount.innerHTML = `<div class="memory-layout"><div class="memory-info"><span>Paires <b>${matched} / ${game.pairs}</b></span><span>Essais <b>${game.moves}</b></span></div><div class="memory-grid">${game.cards.map((card, index) => `<button class="memory-card ${card.open ? 'revealed' : ''} ${card.matched ? 'matched' : ''}" data-memory="${index}" aria-label="Carte ${index + 1}">${card.open || card.matched ? card.emoji : '✦'}</button>`).join('')}</div></div>`;
    scheduleAutomaticSave();
  }

  function flipMemory(index) {
    if (game.finished || game.locked) return;
    const card = game.cards[index]; if (card.open || card.matched) return;
    card.open = true; game.open.push(index); renderMemory();
    if (game.open.length === 2) {
      game.moves++;
      const [a, b] = game.open.map(i => game.cards[i]);
      if (a.pair === b.pair) {
        a.matched = b.matched = true; game.open = []; renderMemory();
        if (game.cards.every(item => item.matched)) finishGame();
      } else {
        game.mistakes++;
        game.locked = true;
        const mismatchedGame = game;
        setTimeout(() => { if (game !== mismatchedGame) return; a.open = b.open = false; mismatchedGame.open = []; mismatchedGame.locked = false; renderMemory(); }, 780);
      }
    }
  }

  function memoryHint() {
    if (game.finished || game.locked) return;
    if (game.open.length) { showToast('Terminez ce tour avant de demander un indice.'); return; }
    let pair = game.hintPair;
    if (pair == null || !game.cards.some(card => card.pair === pair && !card.matched)) {
      const pairs = [...new Set(game.cards.filter(card => !card.matched).map(card => card.pair))];
      if (!pairs.length) { showToast('Toutes les paires sont déjà trouvées.'); return; }
      pair = pairs[Math.floor(random() * pairs.length)]; game.hintPair = pair; game.hintStage = 0;
    }
    const cards = game.cards.filter(card => card.pair === pair && !card.matched); game.hintsUsed++;
    if (!game.hintStage) {
      game.hintStage = 1; setFeedback(`Indice 1/3 : cherchez les deux cartes « ${cards[0].emoji} ».`);
    } else if (game.hintStage === 1) {
      cards.forEach(card => { card.open = true; }); game.hintStage = 2; game.locked = true; renderMemory();
      setFeedback('Indice 2/3 : mémorisez l’emplacement de ces deux cartes.'); refreshHintAction();
      const hintedGame = game;
      setTimeout(() => {
        if (game !== hintedGame) return;
        cards.forEach(card => { if (!card.matched) card.open = false; }); game.locked = false; renderMemory();
      }, 1250);
      return;
    } else {
      cards.forEach(card => { card.matched = true; card.open = false; }); game.hintStage = 0; game.hintPair = null; renderMemory();
      if (game.cards.every(card => card.matched)) { finishGame(); return; }
      setFeedback(`Indice 3/3 : la paire « ${cards[0].emoji} » est révélée.`);
    }
    refreshHintAction();
  }

  function handleAction(action) {
    if (action === 'hint') { if (activeMode === 'sudoku') sudokuHint(); else if (activeMode === 'crossword' || activeMode === 'arrows') wordHint(); else if (activeMode === 'search') wordSearchHint(); else if (activeMode === 'memory') memoryHint(); }
    if (action === 'check') { if (activeMode === 'sudoku') checkSudoku(); else if (activeMode === 'crossword' || activeMode === 'arrows') checkWordGrid(); else if (activeMode === 'search') setFeedback(`${game.entries.filter(entry => entry.found).length} mot${game.entries.filter(entry => entry.found).length > 1 ? 's' : ''} trouvé${game.entries.filter(entry => entry.found).length > 1 ? 's' : ''} sur ${game.entries.length}.`); }
    if (action === 'clearSelection') { game.first = null; game.preview = []; renderWordSearch(); setFeedback('Sélection effacée.'); }
    if (action === 'restart') { makeMemory(); setFeedback('Les cartes ont été mélangées.'); }
    if (action === 'next') startGame(activeMode);
  }

  gameGrid.addEventListener('click', event => { const button = event.target.closest('[data-game]'); if (button) startGame(button.dataset.game); });
  $('backHome').addEventListener('click', backHome); $('brandHome').addEventListener('click', () => activeMode ? backHome() : window.scrollTo({ top: 0, behavior: 'smooth' }));
  $('continueButton').addEventListener('click', () => {
    if (save.solved > 0) startGame(save.lastMode || 'sudoku');
    else gameGrid.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('saveManualGame').addEventListener('click', saveCurrentGame);
  $('restoreManualGame').addEventListener('click', () => restoreGameSnapshot());
  $('restoreManualHome').addEventListener('click', () => restoreGameSnapshot());
  $('resumeAutoHome').addEventListener('click', () => restoreGameSnapshot(null, AUTO_SAVE_KEY));
  $('exportBackup').addEventListener('click', downloadBackup);
  $('importBackupButton').addEventListener('click', () => $('importBackupFile').click());
  $('importBackupFile').addEventListener('change', event => { if (event.target.files[0]) importBackup(event.target.files[0]); event.target.value = ''; });
  $('themeToggle').addEventListener('click', () => { localStorage.setItem('lcdj.theme', document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'); applyTheme(); });
  $('accessibilityToggle').addEventListener('click', () => { const panel = $('accessibilityPanel'), open = panel.classList.contains('hidden'); panel.classList.toggle('hidden', !open); $('accessibilityToggle').setAttribute('aria-expanded', String(open)); if (open) $('textScaleSelect').focus(); });
  $('textScaleSelect').addEventListener('change', event => { try { localStorage.setItem('lcdj.textSize', event.target.value); } catch (_) {} applyAccessibilitySettings(); });
  $('highContrastToggle').addEventListener('change', event => { try { localStorage.setItem('lcdj.highContrast', String(event.target.checked)); } catch (_) {} applyAccessibilitySettings(); });
  $('difficultySelect').addEventListener('change', event => { save.difficulty = DIFFICULTIES[event.target.value] ? event.target.value : 'normal'; persist(); $('difficultyDescription').textContent = DIFFICULTIES[save.difficulty].explanation; });
  $('shareGame').addEventListener('click', shareGame);
  $('openTrophies').addEventListener('click', openTrophies);
  $('openTrophiesBanner').addEventListener('click', openTrophies);
  $('closeTrophies').addEventListener('click', closeTrophies);
  $('trophyFilters').addEventListener('click', event => {
    const button = event.target.closest('[data-filter]');
    if (!button) return;
    trophyFilter = button.dataset.filter;
    $('trophyFilters').querySelectorAll('[data-filter]').forEach(item => item.classList.toggle('active', item === button));
    renderTrophyCollection();
  });
  $('trophyNotificationDismiss').addEventListener('click', dismissTrophyNotification);
  $('trophyNotificationOpen').addEventListener('click', openTrophies);
  $('trophyOverlay').addEventListener('click', event => { if (event.target === $('trophyOverlay')) closeTrophies(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('trophyOverlay').classList.contains('hidden')) closeTrophies(); });
  toolsPanel.addEventListener('click', event => {
    const action = event.target.closest('[data-action]'); if (action) { handleAction(action.dataset.action); return; }
    const number = event.target.closest('[data-number]'); if (number) setSudokuValue(Number(number.dataset.number));
  });

  boardMount.addEventListener('click', event => {
    const sudokuCell = event.target.closest('[data-sudoku]');
    if (sudokuCell && game && !game.finished) { game.selected = Number(sudokuCell.dataset.sudoku); renderSudoku(); return; }
    const wordCell = event.target.closest('[data-word-cell]');
    if (wordCell && game && !game.finished) { selectWordCell(wordCell.dataset.wordCell); return; }
    const clue = event.target.closest('[data-entry]');
    if (clue && game && !game.finished) { selectEntry(Number(clue.dataset.entry)); return; }
    const searchCell = event.target.closest('[data-search-cell]');
    if (searchCell && game && !game.finished) { if (suppressNextSearchClick) { suppressNextSearchClick = false; return; } onSearchCell(searchCell.dataset.searchCell); return; }
    const memoryCard = event.target.closest('[data-memory]');
    if (memoryCard && game) flipMemory(Number(memoryCard.dataset.memory));
  });

  boardMount.addEventListener('pointerdown', event => {
    const cell = event.target.closest('[data-search-cell]');
    if (!cell || !game || game.finished || activeMode !== 'search' || event.button !== 0) return;
    const [r, c] = cell.dataset.searchCell.split(',').map(Number);
    searchPointerSelection = { pointerId: event.pointerId, start: { r, c }, startKey: cell.dataset.searchCell, lastKey: cell.dataset.searchCell };
    try { boardMount.setPointerCapture(event.pointerId); } catch (_) { /* Certains WebViews ne proposent pas le pointage capturé. */ }
    event.preventDefault();
  });
  boardMount.addEventListener('pointermove', event => {
    if (!searchPointerSelection || searchPointerSelection.pointerId !== event.pointerId) return;
    const cell = searchCellAtPoint(event.clientX, event.clientY);
    if (cell) updateSearchDragPreview(cell);
  });
  boardMount.addEventListener('pointerup', event => {
    if (!searchPointerSelection || searchPointerSelection.pointerId !== event.pointerId) return;
    const selection = searchPointerSelection, cell = searchCellAtPoint(event.clientX, event.clientY);
    searchPointerSelection = null;
    document.querySelectorAll('.search-cell.drag-path,.search-cell.drag-end').forEach(item => item.classList.remove('drag-path', 'drag-end'));
    suppressNextSearchClick = true; setTimeout(() => { suppressNextSearchClick = false; }, 80);
    if (cell && game && !game.finished) {
      const endKey = cell.dataset.searchCell;
      if (endKey === selection.startKey) onSearchCell(selection.startKey);
      else { const [r, c] = endKey.split(',').map(Number); completeSearchSelection(selection.start, { r, c }); }
    } else if (game && !game.finished) renderWordSearch();
    try { if (boardMount.hasPointerCapture(event.pointerId)) boardMount.releasePointerCapture(event.pointerId); } catch (_) { /* Capture déjà libérée par le système. */ }
  });
  boardMount.addEventListener('pointercancel', () => {
    if (!searchPointerSelection) return;
    searchPointerSelection = null;
    if (game && !game.finished && activeMode === 'search') renderWordSearch();
  });

  document.addEventListener('keydown', event => {
    if (event.target.matches('input,textarea,select,[contenteditable="true"]')) return;
    if (event.key === 'Escape' && !$('accessibilityPanel').classList.contains('hidden')) { closeAccessibilityPanel(); $('accessibilityToggle').focus(); return; }
    if (!activeMode || game?.finished || !$('trophyOverlay').classList.contains('hidden') || event.ctrlKey || event.altKey || event.metaKey) return;
    if (activeMode === 'sudoku') {
      if (/^[1-9]$/.test(event.key)) { setSudokuValue(Number(event.key)); event.preventDefault(); }
      else if (event.key === 'Backspace' || event.key === 'Delete' || event.key === '0') { setSudokuValue(0); event.preventDefault(); }
      else if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key)) { const delta = { ArrowUp: -9, ArrowDown: 9, ArrowLeft: -1, ArrowRight: 1 }[event.key]; game.selected = (game.selected + delta + 81) % 81; renderSudoku(); event.preventDefault(); }
    } else if (activeMode === 'crossword' || activeMode === 'arrows') {
      if (/^[a-zA-Z]$/.test(event.key)) { typeWordLetter(event.key.toUpperCase()); event.preventDefault(); }
      else if (event.key === 'Backspace' || event.key === 'Delete') { removeWordLetter(); event.preventDefault(); }
      else if (event.key === 'ArrowRight' || event.key === 'ArrowDown') { selectEntry((game.selected + 1) % game.entries.length); event.preventDefault(); }
      else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') { selectEntry((game.selected - 1 + game.entries.length) % game.entries.length); event.preventDefault(); }
    }
  });

  delete save.playerName; delete save.onlineWins;
  unlockTrophies(); persist();
  applyTheme(); applyAccessibilitySettings(); if (manualSaveExists()) $('restoreManualHome').classList.remove('hidden');
  renderHome();
  window.addEventListener('pagehide', persistAutomaticSave);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') persistAutomaticSave(); });
})();
