(() => {
  'use strict';

  const API_URL = window.LE_CERCLE_API_URL || 'https://loic-apps.duckdns.org/lecercle-api/v1/index.php';
  const PROFILE_KEY = 'lecercle.multiplayer.profile.v1';
  const CONSENT_VERSION = 'privacy-2026-11-22-v1.5.0';
  const NICKNAME_PATTERN = /^[\p{L}\p{N}_-]{3,20}$/u;
  const MODES = [
    { id: 'sudoku', title: 'Sudoku', icon: '▦' },
    { id: 'crossword', title: 'Mots croisés', icon: '✳' },
    { id: 'arrows', title: 'Mots fléchés', icon: '↘' },
    { id: 'search', title: 'Mots mêlés', icon: '⌕' },
    { id: 'memory', title: 'Mémory', icon: '❋' }
  ];
  const $ = id => document.getElementById(id);
  const overlay = $('challengeOverlay');
  const modeList = $('challengeModeList');
  const status = $('challengeStatus');
  const resultStatus = $('challengeResultStatus');
  let profile = readProfile();
  let challenges = new Map();
  let nicknameSupportStatus = 'checking';
  let lastRenderedNickname = null;
  let detectedCountry = { code: 'FR', name: 'France' };
  let currentLeaderboardMode = '';
  let currentCareerMode = '';
  let advancedApiSupported = false;
  let apiVersionSupported = false;
  let careerLeaderboardSupported = false;
  let careerDifficultySupported = false;
  let trophyTierRankingSupported = false;
  let trophyDataStorageSupported = false;
  let emailDeliveryConfigured = false;

  function cleanNickname(value) {
    return String(value || '').normalize('NFC').trim();
  }

  function nicknameError(value) {
    const nickname = cleanNickname(value);
    if (!nickname) return 'Saisis un pseudo pour le classement.';
    if (!NICKNAME_PATTERN.test(nickname)) return 'Le pseudo doit contenir de 3 à 20 lettres, chiffres, tirets ou tirets bas.';
    return '';
  }

  function readProfile() {
    try {
      const value = JSON.parse(localStorage.getItem(PROFILE_KEY) || 'null');
      return value && value.token && value.nickname ? value : null;
    } catch (_) { return null; }
  }

  function saveProfile(value) {
    if (value) localStorage.setItem(PROFILE_KEY, JSON.stringify(value));
    else { try { localStorage.removeItem(PROFILE_KEY); } catch (_) { /* Le profil serveur vient d’être supprimé. */ } }
    profile = value;
    renderProfile();
  }

  function renderProfile() {
    $('challengeRegistration').classList.toggle('hidden', !!profile);
    $('challengeProfileReady').classList.toggle('hidden', !profile);
    const editInput = $('challengeNicknameEdit');
    if (profile) {
      $('challengePlayerName').textContent = profile.nickname;
      const playerLabel = $('playerLabel');
      if (playerLabel) playerLabel.textContent = profile.nickname;
      const menuAction = $('profileMenuOpen');
      if (menuAction) menuAction.textContent = 'Gérer mon profil';
      if (lastRenderedNickname !== profile.nickname) {
        editInput.value = profile.nickname;
        lastRenderedNickname = profile.nickname;
      }
    } else {
      const playerLabel = $('playerLabel');
      if (playerLabel) playerLabel.textContent = 'Créer un compte';
      const menuAction = $('profileMenuOpen');
      if (menuAction) menuAction.textContent = 'Créer un compte joueur';
      lastRenderedNickname = null;
    }
    const consent = $('challengeConsent');
    $('shareTrophyProgress').disabled = !profile || !apiVersionSupported || !trophyTierRankingSupported || !trophyDataStorageSupported;
    $('sendEmailVerification').disabled = !profile || !emailDeliveryConfigured;
    $('verifyAccountEmail').disabled = !profile;
    $('sendRecoveryCode').disabled = !emailDeliveryConfigured;
    $('recoverAccount').disabled = false;
    $('leaderboardScope').disabled = !advancedApiSupported;
    const careerDifficulty = $('careerDifficulty');
    if (careerDifficulty) careerDifficulty.disabled = !careerDifficultySupported;
    $('acceptPrivacyUpdate').disabled = !profile || !apiVersionSupported;
    const createButton = $('createChallengeProfile');
    const nicknameInput = $('challengeNickname');
    if (consent && createButton) createButton.disabled = !!profile || !consent.checked || !!nicknameError(nicknameInput.value) || nicknameSupportStatus !== 'supported';
    const editButton = $('saveChallengeNickname');
    if (editButton) editButton.disabled = !profile || !!nicknameError(editInput.value) || cleanNickname(editInput.value) === (profile && profile.nickname) || nicknameSupportStatus !== 'supported';
    const serverMessage = nicknameSupportStatus === 'supported'
        ? ''
        : nicknameSupportStatus === 'unsupported'
          ? 'Mettez à jour le service du site vers la version 1.5 avant de créer ou modifier un compte joueur.'
          : nicknameSupportStatus === 'offline'
            ? 'Le classement est hors ligne. Réessaie quand le service sera accessible.'
            : 'Vérification du service de classement…';
    for (const noticeId of ['nicknameServerNotice', 'nicknameEditServerNotice']) {
      const serverNotice = $(noticeId);
      if (serverNotice) serverNotice.textContent = serverMessage;
    }
    renderCareerModes();
  }

  function applyFeatureFlags(features = {}) {
    apiVersionSupported = features.api_version === '1.5.0';
    advancedApiSupported = features.country_ranking === true && features.world_ranking === true;
    careerLeaderboardSupported = features.solo_leaderboard === true;
    careerDifficultySupported = features.solo_difficulty_leaderboard === true;
    trophyTierRankingSupported = features.trophy_tier_leaderboard === true;
    trophyDataStorageSupported = features.trophy_data_storage === true;
    emailDeliveryConfigured = features.email_delivery_configured === true;
  }

  async function request(action, { method = 'GET', params = {}, body = null, authenticated = false } = {}) {
    const url = new URL(API_URL);
    url.searchParams.set('action', action);
    for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value));
    const headers = { Accept: 'application/json' };
    if (body !== null) headers['Content-Type'] = 'application/json';
    if (authenticated && profile) headers.Authorization = `Bearer ${profile.token}`;
    const response = await fetch(url, { method, headers, body: body === null ? undefined : JSON.stringify(body), cache: 'no-store' });
    let payload;
    try { payload = await response.json(); } catch (_) { throw new Error('Le serveur a renvoyé une réponse illisible.'); }
    if (!response.ok || !payload || payload.ok !== true) throw new Error((payload && payload.error) || `Erreur réseau (${response.status}).`);
    return payload.data || {};
  }

  function setStatus(message, kind = '') {
    status.textContent = message;
    status.className = `challenge-status${kind ? ` ${kind}` : ''}`;
  }

  function formatTime(seconds) {
    const value = Math.max(0, Number(seconds) || 0);
    return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
  }

  function renderModes() {
    while (modeList.firstChild) modeList.removeChild(modeList.firstChild);
    for (const mode of MODES) {
      const challenge = challenges.get(mode.id);
      const row = document.createElement('article');
      row.className = 'challenge-mode-row';
      const symbol = document.createElement('span'); symbol.className = 'challenge-mode-symbol'; symbol.textContent = mode.icon;
      const copy = document.createElement('div'); copy.className = 'challenge-mode-copy';
      const title = document.createElement('b'); title.textContent = mode.title;
      const detail = document.createElement('small'); detail.textContent = challenge ? `Niveau ${challenge.level} · ${challenge.date_label}` : 'Défi quotidien';
      copy.append(title, detail);
      const play = document.createElement('button'); play.type = 'button'; play.className = 'challenge-play'; play.textContent = 'Jouer'; play.dataset.playChallenge = mode.id; play.disabled = !challenge;
      const ranking = document.createElement('button'); ranking.type = 'button'; ranking.className = 'challenge-ranking'; ranking.textContent = 'Classement'; ranking.dataset.leaderboardMode = mode.id; ranking.disabled = !challenge;
      row.append(symbol, copy, play, ranking);
      modeList.append(row);
    }
  }

  function renderCareerModes() {
    const container = $('careerRankingModes');
    if (!container) return;
    while (container.firstChild) container.removeChild(container.firstChild);
    for (const mode of MODES) {
      const row = document.createElement('article'); row.className = 'challenge-mode-row';
      const symbol = document.createElement('span'); symbol.className = 'challenge-mode-symbol'; symbol.textContent = mode.icon;
      const copy = document.createElement('div'); copy.className = 'challenge-mode-copy';
      const title = document.createElement('b'); title.textContent = mode.title;
      const detail = document.createElement('small'); detail.textContent = 'Progression des niveaux terminés'; copy.append(title, detail);
      const ranking = document.createElement('button'); ranking.type = 'button'; ranking.className = 'challenge-ranking'; ranking.textContent = 'Classement'; ranking.dataset.careerMode = mode.id; ranking.disabled = !careerLeaderboardSupported || !careerDifficultySupported;
      row.append(symbol, copy, ranking); container.append(row);
    }
  }

  async function loadChallenges() {
    challenges.clear(); nicknameSupportStatus = 'checking'; renderProfile(); renderModes(); setStatus('Connexion au classement…');
    let successful = [], dateLabel = '';
    try {
      const batch = await request('challenges');
      if (!Array.isArray(batch.challenges)) throw new Error('Réponse de défis incompatible.');
      successful = batch.challenges.map(value => ({ fulfilled: true, value }));
      batch.challenges.forEach(value => { if (value.mode) challenges.set(value.mode, value); if (!dateLabel) dateLabel = value.date_label || ''; });
      detectedCountry.code = String(batch.region || 'FR').toUpperCase(); detectedCountry.name = batch.country_name || detectedCountry.name;
      nicknameSupportStatus = batch.features?.custom_nickname === true && batch.features?.api_version === '1.5.0' ? 'supported' : 'unsupported';
      applyFeatureFlags(batch.features);
    } catch (_) {
      advancedApiSupported = false;
      const results = await Promise.all(MODES.map(mode => request('challenge', { params: { mode: mode.id } }).then(value => ({ fulfilled: true, value }), error => ({ fulfilled: false, error }))));
      successful = results.filter(result => result.fulfilled);
      nicknameSupportStatus = successful.length ? (successful.some(result => result.value.features && result.value.features.custom_nickname === true && result.value.features.api_version === '1.5.0') ? 'supported' : 'unsupported') : 'offline';
      applyFeatureFlags(successful[0]?.value?.features || {});
      results.forEach((result, index) => { if (result.fulfilled) { challenges.set(MODES[index].id, result.value); if (!dateLabel) dateLabel = result.value.date_label || ''; if (result.value.region) detectedCountry.code = String(result.value.region).toUpperCase(); if (result.value.country_name) detectedCountry.name = result.value.country_name; } });
    }
    renderModes(); renderCareerModes();
    renderProfile();
    if (!challenges.size) {
      setStatus('Le classement n’est pas encore joignable. Le service doit être installé sur le site.', 'error');
      return;
    }
    try { detectedCountry.name = new Intl.DisplayNames(['fr'], { type: 'region' }).of(detectedCountry.code) || detectedCountry.name; } catch (_) { /* Nom fourni par le serveur. */ }
    const countryText = successful.some(result => result.value.region_source === 'fallback') ? `${detectedCountry.name} (pays par défaut)` : detectedCountry.name;
    $('challengeNavLabel').textContent = `Défis ${detectedCountry.name}`;
    const missing = [!advancedApiSupported && 'classements pays/monde', !careerLeaderboardSupported && 'niveaux solo', !careerDifficultySupported && 'classements par difficulté', !trophyTierRankingSupported && 'trophées par niveau', !trophyDataStorageSupported && 'sauvegarde des trophées'].filter(Boolean);
    setStatus(`Défis du ${dateLabel} · pays détecté : ${countryText}${missing.length ? ` · mettez à jour le service pour activer : ${missing.join(', ')}` : ''}`, missing.length ? '' : 'success');
  }

  async function showLeaderboard(modeId) {
    const mode = MODES.find(item => item.id === modeId);
    if (!mode) return;
    currentLeaderboardMode = modeId;
    currentCareerMode = '';
    $('careerDifficultyRow').classList.add('hidden');
    $('leaderboardPanel').classList.remove('hidden');
    modeList.classList.add('hidden');
    $('careerRankingSection').classList.add('hidden');
    $('leaderboardTitle').textContent = `Classement · ${mode.title}`;
    $('leaderboardDate').textContent = 'Chargement…';
    while ($('leaderboardList').firstChild) $('leaderboardList').removeChild($('leaderboardList').firstChild);
    try {
      const scope = $('leaderboardScope').value;
      const data = await request('leaderboard', { params: { mode: modeId, scope } });
      $('leaderboardDate').textContent = `Défi du ${data.date_label} · ${scope === 'world' ? 'classement mondial' : `classement ${detectedCountry.name}`} · meilleurs temps, puis aides utilisées.`;
      if (!Array.isArray(data.entries) || !data.entries.length) {
        const empty = document.createElement('li'); empty.className = 'leaderboard-empty'; empty.textContent = `Aucun résultat pour le défi quotidien ${mode.title} d’aujourd’hui, dans ce classement. Les niveaux classiques apparaissent dans « Classement solo par jeu et difficulté ».`;
        $('leaderboardList').append(empty);
        return;
      }
      data.entries.forEach((entry, index) => {
        const item = document.createElement('li'); item.className = 'leaderboard-entry';
        const rank = document.createElement('span'); rank.className = 'leaderboard-rank'; rank.textContent = String(index + 1);
        const name = document.createElement('b'); name.className = 'leaderboard-name'; name.textContent = String(entry.nickname || 'Joueur');
        const time = document.createElement('span'); time.className = 'leaderboard-time'; time.textContent = formatTime(entry.best_seconds);
        const detail = document.createElement('small'); detail.textContent = `${Number(entry.hints_used) || 0} aide${Number(entry.hints_used) === 1 ? '' : 's'}`;
        item.append(rank, name, time, detail); $('leaderboardList').append(item);
      });
    } catch (error) {
      $('leaderboardDate').textContent = error.message || 'Classement indisponible.';
    }
  }

  async function showCareerLeaderboard(modeId) {
    const mode = MODES.find(item => item.id === modeId);
    if (!mode) return;
    if (!careerLeaderboardSupported || !careerDifficultySupported) { setStatus('Mettez à jour le service et sa base MySQL vers la version 1.5 pour activer les classements solo par difficulté.', 'error'); return; }
    currentCareerMode = modeId; currentLeaderboardMode = '';
    $('leaderboardPanel').classList.remove('hidden'); modeList.classList.add('hidden'); $('careerRankingSection').classList.add('hidden');
    $('careerDifficultyRow').classList.remove('hidden');
    const difficulty = $('careerDifficulty').value;
    const difficultyLabels = { relaxed: 'Tranquille', normal: 'Classique', expert: 'Expert' };
    $('leaderboardTitle').textContent = `Progression solo · ${mode.title} · ${difficultyLabels[difficulty] || 'Classique'}`;
    $('leaderboardDate').textContent = 'Chargement…';
    while ($('leaderboardList').firstChild) $('leaderboardList').removeChild($('leaderboardList').firstChild);
    try {
      const scope = $('leaderboardScope').value;
      const data = await request('career-leaderboard', { params: { mode: modeId, scope, difficulty } });
      $('leaderboardDate').textContent = `${scope === 'world' ? 'Classement mondial' : `Classement ${data.country_name || detectedCountry.name}`} · difficulté ${difficultyLabels[difficulty] || 'Classique'} · rang selon le niveau atteint, puis le temps cumulé.`;
      if (!Array.isArray(data.entries) || !data.entries.length) {
        const empty = document.createElement('li'); empty.className = 'leaderboard-empty'; empty.textContent = `Aucun niveau ${difficultyLabels[difficulty]?.toLowerCase() || 'classique'} enregistré pour ${mode.title}. Termine un niveau avec ton compte joueur et accepte la politique mise à jour pour apparaître ici.`; $('leaderboardList').append(empty); return;
      }
      data.entries.forEach((entry, index) => {
        const item = document.createElement('li'); item.className = 'leaderboard-entry career-ranking-entry';
        const rank = document.createElement('span'); rank.className = 'leaderboard-rank'; rank.textContent = String(index + 1);
        const name = document.createElement('b'); name.className = 'leaderboard-name'; name.textContent = String(entry.nickname || 'Joueur');
        const progress = document.createElement('span'); progress.className = 'leaderboard-time'; progress.textContent = `Niveau ${Number(entry.highest_level) || 0}`;
        const count = document.createElement('small'); count.textContent = `${Number(entry.completed_levels) || 0} niveaux`;
        const time = document.createElement('small'); time.textContent = formatTime(entry.total_seconds);
        item.append(rank, name, progress, count, time); $('leaderboardList').append(item);
      });
    } catch (error) { $('leaderboardDate').textContent = error.message || 'Classement indisponible.'; }
  }

  async function registerProfile() {
    if (!$('challengeConsent').checked) { setStatus('Coche la case pour participer aux classements.', 'error'); return; }
    if (nicknameSupportStatus !== 'supported') { setStatus('Le service du site doit être mis à jour avant de choisir un pseudo.', 'error'); return; }
    const nickname = cleanNickname($('challengeNickname').value);
    const validation = nicknameError(nickname);
    if (validation) { setStatus(validation, 'error'); return; }
    $('createChallengeProfile').disabled = true; setStatus('Enregistrement du pseudo…');
    try {
      const storageProbe = `${PROFILE_KEY}.check`;
      localStorage.setItem(storageProbe, '1'); localStorage.removeItem(storageProbe);
      const data = await request('register', { method: 'POST', body: { nickname, consent: true, consent_version: CONSENT_VERSION } });
      if (data.nickname !== nickname) throw new Error('Le serveur n’a pas confirmé le pseudo choisi. Mets à jour le service du site puis réessaie.');
      saveProfile({ nickname: data.nickname, token: data.token });
      syncTrophyProgress(false);
      setStatus('Pseudo enregistré. Choisis un défi pour jouer.', 'success');
    } catch (error) {
      setStatus(error.message || 'Impossible d’enregistrer le pseudo.', 'error');
    } finally { $('createChallengeProfile').disabled = false; }
  }

  async function renameProfile() {
    if (!profile) return;
    const nickname = cleanNickname($('challengeNicknameEdit').value);
    const validation = nicknameError(nickname);
    if (validation) { setStatus(validation, 'error'); return; }
    if (nicknameSupportStatus !== 'supported') { setStatus('Le service du site doit être mis à jour avant de changer le pseudo.', 'error'); return; }
    $('saveChallengeNickname').disabled = true; setStatus('Mise à jour du pseudo…');
    try {
      const data = await request('rename', { method: 'POST', body: { nickname }, authenticated: true });
      saveProfile({ ...profile, nickname: data.nickname });
      setStatus(`Pseudo modifié : ${data.nickname}.`, 'success');
    } catch (error) {
      setStatus(error.message || 'Impossible de modifier le pseudo.', 'error');
    } finally { renderProfile(); }
  }

  async function deleteProfile() {
    if (!profile || !window.confirm('Supprimer ce pseudo et tous ses résultats du classement ?')) return;
    $('deleteChallengeProfile').disabled = true; setStatus('Suppression du profil…');
    try {
      await request('delete', { method: 'POST', body: {}, authenticated: true });
      try { localStorage.removeItem(PROFILE_KEY); } catch (_) { /* Profil supprimé du serveur. */ }
      saveProfile(null);
      setStatus('Pseudo et résultats supprimés.', 'success');
    } catch (error) {
      setStatus(error.message || 'Impossible de supprimer le profil.', 'error');
    } finally { $('deleteChallengeProfile').disabled = false; }
  }

  async function startChallenge(modeId) {
    let challenge = challenges.get(modeId);
    if (!challenge) {
      try { challenge = await request('challenge', { params: { mode: modeId } }); challenges.set(modeId, challenge); }
      catch (error) { setStatus(error.message || 'Défi indisponible.', 'error'); return; }
    }
    overlay.classList.add('hidden');
    if (typeof window.startDailyChallenge === 'function') window.startDailyChallenge(modeId, challenge);
  }

  async function submitResult(event) {
    const result = event.detail;
    if (!result || !result.mode || !result.date) return;
    if (!profile) { resultStatus.textContent = 'Résultat terminé ; aucun pseudo enregistré pour le classement.'; return; }
    if (!apiVersionSupported) { resultStatus.textContent = 'Mettez à jour le service du site vers la version 1.5 pour envoyer les résultats avec la nouvelle politique.'; return; }
    resultStatus.textContent = 'Envoi du résultat au classement…';
    try {
      const saved = await request('submit', {
        method: 'POST', authenticated: true,
        body: { mode: result.mode, date: result.date, elapsed_seconds: result.elapsedSeconds, mistakes: result.mistakes, hints_used: result.hintsUsed }
      });
      resultStatus.textContent = saved.improved ? `Résultat classé : ${formatTime(saved.best_seconds)}.` : `Ton meilleur temps reste ${formatTime(saved.best_seconds)}.`;
    } catch (error) {
      resultStatus.textContent = `Résultat terminé, envoi impossible : ${error.message || 'classement indisponible'}.`;
    }
  }

  async function submitLevelResult(event) {
    const result = event.detail;
    if (!result || !result.mode || !Number.isInteger(Number(result.level))) return;
    if (!profile) { resultStatus.textContent = 'Niveau terminé. Crée un compte joueur pour rejoindre le classement des niveaux solo.'; return; }
    if (!apiVersionSupported) { resultStatus.textContent = 'Niveau terminé. Mettez à jour le service et la base MySQL vers la version 1.5 avant d’envoyer des résultats.'; return; }
    if (!careerLeaderboardSupported || !careerDifficultySupported) { resultStatus.textContent = 'Niveau terminé. Le classement solo par difficulté sera disponible après la mise à jour du service et de sa base MySQL.'; return; }
    resultStatus.textContent = 'Ajout du niveau au classement solo…';
    try {
      const saved = await request('level-submit', { method: 'POST', authenticated: true, body: { mode: result.mode, level: Number(result.level), difficulty: result.difficulty, elapsed_seconds: result.elapsedSeconds, mistakes: result.mistakes, hints_used: result.hintsUsed } });
      resultStatus.textContent = saved.improved ? `Niveau ${result.level} ajouté au classement · meilleur temps ${formatTime(saved.best_seconds)}.` : `Niveau ${result.level} conservé dans ta progression · meilleur temps ${formatTime(saved.best_seconds)}.`;
    } catch (error) { resultStatus.textContent = `Niveau terminé, envoi au classement impossible : ${error.message || 'service indisponible'}.`; }
  }

  function currentTrophyCount() {
    const values = String($('headerTrophyCount')?.textContent || '0 / 0').match(/(\d+)\s*\//);
    return values ? Number(values[1]) : 0;
  }

  function currentTrophyCounts() {
    const counts = window.leCercleTrophyCounts || {};
    return { total: currentTrophyCount(), bronze: Number(counts.bronze) || 0, silver: Number(counts.silver) || 0, gold: Number(counts.gold) || 0, diamond: Number(counts.diamond) || 0, unlocked_ids: Array.isArray(window.leCercleUnlockedTrophyIds) ? window.leCercleUnlockedTrophyIds : [] };
  }

  async function syncTrophyConsent() {
    return syncTrophyProgress(true);
  }

  async function syncTrophyProgress(announce = false) {
    if (!profile) { if (announce) $('trophyCompareResult').textContent = 'Créez ou récupérez un pseudo pour comparer votre progression.'; return; }
    if (!apiVersionSupported || !trophyDataStorageSupported) { if (announce) $('trophyCompareResult').textContent = 'Mettez à jour le service et la base MySQL vers la version 1.5 pour enregistrer vos trophées.'; return; }
    const enabled = $('shareTrophyProgress').checked;
    try {
      await request('trophy-progress', { method: 'POST', authenticated: true, body: { share: enabled, ...currentTrophyCounts() } });
      if (announce) $('trophyCompareResult').textContent = enabled ? 'Partage activé. Votre pseudo et vos totaux par niveau seront visibles.' : 'Partage désactivé. Vos trophées restent enregistrés dans votre compte, mais ils ne figurent plus dans le classement public.';
    } catch (error) { if (announce) $('trophyCompareResult').textContent = error.message || 'Mise à jour du partage impossible.'; }
  }

  async function compareTrophies() {
    const output = $('trophyCompareResult');
    if (!profile) { output.textContent = 'Créez ou récupérez un pseudo pour comparer votre progression.'; return; }
    if (!$('shareTrophyProgress').checked) { output.textContent = 'Activez le partage facultatif pour comparer votre progression.'; return; }
    if (!apiVersionSupported || !trophyTierRankingSupported || !trophyDataStorageSupported) { output.textContent = 'Mettez à jour le service et la base MySQL vers la version 1.5 pour activer les classements de trophées.'; return; }
    output.textContent = 'Comparaison en cours…';
    try {
      await request('trophy-progress', { method: 'POST', authenticated: true, body: { share: true, ...currentTrophyCounts() } });
      const tier = $('trophyCompareTier').value;
      const data = await request('trophy-leaderboard', { params: { scope: $('trophyCompareScope').value, tier }, authenticated: true });
      const scopeLabel = data.scope === 'world' ? 'dans le monde' : `en ${data.country_name || detectedCountry.name}`;
      const tierLabel = { total: 'tous les trophées', bronze: 'les trophées bronze', silver: 'les trophées argent', gold: 'les trophées or', diamond: 'les trophées diamant' }[tier] || 'les trophées';
      output.textContent = data.total_players ? `Classement ${scopeLabel} pour ${tierLabel} · ${data.rank}${ordinalSuffix(data.rank)} sur ${data.total_players} joueurs.` : `Aucun joueur ne partage encore ${tierLabel} ${scopeLabel}.`;
      const list = $('trophyLeaderboardList'); while (list.firstChild) list.removeChild(list.firstChild);
      (data.entries || []).forEach((entry, index) => {
        const item = document.createElement('li'); item.className = 'trophy-leaderboard-entry';
        const rank = document.createElement('span'); rank.textContent = String(index + 1);
        const name = document.createElement('b'); name.textContent = String(entry.nickname || 'Joueur');
        const value = document.createElement('span'); value.className = 'trophy-leaderboard-value'; value.textContent = `${Number(entry.count) || 0} ${tier === 'total' ? 'trophées' : tierLabel.replace('les trophées ', '')}`;
        item.append(rank, name, value); list.append(item);
      });
    } catch (error) { output.textContent = error.message || 'Comparaison indisponible. Vérifiez que le serveur est à jour.'; }
  }

  function ordinalSuffix(value) { return Number(value) === 1 ? 'er' : 'e'; }

  async function refreshAccountStatus() {
    if (!profile) return;
    try {
      const data = await request('account-status', { authenticated: true });
      $('shareTrophyProgress').checked = !!data.share_trophies;
      emailDeliveryConfigured = data.email_delivery_configured === true;
      renderProfile();
      $('accountEmailStatus').textContent = !apiVersionSupported
        ? 'Mettez à jour le service du site vers la version 1.5 pour utiliser la nouvelle protection de compte.'
        : !emailDeliveryConfigured
        ? 'L’envoi d’e-mail n’est pas configuré sur le serveur. La protection et la récupération par e-mail seront disponibles après le réglage du fournisseur mail sur l’hébergement.'
        : (data.email_verified ? `Adresse confirmée : ${data.email_masked}` : (data.pending_email ? `Vérification envoyée à ${data.pending_email}.` : 'Aucune adresse e-mail confirmée.'));
      const updateBox = $('privacyUpdateBox'); updateBox.classList.toggle('hidden', data.consent_version === CONSENT_VERSION);
      if (data.consent_version !== CONSENT_VERSION) $('trophyCompareResult').textContent = 'Confirmez la politique mise à jour dans votre profil pour reprendre l’envoi des résultats.';
      else syncTrophyProgress(false);
    } catch (_) { /* Un ancien serveur conserve le fonctionnement solo et le classement existant. */ }
  }

  async function sendVerificationCode() {
    if (!profile) return;
    if (!emailDeliveryConfigured) { $('accountEmailStatus').textContent = 'L’envoi d’e-mail n’est pas configuré sur le serveur. Réglez le service SMTP dans la configuration privée de l’hébergement.'; return; }
    const output = $('accountEmailStatus'); output.textContent = 'Envoi du code…';
    try { const data = await request('email-start', { method: 'POST', body: { email: $('accountEmail').value.trim() }, authenticated: true }); output.textContent = data.message || 'Code envoyé. Vérifiez votre messagerie.'; }
    catch (error) { output.textContent = error.message || 'Envoi du code impossible. Le serveur doit être mis à jour.'; }
  }

  async function verifyAccountEmail() {
    if (!profile) return;
    const output = $('accountEmailStatus'); output.textContent = 'Vérification…';
    try { const data = await request('email-verify', { method: 'POST', body: { code: $('emailVerificationCode').value.trim() }, authenticated: true }); output.textContent = `Adresse confirmée : ${data.email_masked}.`; }
    catch (error) { output.textContent = error.message || 'Code invalide ou expiré.'; }
  }

  async function sendRecoveryCode() {
    const output = $('recoveryStatus'); output.textContent = 'Demande en cours…';
    if (!emailDeliveryConfigured) { output.textContent = 'L’envoi d’e-mail n’est pas configuré sur le serveur. La récupération sera disponible après le réglage du service SMTP sur l’hébergement.'; return; }
    try { const data = await request('recover-start', { method: 'POST', body: { nickname: $('recoveryNickname').value.trim(), email: $('recoveryEmail').value.trim() } }); output.textContent = data.message || 'Si les informations correspondent à un compte confirmé, un code a été envoyé.'; }
    catch (error) { output.textContent = error.message || 'La demande de récupération est indisponible.'; }
  }

  async function recoverAccount() {
    const output = $('recoveryStatus'); output.textContent = 'Récupération du compte…';
    try { const data = await request('recover-finish', { method: 'POST', body: { nickname: $('recoveryNickname').value.trim(), email: $('recoveryEmail').value.trim(), code: $('recoveryCode').value.trim() } }); saveProfile({ nickname: data.nickname, token: data.token }); output.textContent = 'Accès récupéré. Votre appareil est reconnecté au compte.'; await refreshAccountStatus(); }
    catch (error) { output.textContent = error.message || 'Code invalide ou expiré.'; }
  }

  async function acceptPrivacyUpdate() {
    if (!profile || !$('privacyUpdateConsent').checked) return;
    try { await request('update-consent', { method: 'POST', body: { consent: true, consent_version: CONSENT_VERSION }, authenticated: true }); $('privacyUpdateBox').classList.add('hidden'); setStatus('Votre choix est enregistré.', 'success'); syncTrophyProgress(false); }
    catch (error) { setStatus(error.message || 'Impossible d’enregistrer votre choix.', 'error'); }
  }

  function openChallengeCenter() {
    overlay.classList.remove('hidden');
    $('leaderboardPanel').classList.add('hidden'); modeList.classList.remove('hidden'); $('careerRankingSection').classList.remove('hidden');
    currentLeaderboardMode = ''; currentCareerMode = '';
    renderProfile(); loadChallenges(); refreshAccountStatus();
  }

  function closeProfileMenu() {
    $('profileMenu').classList.add('hidden'); $('profileMenuButton').setAttribute('aria-expanded', 'false');
  }

  $('openChallenges').addEventListener('click', openChallengeCenter);
  $('profileMenuButton').addEventListener('click', event => {
    event.stopPropagation();
    const menu = $('profileMenu'), opening = menu.classList.contains('hidden');
    menu.classList.toggle('hidden', !opening); $('profileMenuButton').setAttribute('aria-expanded', String(opening));
  });
  $('profileMenuOpen').addEventListener('click', () => { closeProfileMenu(); openChallengeCenter(); });
  $('profileMenuTrophies').addEventListener('click', () => { closeProfileMenu(); $('openTrophies').click(); });
  document.addEventListener('click', event => { if (!event.target.closest('#profileMenu') && !event.target.closest('#profileMenuButton')) closeProfileMenu(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeProfileMenu(); });
  $('closeChallenges').addEventListener('click', () => overlay.classList.add('hidden'));
  $('createChallengeProfile').addEventListener('click', registerProfile);
  $('challengeNickname').addEventListener('input', renderProfile);
  $('challengeNicknameEdit').addEventListener('input', renderProfile);
  $('saveChallengeNickname').addEventListener('click', renameProfile);
  $('challengeConsent').addEventListener('change', renderProfile);
  $('deleteChallengeProfile').addEventListener('click', deleteProfile);
  $('backToChallenges').addEventListener('click', () => { $('leaderboardPanel').classList.add('hidden'); modeList.classList.remove('hidden'); $('careerRankingSection').classList.remove('hidden'); currentLeaderboardMode = ''; currentCareerMode = ''; });
  $('leaderboardScope').addEventListener('change', () => { if (currentLeaderboardMode) showLeaderboard(currentLeaderboardMode); else if (currentCareerMode) showCareerLeaderboard(currentCareerMode); });
  $('careerDifficulty').addEventListener('change', () => { if (currentCareerMode) showCareerLeaderboard(currentCareerMode); });
  $('shareTrophyProgress').addEventListener('change', syncTrophyConsent);
  $('refreshTrophyCompare').addEventListener('click', compareTrophies);
  $('sendEmailVerification').addEventListener('click', sendVerificationCode);
  $('verifyAccountEmail').addEventListener('click', verifyAccountEmail);
  $('sendRecoveryCode').addEventListener('click', sendRecoveryCode);
  $('recoverAccount').addEventListener('click', recoverAccount);
  $('acceptPrivacyUpdate').addEventListener('click', acceptPrivacyUpdate);
  $('openTrophies').addEventListener('click', () => { loadChallenges(); refreshAccountStatus(); });
  $('openTrophiesBanner').addEventListener('click', () => { loadChallenges(); refreshAccountStatus(); });
  overlay.addEventListener('click', event => { if (event.target === overlay) overlay.classList.add('hidden'); });
  modeList.addEventListener('click', event => {
    const play = event.target.closest('[data-play-challenge]');
    const ranking = event.target.closest('[data-leaderboard-mode]');
    if (play && !play.disabled) startChallenge(play.dataset.playChallenge);
    if (ranking && !ranking.disabled) showLeaderboard(ranking.dataset.leaderboardMode);
  });
  $('careerRankingModes').addEventListener('click', event => {
    const ranking = event.target.closest('[data-career-mode]');
    if (ranking && !ranking.disabled) showCareerLeaderboard(ranking.dataset.careerMode);
  });
  window.addEventListener('lcdj:challenge-finished', submitResult);
  window.addEventListener('lcdj:level-finished', submitLevelResult);
  window.addEventListener('lcdj:trophy-progress', () => { syncTrophyProgress(false); });
  renderProfile(); renderModes(); renderCareerModes();
})();
