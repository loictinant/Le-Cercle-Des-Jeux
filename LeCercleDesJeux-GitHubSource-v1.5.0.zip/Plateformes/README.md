# Versions Windows Store et Android

Ces projets emballent le jeu original, sans modifier ses fichiers et sans remplacer les deux propositions visuelles conservées dans `Propositions/`.

- `WindowsStore/` : application UWP empaquetée en MSIX.
- `Android/` : APK Android hors ligne et, avec la clé de téléversement locale, AAB pour Google Play.
- `Sync-GameFiles.ps1` : recopie le jeu et ajoute une page de confidentialité propre aux paquets mobiles/boutique.

Les trophées sont les trophées internes du jeu : ils restent enregistrés sur cet appareil. L’édition Windows Store est préparée pour une monétisation facultative propre à cette version ; elle reste désactivée jusqu’à la configuration des comptes et identifiants publicitaires et Store. L’EXE d’essai et Android restent sans publicité dans cette intégration.
