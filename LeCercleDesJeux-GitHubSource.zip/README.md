# Le Cercle des jeux

Jeu de réflexion solo pour Windows et Android : sudoku, mots croisés, mots fléchés, mots mêlés et mémory. Les grilles sont renouvelées au fil des niveaux et la progression d’essai reste locale à l’appareil.

Présentation : https://tinant-loic-applications.thinmorningglory.chatgpt.site/apps/le-cercle-des-jeux/

## Versions

- **WindowsStore** : application UWP empaquetée en MSIX.
- **WindowsExe** : EXE x64 d’essai et lanceur préparé pour ouvrir la fiche Microsoft Store après publication.
- **Android** : application Android hors ligne, APK de test et préparation du bundle Google Play.
- **Propositions** : deux présentations alternatives conservées séparément de l’édition classique.

## Compiler

Les scripts de plateforme se trouvent dans LeCercleDesJeux/Plateformes/.

- EXE Windows d’essai : LeCercleDesJeux/Plateformes/WindowsExe/build.ps1
- MSIX Windows Store : LeCercleDesJeux/Plateformes/WindowsStore/build.ps1
- APK Android : LeCercleDesJeux/Plateformes/Android/build.ps1

Les outils requis sont décrits dans les README de chaque plateforme. Les fichiers de compilation vont dans deliverables/ et ne font pas partie du dépôt.

## Trophées

La collection de trophées de l’essai est locale à l’appareil. Les succès Windows Store et les trophées Android sont deux intégrations distinctes ; ils ne sont pas activés par l’EXE d’essai et leur configuration officielle reste à finaliser.

## Confidentialité

Le jeu fonctionne hors ligne, sans compte ni publicité. Les parties et trophées locaux restent sur l’appareil. Les propositions visuelles restent indépendantes de l’édition classique.
