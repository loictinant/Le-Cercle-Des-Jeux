param(
    [Parameter(Mandatory = $true)]
    [string]$Destination
)

$ErrorActionPreference = 'Stop'
$source = Join-Path (Split-Path -Parent $PSScriptRoot) ''
$destinationPath = [System.IO.Path]::GetFullPath($Destination)
New-Item -ItemType Directory -Path $destinationPath -Force | Out-Null

foreach ($name in @('index.html', 'style.css', 'details.css', 'app.js')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $destinationPath $name) -Force
}

$indexPath = Join-Path $destinationPath 'index.html'
$html = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
$footer = '<footer class="home-footer"><span>LE CERCLE DES JEUX <i>·</i> ÉDITION CLASSIQUE</span><span>Vos parties restent sur cet appareil.</span></footer>'
$footerWithPrivacy = '<footer class="home-footer"><span>LE CERCLE DES JEUX <i>·</i> ÉDITION CLASSIQUE</span><span>Vos parties restent sur cet appareil.</span><a class="privacy-link" href="privacy.html">Confidentialité</a></footer>'
if ($html.Contains($footer)) {
    $html = $html.Replace($footer, $footerWithPrivacy)
}
[System.IO.File]::WriteAllText($indexPath, $html, (New-Object System.Text.UTF8Encoding($false)))

$cssPath = Join-Path $destinationPath 'style.css'
$css = [System.IO.File]::ReadAllText($cssPath, [System.Text.Encoding]::UTF8)
$css += "`n.privacy-link{color:inherit;text-decoration:underline;text-underline-offset:3px}`n"
[System.IO.File]::WriteAllText($cssPath, $css, (New-Object System.Text.UTF8Encoding($false)))

$privacy = @'
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#f6f3eb">
  <title>Confidentialité — Le Cercle des jeux</title>
  <style>
    :root{font-family:"Segoe UI",Arial,sans-serif;color:#202d2a;background:#f6f3eb}
    body{margin:0;padding:24px;line-height:1.65}
    main{max-width:760px;margin:32px auto;padding:32px;background:#fcfaf5;border:1px solid #e6e2d8;border-radius:8px}
    h1{font-family:Georgia,serif;line-height:1.2}
    h2{margin-top:28px;font-size:1.15rem}
    a{color:#315d4e}
    small{color:#75817a}
    @media(max-width:520px){body{padding:12px}main{margin:12px auto;padding:22px}}
  </style>
</head>
<body>
  <main>
    <a href="index.html">← Retour au jeu</a>
    <h1>Confidentialité</h1>
    <p><strong>Le Cercle des jeux</strong> est publié par Loïc Tinant. Cette politique décrit la version hors ligne distribuée dans les boutiques Windows et Android.</p>
    <p><small>Dernière mise à jour : 16 novembre 2026</small></p>
    <h2>Données et fonctionnement</h2>
    <p>Le jeu ne demande pas de compte et ne transmet pas vos parties à un serveur. Votre progression, vos trophées et vos préférences sont enregistrés localement sur l’appareil, dans l’espace de stockage de l’application.</p>
    <p>Cette version ne contient ni publicité, ni suivi publicitaire, ni outil d’analyse. Elle ne demande aucune permission d’accès aux contacts, à la localisation, au microphone ou à l’appareil photo.</p>
    <h2>Conservation et suppression</h2>
    <p>Les données de progression restent sur l’appareil. La désinstallation de l’application ou l’effacement de ses données système les supprime. Elles ne sont pas synchronisées entre appareils.</p>
    <h2>Contact</h2>
    <p>Pour toute question concernant cette politique, écrivez à <a href="mailto:loictinant@hotmail.com">loictinant@hotmail.com</a>.</p>
  </main>
</body>
</html>
'@
[System.IO.File]::WriteAllText((Join-Path $destinationPath 'privacy.html'), $privacy, (New-Object System.Text.UTF8Encoding($false)))
