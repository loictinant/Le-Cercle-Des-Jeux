# Version Windows Store

Le projet est une application UWP empaquetée en MSIX, avec le jeu principal inclus hors ligne dans une WebView. Il ne contient pas les deux propositions visuelles non validées.

Le manifeste reprend l’éditeur utilisé par vos autres applications (`TINANT LOIC`, certificat `CN=D67E21A8-DC00-45EF-86D1-375158FB659F`). Le nom d’identité proposé est `TINANTLOIC.LeCercleDesJeux` ; vérifiez qu’il correspond à l’identité affichée dans Partner Center après avoir réservé le nom. Le package local signé est destiné au développement ; Microsoft re-signe les packages acceptés pour la distribution Store.

Le script `build.ps1` synchronise le jeu de base et produit les packages dans `deliverables/LeCercleDesJeux/Windows`. La progression reste locale à chaque appareil et n’est pas partagée entre Windows et Android.
