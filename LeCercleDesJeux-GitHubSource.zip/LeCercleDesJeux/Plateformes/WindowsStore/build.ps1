$ErrorActionPreference = 'Stop'
$windowsRoot = $PSScriptRoot
$gameRoot = Split-Path -Parent (Split-Path -Parent $windowsRoot)
$repoRoot = Split-Path -Parent $gameRoot
$outputDir = Join-Path $repoRoot 'deliverables\LeCercleDesJeux\Windows'
$syncScript = Join-Path (Split-Path -Parent $windowsRoot) 'Sync-GameFiles.ps1'

& $syncScript -Destination (Join-Path $windowsRoot 'www')
& (Join-Path $windowsRoot 'generate-assets.ps1')
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null

$vswhere = 'C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'
$vsPath = & $vswhere -products * -requires Microsoft.VisualStudio.Workload.Universal -property installationPath
if (-not $vsPath) { throw "Le composant Windows UWP requis n'a pas été trouvé." }
$msbuild = Join-Path $vsPath 'MSBuild\Current\Bin\MSBuild.exe'
$certName = 'LeCercleDesJeux-Store-Test'
$publisherSubject = 'CN=D67E21A8-DC00-45EF-86D1-375158FB659F'
$certificate = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.FriendlyName -eq $certName -and $_.Subject -eq $publisherSubject -and $_.HasPrivateKey } | Select-Object -First 1
if (-not $certificate) {
    $certificate = New-SelfSignedCertificate -Type CodeSigningCert -Subject $publisherSubject -FriendlyName $certName -CertStoreLocation Cert:\CurrentUser\My -NotAfter (Get-Date).AddYears(5)
}

$buildArguments = @(
    (Join-Path $windowsRoot 'LeCercleDesJeux.Windows.csproj'),
    '/restore',
    '/t:Rebuild',
    '/verbosity:minimal',
    '/p:Configuration=Release',
    '/p:Platform=x64',
    '/p:GenerateAppxPackageOnBuild=true',
    '/p:AppxPackageSigningEnabled=true',
    "/p:PackageCertificateThumbprint=$($certificate.Thumbprint)",
    '/p:AppxBundle=Always',
    '/p:AppxBundlePlatforms=x64|arm64',
    ("/p:AppxPackageDir=" + $outputDir + '\')
)
Push-Location $windowsRoot
try {
    & $msbuild @buildArguments
} finally {
    Pop-Location
}
if ($LASTEXITCODE -ne 0) { throw 'La compilation MSIX Windows a échoué.' }

$generatedPackages = Get-ChildItem $outputDir -File -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in '.msixupload', '.msixbundle', '.appxupload', '.appxbundle', '.cer' }
foreach ($package in $generatedPackages) {
    if ($package.DirectoryName -ne $outputDir) {
        Copy-Item -LiteralPath $package.FullName -Destination $outputDir -Force
    }
}

# Partner Center recommends an upload archive containing the architecture bundle and symbols.
$uploadBundle = Get-ChildItem -LiteralPath $outputDir -File -Filter '*_x64_arm64.msixbundle' |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1
if (-not $uploadBundle) { throw 'Le bundle MSIX x64/ARM64 est introuvable pour créer le paquet Store.' }

$testFolderName = $uploadBundle.BaseName -replace '_x64_arm64$', '_Test'
$testFolder = Join-Path $outputDir $testFolderName
$uploadSymbols = @(Get-ChildItem -LiteralPath $testFolder -File -Filter '*.appxsym' -ErrorAction SilentlyContinue)
if ($uploadSymbols.Count -lt 2) { throw "Les symboles x64 et ARM64 sont introuvables dans : $testFolder" }

Add-Type -AssemblyName System.IO.Compression.FileSystem
$uploadPath = Join-Path $outputDir ($uploadBundle.BaseName + '.msixupload')
if (Test-Path -LiteralPath $uploadPath) { Remove-Item -LiteralPath $uploadPath -Force }
$uploadArchive = [System.IO.Compression.ZipFile]::Open(
    $uploadPath,
    [System.IO.Compression.ZipArchiveMode]::Create
)
try {
    $uploadFiles = @($uploadBundle) + $uploadSymbols
    foreach ($file in $uploadFiles) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $uploadArchive,
            $file.FullName,
            $file.Name,
            [System.IO.Compression.CompressionLevel]::Optimal
        ) | Out-Null
    }
}
finally {
    $uploadArchive.Dispose()
}

$testReadme = Join-Path $testFolder 'README_TEST.txt'
@'
LE CERCLE DES JEUX — VERSION DE TEST WINDOWS

1. Extrayez ce dossier complet dans un emplacement local.
2. Lancez Install.ps1 avec PowerShell (option -SkipLoggingTelemetry conseillée).
3. Suivez les invites Windows pour installer les dépendances et le certificat de test.
4. Lancez « Le Cercle des jeux » depuis le menu Démarrer.

Le certificat fourni est un certificat de développement local. Il ne sert qu'à installer ce paquet de test et ne doit pas être distribué.
'@ | Set-Content -LiteralPath $testReadme -Encoding UTF8

$testArchivePath = Join-Path $outputDir ($testFolderName + '.zip')
Compress-Archive -Path (Join-Path $testFolder '*') -DestinationPath $testArchivePath -CompressionLevel Optimal -Force

Write-Host "Paquet à téléverser dans Partner Center : $uploadPath"
Write-Host "Kit d’installation/test : $testArchivePath"
Get-ChildItem $outputDir | Select-Object Name, Length, LastWriteTime
