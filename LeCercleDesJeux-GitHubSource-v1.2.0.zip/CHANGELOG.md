# Changements

## 1.2.0 — 18 novembre 2026

- Le joueur choisit un pseudo public unique de 3 à 20 caractères et peut le modifier ensuite.
- Ajout d’une vérification de compatibilité : l’application signale quand le service PHP du site doit être mis à jour.
- Remplacement de l’illustration d’accueil par une scène 3D réunissant les cinq jeux.
- Ajout d’animations douces sur l’accueil, avec respect du réglage « réduire les animations » de l’appareil.
- Précision dans l’interface : le classement reste réglé sur la France et n’utilise pas la localisation de l’appareil.

## 1.1.0 — 18 novembre 2026

- Ajout des défis quotidiens asynchrones France et d’un classement séparé pour chacun des cinq jeux.
- Les grilles quotidiennes sont générées à partir d’une graine commune fournie par le service.
- La participation au classement est facultative et demande une acceptation explicite ; le pseudo était généré automatiquement dans cette version.
- Ajout d’une API PHP/MySQL, de la suppression du profil et d’une politique de confidentialité dédiée.
- Le mode solo, sa progression et les trophées internes restent disponibles hors ligne.
- Les succès Windows/Xbox restent désactivés. Le service doit être installé et configuré sur l’hébergement avant que le classement soit joignable.
