<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Cache-Control: no-store, max-age=0');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ok(array $data = []): never
{
    respond(['ok' => true, 'data' => $data]);
}

function fail(string $message, int $status = 400): never
{
    respond(['ok' => false, 'error' => $message], $status);
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > 8192) {
        fail('La requête est trop volumineuse.', 413);
    }
    $value = json_decode($raw, true);
    if (!is_array($value)) {
        fail('Le contenu JSON est invalide.');
    }
    return $value;
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $configPath = dirname(__DIR__) . '/config.php';
    if (!is_file($configPath)) {
        fail('Le service multijoueur n’est pas encore configuré sur le site.', 503);
    }
    $config = require $configPath;
    if (!is_array($config) || empty($config['dsn']) || empty($config['username']) || !isset($config['password']) || strlen((string)($config['challenge_secret'] ?? '')) < 32) {
        fail('La configuration du service multijoueur est incomplète.', 503);
    }

    try {
        $pdo = new PDO((string)$config['dsn'], (string)$config['username'], (string)$config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Throwable $exception) {
        error_log('Le Cercle des jeux API: connexion MySQL impossible.');
        fail('Le classement est temporairement indisponible.', 503);
    }
    return $pdo;
}

function allowedMode(string $mode): string
{
    $modes = ['sudoku', 'crossword', 'arrows', 'search', 'memory'];
    if (!in_array($mode, $modes, true)) fail('Jeu inconnu.');
    return $mode;
}

function normalizeNickname(mixed $value): string
{
    if (!is_string($value)) fail('Saisis un pseudo pour le classement.');
    $nickname = trim($value);
    if (preg_match('/\A[\p{L}\p{N}_-]{3,20}\z/u', $nickname) !== 1) {
        fail('Le pseudo doit contenir de 3 à 20 lettres, chiffres, tirets ou tirets bas.');
    }
    return $nickname;
}

function nicknameIsTaken(PDO $pdo, string $nickname, ?int $exceptPlayerId = null): bool
{
    $sql = 'SELECT id FROM players WHERE nickname = :nickname';
    $values = ['nickname' => $nickname];
    if ($exceptPlayerId !== null) {
        $sql .= ' AND id <> :except_player_id';
        $values['except_player_id'] = $exceptPlayerId;
    }
    $query = $pdo->prepare($sql . ' LIMIT 1');
    $query->execute($values);
    return $query->fetchColumn() !== false;
}

function parisToday(): DateTimeImmutable
{
    return new DateTimeImmutable('now', new DateTimeZone('Europe/Paris'));
}

function cleanupExpiredData(PDO $pdo): void
{
    $scoreCutoff = parisToday()->modify('-90 days')->format('Y-m-d');
    $scores = $pdo->prepare('DELETE FROM daily_scores WHERE challenge_date < :cutoff');
    $scores->execute(['cutoff' => $scoreCutoff]);

    $profileCutoff = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->modify('-365 days')->format('Y-m-d H:i:s');
    $players = $pdo->prepare('DELETE FROM players WHERE last_seen_at < :cutoff');
    $players->execute(['cutoff' => $profileCutoff]);
}

function challengePayload(string $mode, array $config): array
{
    $today = parisToday();
    $date = $today->format('Y-m-d');
    $digest = hash_hmac('sha256', $date . '|' . $mode . '|generator-v1', (string)$config['challenge_secret'], true);
    $unpacked = unpack('Nseed', substr($digest, 0, 4));
    $seed = (int)($unpacked['seed'] ?? 1);
    if ($seed === 0) $seed = 1;
    return [
        'date' => $date,
        'date_label' => $today->format('d/m/Y'),
        'mode' => $mode,
        'seed' => $seed,
        'level' => ((int)$today->format('z') % 5) + 1,
        'region' => 'FR',
        'generator_version' => 1,
        'features' => ['custom_nickname' => true],
    ];
}

function bearerToken(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, 'Authorization') === 0) { $header = (string)$value; break; }
        }
    }
    if (!preg_match('/^Bearer ([a-f0-9]{64})$/i', trim($header), $matches)) {
        fail('Profil multijoueur manquant. Enregistre un pseudo.', 401);
    }
    return strtolower($matches[1]);
}

function authenticatedPlayer(PDO $pdo): array
{
    $token = bearerToken();
    $query = $pdo->prepare('SELECT id, nickname FROM players WHERE token_hash = :token_hash LIMIT 1');
    $query->execute(['token_hash' => hash('sha256', $token)]);
    $player = $query->fetch();
    if (!$player) fail('Profil introuvable. Enregistre un nouveau pseudo.', 401);
    $touch = $pdo->prepare('UPDATE players SET last_seen_at = UTC_TIMESTAMP() WHERE id = :id');
    $touch->execute(['id' => $player['id']]);
    return $player;
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$action = strtolower(trim((string)($_GET['action'] ?? '')));
$mode = (string)($_GET['mode'] ?? '');

try {
    $configPath = dirname(__DIR__) . '/config.php';
    $config = is_file($configPath) ? require $configPath : [];

    if ($method === 'GET' && $action === 'challenge') {
        $mode = allowedMode($mode);
        if (!is_array($config) || strlen((string)($config['challenge_secret'] ?? '')) < 32) {
            fail('Le service multijoueur n’est pas encore configuré sur le site.', 503);
        }
        ok(challengePayload($mode, $config));
    }

    $pdo = database();
    cleanupExpiredData($pdo);

    if ($method === 'POST' && $action === 'register') {
        $body = requestBody();
        if (($body['consent'] ?? false) !== true || ($body['consent_version'] ?? '') !== 'privacy-2026-11-18') {
            fail('Coche la case de participation avant de créer un pseudo.');
        }
        $nickname = normalizeNickname($body['nickname'] ?? null);
        if (nicknameIsTaken($pdo, $nickname)) {
            fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
        }
        $insert = $pdo->prepare('INSERT INTO players (nickname, token_hash, last_seen_at, consented_at, consent_version) VALUES (:nickname, :token_hash, UTC_TIMESTAMP(), UTC_TIMESTAMP(), :consent_version)');
        $token = bin2hex(random_bytes(32));
        try {
            $insert->execute(['nickname' => $nickname, 'token_hash' => hash('sha256', $token), 'consent_version' => $body['consent_version']]);
        } catch (PDOException $exception) {
            if (nicknameIsTaken($pdo, $nickname)) {
                fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
            }
            throw $exception;
        }
        ok(['nickname' => $nickname, 'token' => $token]);
    }

    if ($method === 'POST' && $action === 'rename') {
        $player = authenticatedPlayer($pdo);
        $body = requestBody();
        $nickname = normalizeNickname($body['nickname'] ?? null);
        $playerId = (int)$player['id'];
        if (nicknameIsTaken($pdo, $nickname, $playerId)) {
            fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
        }
        $rename = $pdo->prepare('UPDATE players SET nickname = :nickname WHERE id = :id');
        try {
            $rename->execute(['nickname' => $nickname, 'id' => $playerId]);
        } catch (PDOException $exception) {
            if (nicknameIsTaken($pdo, $nickname, $playerId)) {
                fail('Ce pseudo est déjà utilisé. Choisis-en un autre.', 409);
            }
            throw $exception;
        }
        ok(['nickname' => $nickname]);
    }

    if ($method === 'GET' && $action === 'leaderboard') {
        $mode = allowedMode($mode);
        $today = parisToday();
        $query = $pdo->prepare(
            'SELECT p.nickname, s.best_seconds, s.hints_used, s.mistakes
             FROM daily_scores s INNER JOIN players p ON p.id = s.player_id
             WHERE s.challenge_date = :challenge_date AND s.game_mode = :game_mode
             ORDER BY s.ranking_key ASC, s.submitted_at ASC, p.id ASC LIMIT 50'
        );
        $query->execute(['challenge_date' => $today->format('Y-m-d'), 'game_mode' => $mode]);
        ok(['date_label' => $today->format('d/m/Y'), 'region' => 'FR', 'entries' => $query->fetchAll()]);
    }

    if ($method === 'POST' && $action === 'submit') {
        $player = authenticatedPlayer($pdo);
        $body = requestBody();
        $submitMode = allowedMode((string)($body['mode'] ?? ''));
        $today = parisToday();
        $date = (string)($body['date'] ?? '');
        if ($date !== $today->format('Y-m-d')) fail('Ce défi n’est plus celui du jour.', 409);
        $seconds = filter_var($body['elapsed_seconds'] ?? null, FILTER_VALIDATE_INT);
        $hints = filter_var($body['hints_used'] ?? 0, FILTER_VALIDATE_INT);
        $mistakes = filter_var($body['mistakes'] ?? 0, FILTER_VALIDATE_INT);
        if ($seconds === false || $seconds < 1 || $seconds > 86400 || $hints === false || $hints < 0 || $hints > 999 || $mistakes === false || $mistakes < 0 || $mistakes > 999) {
            fail('Le résultat envoyé est invalide.');
        }

        $rankingKey = ($seconds * 1000000) + ($hints * 1000) + $mistakes;
        $previousQuery = $pdo->prepare('SELECT ranking_key FROM daily_scores WHERE player_id = :player_id AND challenge_date = :challenge_date AND game_mode = :game_mode LIMIT 1');
        $previousQuery->execute(['player_id' => $player['id'], 'challenge_date' => $date, 'game_mode' => $submitMode]);
        $previousKey = $previousQuery->fetchColumn();
        $improved = $previousKey === false || $rankingKey < (int)$previousKey;
        $upsert = $pdo->prepare(
            'INSERT INTO daily_scores (player_id, challenge_date, game_mode, best_seconds, hints_used, mistakes, ranking_key, submitted_at)
             VALUES (:player_id, :challenge_date, :game_mode, :best_seconds, :hints_used, :mistakes, :ranking_key, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE
               best_seconds = IF(VALUES(ranking_key) < ranking_key, VALUES(best_seconds), best_seconds),
               hints_used = IF(VALUES(ranking_key) < ranking_key, VALUES(hints_used), hints_used),
               mistakes = IF(VALUES(ranking_key) < ranking_key, VALUES(mistakes), mistakes),
               submitted_at = IF(VALUES(ranking_key) < ranking_key, UTC_TIMESTAMP(), submitted_at),
               ranking_key = LEAST(ranking_key, VALUES(ranking_key))'
        );
        $upsert->execute([
            'player_id' => $player['id'], 'challenge_date' => $date, 'game_mode' => $submitMode,
            'best_seconds' => $seconds, 'hints_used' => $hints, 'mistakes' => $mistakes, 'ranking_key' => $rankingKey,
        ]);
        $resultQuery = $pdo->prepare('SELECT best_seconds FROM daily_scores WHERE player_id = :player_id AND challenge_date = :challenge_date AND game_mode = :game_mode');
        $resultQuery->execute(['player_id' => $player['id'], 'challenge_date' => $date, 'game_mode' => $submitMode]);
        $bestSeconds = (int)$resultQuery->fetchColumn();
        ok(['improved' => $improved, 'best_seconds' => $bestSeconds]);
    }

    if ($method === 'POST' && $action === 'delete') {
        $player = authenticatedPlayer($pdo);
        $delete = $pdo->prepare('DELETE FROM players WHERE id = :id');
        $delete->execute(['id' => $player['id']]);
        ok(['deleted' => true]);
    }

    fail('Action inconnue.', 404);
} catch (Throwable $exception) {
    error_log('Le Cercle des jeux API: erreur interne.');
    fail('Le service multijoueur a rencontré une erreur.', 500);
}
