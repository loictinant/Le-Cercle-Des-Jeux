(() => {
  'use strict';

  const API_URL = window.LE_CERCLE_API_URL || 'https://loic-apps.duckdns.org/lecercle-api/v1/index.php';
  const PROFILE_KEY = 'lecercle.multiplayer.profile.v1';
  const CONSENT_VERSION = 'privacy-2026-11-18';
  const NICKNAME_PATTERN = /^[\p{L}\p{N}_-]{3,20}$/u;
  const MODES = [
    { id: 'sudoku', title: 'Sudoku', icon: '▦' },
    { id: 'crossword', title: 'Mots croisés', icon: '✳' },
    { id: 'arrows', title: 'Mots fléchés', icon: '↘' },
    { id: 'search', title: 'Mots mêlés', icon: '⌕' },
    { id: 'memory', title: 'Mémory', icon: '❋' }
  ];
  const $ = id => document.getElementById(id);
  const overlay = $('challengeOverlay');
  const modeList = $('challengeModeList');
  const status = $('challengeStatus');
  const resultStatus = $('challengeResultStatus');
  let profile = readProfile();
  let challenges = new Map();
  let nicknameSupportStatus = 'checking';

  function cleanNickname(value) {
    return String(value || '').normalize('NFC').trim();
  }

  function nicknameError(value) {
    const nickname = cleanNickname(value);
    if (!nickname) return 'Saisis un pseudo pour le classement.';
    if (!NICKNAME_PATTERN.test(nickname)) return 'Le pseudo doit contenir de 3 à 20 lettres, chiffres, tirets ou tirets bas.';
    return '';
  }

  function readProfile() {
    try {
      const value = JSON.parse(localStorage.getItem(PROFILE_KEY) || 'null');
      return value && value.token && value.nickname ? value : null;
    } catch (_) { return null; }
  }

  function saveProfile(value) {
    if (value) localStorage.setItem(PROFILE_KEY, JSON.stringify(value));
    else { try { localStorage.removeItem(PROFILE_KEY); } catch (_) { /* Le profil serveur vient d’être supprimé. */ } }
    profile = value;
    renderProfile();
  }

  function renderProfile() {
    $('challengeRegistration').classList.toggle('hidden', !!profile);
    $('challengeProfileReady').classList.toggle('hidden', !profile);
    const editInput = $('challengeNicknameEdit');
    if (profile) {
      $('challengePlayerName').textContent = profile.nickname;
      const playerLabel = $('playerLabel');
      if (playerLabel) playerLabel.textContent = profile.nickname;
      if (document.activeElement !== editInput) editInput.value = profile.nickname;
    } else {
      const playerLabel = $('playerLabel');
      if (playerLabel) playerLabel.textContent = 'Joueur du jour';
    }
    const consent = $('challengeConsent');
    const createButton = $('createChallengeProfile');
    const nicknameInput = $('challengeNickname');
    if (consent && createButton) createButton.disabled = !!profile || !consent.checked || !!nicknameError(nicknameInput.value) || nicknameSupportStatus !== 'supported';
    const editButton = $('saveChallengeNickname');
    if (editButton) editButton.disabled = !profile || !!nicknameError(editInput.value) || cleanNickname(editInput.value) === (profile && profile.nickname) || nicknameSupportStatus !== 'supported';
    const serverMessage = nicknameSupportStatus === 'supported'
        ? ''
        : nicknameSupportStatus === 'unsupported'
          ? 'Une mise à jour du service du site est nécessaire pour choisir ou changer un pseudo.'
          : nicknameSupportStatus === 'offline'
            ? 'Le classement est hors ligne. Réessaie quand le service sera accessible.'
            : 'Vérification du service de classement…';
    for (const noticeId of ['nicknameServerNotice', 'nicknameEditServerNotice']) {
      const serverNotice = $(noticeId);
      if (serverNotice) serverNotice.textContent = serverMessage;
    }
  }

  async function request(action, { method = 'GET', params = {}, body = null, authenticated = false } = {}) {
    const url = new URL(API_URL);
    url.searchParams.set('action', action);
    for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value));
    const headers = { Accept: 'application/json' };
    if (body !== null) headers['Content-Type'] = 'application/json';
    if (authenticated && profile) headers.Authorization = `Bearer ${profile.token}`;
    const response = await fetch(url, { method, headers, body: body === null ? undefined : JSON.stringify(body), cache: 'no-store' });
    let payload;
    try { payload = await response.json(); } catch (_) { throw new Error('Le serveur a renvoyé une réponse illisible.'); }
    if (!response.ok || !payload || payload.ok !== true) throw new Error((payload && payload.error) || `Erreur réseau (${response.status}).`);
    return payload.data || {};
  }

  function setStatus(message, kind = '') {
    status.textContent = message;
    status.className = `challenge-status${kind ? ` ${kind}` : ''}`;
  }

  function formatTime(seconds) {
    const value = Math.max(0, Number(seconds) || 0);
    return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
  }

  function renderModes() {
    while (modeList.firstChild) modeList.removeChild(modeList.firstChild);
    for (const mode of MODES) {
      const challenge = challenges.get(mode.id);
      const row = document.createElement('article');
      row.className = 'challenge-mode-row';
      const symbol = document.createElement('span'); symbol.className = 'challenge-mode-symbol'; symbol.textContent = mode.icon;
      const copy = document.createElement('div'); copy.className = 'challenge-mode-copy';
      const title = document.createElement('b'); title.textContent = mode.title;
      const detail = document.createElement('small'); detail.textContent = challenge ? `Niveau ${challenge.level} · ${challenge.date_label}` : 'Défi quotidien';
      copy.append(title, detail);
      const play = document.createElement('button'); play.type = 'button'; play.className = 'challenge-play'; play.textContent = 'Jouer'; play.dataset.playChallenge = mode.id; play.disabled = !challenge;
      const ranking = document.createElement('button'); ranking.type = 'button'; ranking.className = 'challenge-ranking'; ranking.textContent = 'Classement'; ranking.dataset.leaderboardMode = mode.id; ranking.disabled = !challenge;
      row.append(symbol, copy, play, ranking);
      modeList.append(row);
    }
  }

  async function loadChallenges() {
    challenges.clear(); nicknameSupportStatus = 'checking'; renderProfile(); renderModes(); setStatus('Connexion au classement…');
    const results = await Promise.all(MODES.map(mode => request('challenge', { params: { mode: mode.id } }).then(value => ({ fulfilled: true, value }), error => ({ fulfilled: false, error }))));
    const successful = results.filter(result => result.fulfilled);
    nicknameSupportStatus = successful.length
      ? (successful.some(result => result.value.features && result.value.features.custom_nickname === true) ? 'supported' : 'unsupported')
      : 'offline';
    let dateLabel = '';
    results.forEach((result, index) => {
      if (result.fulfilled) {
        challenges.set(MODES[index].id, result.value);
        if (!dateLabel) dateLabel = result.value.date_label || '';
      }
    });
    renderModes();
    renderProfile();
    if (!challenges.size) {
      setStatus('Le classement n’est pas encore joignable. Le service doit être installé sur le site.', 'error');
      return;
    }
    setStatus(`Défis du ${dateLabel} · classement France`, 'success');
  }

  async function showLeaderboard(modeId) {
    const mode = MODES.find(item => item.id === modeId);
    if (!mode) return;
    $('leaderboardPanel').classList.remove('hidden');
    modeList.classList.add('hidden');
    $('leaderboardTitle').textContent = `Classement · ${mode.title}`;
    $('leaderboardDate').textContent = 'Chargement…';
    while ($('leaderboardList').firstChild) $('leaderboardList').removeChild($('leaderboardList').firstChild);
    try {
      const data = await request('leaderboard', { params: { mode: modeId } });
      $('leaderboardDate').textContent = `Défi du ${data.date_label} · meilleurs temps, puis aides utilisées.`;
      if (!Array.isArray(data.entries) || !data.entries.length) {
        const empty = document.createElement('li'); empty.className = 'leaderboard-empty'; empty.textContent = 'Pas encore de résultat aujourd’hui. À toi de commencer !';
        $('leaderboardList').append(empty);
        return;
      }
      data.entries.forEach((entry, index) => {
        const item = document.createElement('li'); item.className = 'leaderboard-entry';
        const rank = document.createElement('span'); rank.className = 'leaderboard-rank'; rank.textContent = String(index + 1);
        const name = document.createElement('b'); name.className = 'leaderboard-name'; name.textContent = String(entry.nickname || 'Joueur');
        const time = document.createElement('span'); time.className = 'leaderboard-time'; time.textContent = formatTime(entry.best_seconds);
        const detail = document.createElement('small'); detail.textContent = `${Number(entry.hints_used) || 0} aide${Number(entry.hints_used) === 1 ? '' : 's'}`;
        item.append(rank, name, time, detail); $('leaderboardList').append(item);
      });
    } catch (error) {
      $('leaderboardDate').textContent = error.message || 'Classement indisponible.';
    }
  }

  async function registerProfile() {
    if (!$('challengeConsent').checked) { setStatus('Coche la case pour participer au classement France.', 'error'); return; }
    if (nicknameSupportStatus !== 'supported') { setStatus('Le service du site doit être mis à jour avant de choisir un pseudo.', 'error'); return; }
    const nickname = cleanNickname($('challengeNickname').value);
    const validation = nicknameError(nickname);
    if (validation) { setStatus(validation, 'error'); return; }
    $('createChallengeProfile').disabled = true; setStatus('Enregistrement du pseudo…');
    try {
      const storageProbe = `${PROFILE_KEY}.check`;
      localStorage.setItem(storageProbe, '1'); localStorage.removeItem(storageProbe);
      const data = await request('register', { method: 'POST', body: { nickname, consent: true, consent_version: CONSENT_VERSION } });
      if (data.nickname !== nickname) throw new Error('Le serveur n’a pas confirmé le pseudo choisi. Mets à jour le service du site puis réessaie.');
      saveProfile({ nickname: data.nickname, token: data.token });
      setStatus('Pseudo enregistré. Choisis un défi pour jouer.', 'success');
    } catch (error) {
      setStatus(error.message || 'Impossible d’enregistrer le pseudo.', 'error');
    } finally { $('createChallengeProfile').disabled = false; }
  }

  async function renameProfile() {
    if (!profile) return;
    const nickname = cleanNickname($('challengeNicknameEdit').value);
    const validation = nicknameError(nickname);
    if (validation) { setStatus(validation, 'error'); return; }
    if (nicknameSupportStatus !== 'supported') { setStatus('Le service du site doit être mis à jour avant de changer le pseudo.', 'error'); return; }
    $('saveChallengeNickname').disabled = true; setStatus('Mise à jour du pseudo…');
    try {
      const data = await request('rename', { method: 'POST', body: { nickname }, authenticated: true });
      saveProfile({ ...profile, nickname: data.nickname });
      setStatus(`Pseudo modifié : ${data.nickname}.`, 'success');
    } catch (error) {
      setStatus(error.message || 'Impossible de modifier le pseudo.', 'error');
    } finally { renderProfile(); }
  }

  async function deleteProfile() {
    if (!profile || !window.confirm('Supprimer ce pseudo et tous ses résultats du classement ?')) return;
    $('deleteChallengeProfile').disabled = true; setStatus('Suppression du profil…');
    try {
      await request('delete', { method: 'POST', body: {}, authenticated: true });
      try { localStorage.removeItem(PROFILE_KEY); } catch (_) { /* Profil supprimé du serveur. */ }
      saveProfile(null);
      setStatus('Pseudo et résultats supprimés.', 'success');
    } catch (error) {
      setStatus(error.message || 'Impossible de supprimer le profil.', 'error');
    } finally { $('deleteChallengeProfile').disabled = false; }
  }

  async function startChallenge(modeId) {
    let challenge = challenges.get(modeId);
    if (!challenge) {
      try { challenge = await request('challenge', { params: { mode: modeId } }); challenges.set(modeId, challenge); }
      catch (error) { setStatus(error.message || 'Défi indisponible.', 'error'); return; }
    }
    overlay.classList.add('hidden');
    if (typeof window.startDailyChallenge === 'function') window.startDailyChallenge(modeId, challenge);
  }

  async function submitResult(event) {
    const result = event.detail;
    if (!result || !result.mode || !result.date) return;
    if (!profile) { resultStatus.textContent = 'Résultat terminé ; aucun pseudo enregistré pour le classement.'; return; }
    resultStatus.textContent = 'Envoi du résultat au classement France…';
    try {
      const saved = await request('submit', {
        method: 'POST', authenticated: true,
        body: { mode: result.mode, date: result.date, elapsed_seconds: result.elapsedSeconds, mistakes: result.mistakes, hints_used: result.hintsUsed }
      });
      resultStatus.textContent = saved.improved ? `Résultat classé : ${formatTime(saved.best_seconds)}.` : `Ton meilleur temps reste ${formatTime(saved.best_seconds)}.`;
    } catch (error) {
      resultStatus.textContent = `Résultat terminé, envoi impossible : ${error.message || 'classement indisponible'}.`;
    }
  }

  $('openChallenges').addEventListener('click', () => {
    overlay.classList.remove('hidden');
    $('leaderboardPanel').classList.add('hidden'); modeList.classList.remove('hidden');
    renderProfile(); loadChallenges();
  });
  $('closeChallenges').addEventListener('click', () => overlay.classList.add('hidden'));
  $('createChallengeProfile').addEventListener('click', registerProfile);
  $('challengeNickname').addEventListener('input', renderProfile);
  $('challengeNicknameEdit').addEventListener('input', renderProfile);
  $('saveChallengeNickname').addEventListener('click', renameProfile);
  $('challengeConsent').addEventListener('change', renderProfile);
  $('deleteChallengeProfile').addEventListener('click', deleteProfile);
  $('backToChallenges').addEventListener('click', () => { $('leaderboardPanel').classList.add('hidden'); modeList.classList.remove('hidden'); });
  overlay.addEventListener('click', event => { if (event.target === overlay) overlay.classList.add('hidden'); });
  modeList.addEventListener('click', event => {
    const play = event.target.closest('[data-play-challenge]');
    const ranking = event.target.closest('[data-leaderboard-mode]');
    if (play && !play.disabled) startChallenge(play.dataset.playChallenge);
    if (ranking && !ranking.disabled) showLeaderboard(ranking.dataset.leaderboardMode);
  });
  window.addEventListener('lcdj:challenge-finished', submitResult);
  renderProfile(); renderModes();
})();
