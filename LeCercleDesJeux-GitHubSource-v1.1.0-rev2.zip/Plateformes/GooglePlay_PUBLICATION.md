# Publier Le Cercle des jeux sur Google Play

## Fichiers

- `deliverables/LeCercleDesJeux/Android/Le-Cercle-des-jeux-debug.apk` : installation de test.
- `deliverables/LeCercleDesJeux/Android/Le-Cercle-des-jeux-release.apk` : APK signé pour installation directe et tests.
- `deliverables/LeCercleDesJeux/Android/Le-Cercle-des-jeux.aab` : fichier à envoyer à Google Play Console.

Pour une nouvelle application Google Play, le fichier de publication est l’Android App Bundle (`.aab`). L’APK sert à installer ou tester le jeu directement.

## Étapes

1. Créer un compte développeur Google Play Console, vérifier son identité et accepter les conditions. L’inscription coûte actuellement 25 USD une seule fois. Les comptes personnels doivent aussi vérifier leur accès à un appareil Android avec l’application Play Console. [Guide du compte](https://support.google.com/googleplay/android-developer/answer/6112435?hl=fr).
2. Créer une application dans Play Console avec le nom et la langue française. L’identifiant prévu pour ce projet est `fr.tinantloic.lecerclejeux` ; il doit rester libre et définitif. Vérifier l’identité développeur et l’enregistrement du nom de package dans Play Console.
3. Ajouter les éléments de fiche : nom, descriptions, icône 512 × 512, captures d’écran, catégorie « Jeux », coordonnées de contact et pays de diffusion.
4. Après avoir téléversé le site, publier la politique de confidentialité à `https://loic-apps.duckdns.org/jeux/LeCercleDesJeux/privacy.html`, puis déclarer dans le formulaire de sécurité des données le pseudo, les résultats et les données techniques réellement traités. Seuls les joueurs qui acceptent et rejoignent le classement France envoient ces données. La version ne contient pas de publicités.
5. Ouvrir **Tester et publier > Tests internes**, créer une version et téléverser `Le-Cercle-des-jeux.aab`. Vérifier l’application sur un téléphone avant de poursuivre.
6. Pour un compte personnel créé après le 13 novembre 2023, créer ensuite un test fermé avec au moins 12 testeurs qui restent inscrits pendant 14 jours consécutifs. Répondre ensuite au questionnaire de préparation à la production. [Règles de test des comptes personnels](https://support.google.com/googleplay/android-developer/answer/14151465?hl=fr).
7. Préparer la version Production, choisir les pays, ajouter les notes de version et envoyer l’application en examen.

Google Play demande l’API 36 pour les nouvelles applications depuis le 31 août 2026 ; le projet Android vise cette API. [Règle d’API cible](https://support.google.com/googleplay/android-developer/answer/11926878?hl=fr). Google Play App Signing est à activer lors du premier téléversement. Pour les nouvelles applications, déposer le AAB plutôt que l’APK : [format Android App Bundle](https://developer.android.com/guide/app-bundle).

La politique de confidentialité publique doit décrire les défis en ligne, le classement, la suppression du profil et les données conservées par l’hébergeur. Vérifier les réponses et catégories directement dans Play Console avant la publication : [préparer l’application pour l’examen](https://support.google.com/googleplay/android-developer/answer/9859455?hl=fr).

## Clé de téléversement

`prepare-release-key.ps1` crée une clé privée sous `%LOCALAPPDATA%\LeCercleDesJeux\AndroidSigning`. Son mot de passe est chiffré pour le compte Windows actuel. Gardez le fichier `.jks` privé et sauvegardez-le ; il sera utile pour les futures versions. Ne le joignez jamais à une publication publique.

## Conditions à compléter avant une publication

- L’adresse de la politique de confidentialité à publier après l’envoi du site est `https://loic-apps.duckdns.org/jeux/LeCercleDesJeux/privacy.html`.
- Le compte, la fiche Play Console, les captures d’écran et l’examen de Google relèvent du titulaire du compte.
- La clé de téléversement est propre à ce projet ; le premier dépôt Google doit être effectué avec le même fichier AAB généré ici, ou avec une clé de téléversement enregistrée dans Play Console.
